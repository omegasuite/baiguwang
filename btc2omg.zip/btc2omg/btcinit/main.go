// Copyright (c) 2014-2016 The btcsuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package main

import (
	"fmt"
	"github.com/btcsuite/btcd/btc2omg/btcd/blockchain"
	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg"
	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg/chainhash"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire/common"
	"github.com/btcsuite/btcd/btc2omg/btcutil"
	"github.com/btcsuite/btcd/btc2omg/btcutil/base58"
	"github.com/btcsuite/btcd/btc2omg/omega/token"
	"math/big"
	_ "net/http/pprof"
	"os"
	"time"
)

func solveGenesisBlock(msgBlock *wire.MsgBlock, bits uint32) {
	// Create some convenience variables.
	header := &msgBlock.Header

	targetDifficulty := blockchain.CompactToBig(bits)
	targetDifficulty = targetDifficulty.Mul(targetDifficulty, big.NewInt(wire.DifficultyRatio))

	//	log.Printf("targetDifficulty = %s\n", targetDifficulty.String())
	for {
		header.Timestamp = time.Now()

		for i := int32(1); i < 0x7FFFFFFF; i++ {
			// Update the nonce and hash the block header.  Each
			// hash is actually a double sha256 (two hashes), so
			// increment the number of hashes completed for each
			// attempt accordingly.
			header.Nonce = i
			hash := header.BlockHash()

			//		log.Printf("%d: solve = %s\n", i, blockchain.HashToBig(&hash).String())

			// The block is solved when the new block hash is less
			// than the target difficulty.  Yay!
			hashNum := blockchain.HashToBig(&hash)
			if hashNum.Cmp(targetDifficulty) <= 0 {
				return
			}
		}
	}
}

func solveMinerBlock(header *wire.MingingRightBlock) {
	// Create some convenience variables.
	targetDifficulty := blockchain.CompactToBig(header.Bits)

	//	log.Printf("targetDifficulty = %s\n", targetDifficulty.String())

	for {
		for i := int32(1); i < 0x7FFFFFFF; i++ {
			// Update the nonce and hash the block header.  Each
			// hash is actually a double sha256 (two hashes), so
			// increment the number of hashes completed for each
			// attempt accordingly.
			header.Nonce = i
			hash := header.BlockHash()

			//		log.Printf("%d: solve = %s\n", i, blockchain.HashToBig(&hash).String())

			// The block is solved when the new block hash is less
			// than the target difficulty.  Yay!
			hashNum := blockchain.HashToBig(&hash)
			if hashNum.Cmp(targetDifficulty) <= 0 {
				return
			}
		}
		header.Timestamp = time.Now()
	}
}

func main() {
	addresses := map[common.OmegaNet][2]string{
		common.MainNet: {"1KJWNqX77WRVSxa3Ystt22kEJ26KowS63H", "1JzP4VZHSt9r9edtZnTAGAmHrv5VunYyxZ"},
		//		common.RegNet:  {"n1g2DjUq9ixkuFB3q5JMRDUs9bZURkyMgu", "mv6rzCvtd8pJ8Tq5ruU9wwfRMucuKynVcS"},
		common.TestNet: {"n1g2DjUq9ixkuFB3q5JMRDUs9bZURkyMgu", "mv6rzCvtd8pJ8Tq5ruU9wwfRMucuKynVcS"},
		//		common.SimNet:  {"ShT4xXB154iheSUtewK49CR6wPCCJvwWBL", "Sbsuizd4YUaEsf8vgmUrfvbf9hFdDeiaaj"},
	}
	// Kzbqi8f6dv57BAXUohwy8Mf9LCsD5EuHV3KUv6F2k2P3kip51TqY, L5o5Rt4JkNBDPFnwkP6DC1JCnLnrRHsqTH5PBkAE8WDqEpxsFr6d
	// cQuCDdLxTbBtSUNiYmyk2cGsiDptva5kL8NvMsa2AnKwFxm6WMoP, cSZRj81Wp2Qrvnbz1ttuqxL2qowZkH4AceC6GYVdbgQ4zerCodZN
	// FrJYkCFv8DqmzYXwgF7cNR8B7puDtQPhhinoajQrvGa17x9AtLWw, FsxnFgvUUf4kUrmD9N2nBmBLFR1ti7N7zEbyVQLUMAe8reC48pFR

	btcroots := map[common.OmegaNet]string{
		common.MainNet: "00000000000000000002fd4bd2b63713153aee330eee4d8934082658301742bb",
		//		common.RegNet:  "0000000000000000000000000000000000000000000000000000000000000000",
		common.TestNet: "000000000054071ecabae44ecd838a9a1ab853e0d4beef030225e40e2112fa1c",
		//		common.SimNet:  "0000000000000000000000000000000000000000000000000000000000000000",
	}

	params := map[common.OmegaNet]*chaincfg.Params{
		common.MainNet: &chaincfg.MainNetParams,
		//		common.RegNet:  &chaincfg.RegressionNetParams,
		common.TestNet: &chaincfg.TestNet3Params,
		//		common.SimNet:  &chaincfg.SimNetParams,
	}
	names := map[common.OmegaNet]string{
		common.MainNet: "MainNet",
		//		common.RegNet:  "RegNet",
		common.TestNet: "TestNet",
		//		common.SimNet:  "SimNet",
	}

	for net, k := range addresses {
		// for coin
		addr, _, err := base58.CheckDecode(k[0])
		if err != nil {
			fmt.Printf("Failed to generate pay-to-address script")
			os.Exit(1)
		}

		coinpkScript := make([]byte, 25)
		coinpkScript[0] = params[net].PubKeyHashAddrID
		copy(coinpkScript[1:], addr)
		coinpkScript[21] = 0x41

		fmt.Printf("\n\nvar " + params[net].Name + "creator = [20]byte{")
		printKey(addr)
		fmt.Printf("}\n")
		var miner [20]byte
		copy(miner[:], addr)

		addr, _, err = base58.CheckDecode(k[1])
		if err != nil {
			fmt.Printf("Failed to generate pay-to-address script")
			os.Exit(1)
		}

		plgpkScript := make([]byte, 25)
		plgpkScript[0] = params[net].PubKeyHashAddrID
		copy(plgpkScript[1:], addr)
		plgpkScript[21] = 0x41

		if err != nil {
			fmt.Printf("Failed to generate pay-to-address script")
			os.Exit(1)
		}

		// genesisBlock defines the genesis block of the block chain which serves as the
		// public transaction ledger for the main network.
		btcroot, _ := chainhash.NewHashFromStr(btcroots[net])

		var genesisCoinbaseTx = wire.MsgTx{
			Version: 0x11,
			TxDef:   []token.Definition{},
			TxIn: []*wire.TxIn{
				{
					PreviousOutPoint: wire.OutPoint{
						Hash:  *btcroot,
						Index: 0,
					},
					SignatureIndex: 0xffffffff,
					Sequence:       0xffffffff,
				},
			},
			TxOut: []*wire.TxOut{
				{
					PkScript: coinpkScript,
				},
			},
			LockTime: 0,
		}

		genesisCoinbaseTx.TxOut[0].TokenType = 0                               // common.OmegaCoinTyp             // for test, we give a large number of omegas, chainid for omega is 1 0
		genesisCoinbaseTx.TxOut[0].Value = &token.NumToken{Val: 6000000 * 1e8} // 6 million omegas
		genesisCoinbaseTx.TxOut[0].Rights = nil

		t1 := btcutil.NewTx(&genesisCoinbaseTx)
		t1.SetIndex(0)

		merkles := blockchain.BuildMerkleTreeStore([]*btcutil.Tx{t1}, false, 0x10000)

		// genesisMerkleRoot is the hash of the first transaction in the genesis block
		// for the main network.
		var genesisMerkleRoot = merkles[len(merkles)-1]

		witnessMerkleTree := blockchain.BuildMerkleTreeStore([]*btcutil.Tx{t1}, true, 0x10000)
		witnessMerkleRoot := witnessMerkleTree[len(witnessMerkleTree)-1]

		var genesisBlock = wire.MsgBlock{
			Header: wire.BlockHeader{
				Version:    0x50000,
				PrevBlock:  chainhash.Hash{},   // 0000000000000000000000000000000000000000000000000000000000000000
				MerkleRoot: *genesisMerkleRoot, //
				Nonce:      0,
			},
			Transactions: []*wire.MsgTx{&genesisCoinbaseTx},
		}

		// because wire.DifficultyRatio is 2, so exp. portion of PowLimitBits is dec. by 2
		solveGenesisBlock(&genesisBlock, params[net].PowLimitBits)
		var genesisHash = genesisBlock.Header.BlockHash()

		genesisCoinbaseTx.SignatureScripts = [][]byte{(*witnessMerkleRoot)[:]}

		printCoinbase(params[net].Name+"coinbaseTx", &genesisCoinbaseTx)

		fmt.Printf("\n\nvar " + names[net] + "GenesisMerkleRoot = ")
		printhash(*genesisMerkleRoot)

		fmt.Printf("\n\nvar "+names[net]+"GenesisBlock = wire.MsgBlock{"+
			"\n\tHeader: wire.BlockHeader{"+
			"\n\t\tVersion:    0x50000,"+
			"\n\t\tPrevBlock:  chainhash.Hash{},"+
			"\n\t\tMerkleRoot: "+names[net]+"GenesisMerkleRoot,"+
			"\n\t\tTimestamp:  time.Unix(0x%x, 0), "+
			"\n\t\tNonce:      %d,", genesisBlock.Header.Timestamp.Unix(), genesisBlock.Header.Nonce)

		fmt.Printf("}}}," +
			"\n\t}," +
			"\n\tTransactions: []*wire.MsgTx{&" + params[net].Name + "coinbaseTx}," +
			"\n}")

		var minerBlock = wire.MingingRightBlock{
			Version:   0x50000,
			PrevBlock: chainhash.Hash{},
			BestBlock: genesisHash,
			Timestamp: genesisBlock.Header.Timestamp,
			Bits:      params[net].PowLimitBits,
			Nonce:     0,
			Miner:     miner,
			//			Connection:      []byte("omegasuite.org"),
			Connection:      []byte("192.168.1.109:18788"),
			Utxos:           nil,
			Collateral:      0,
			MeanTPH:         1000,
			ViolationReport: []*wire.Violations{},
			TphReports:      []uint32{},
			ContractLimit:   100000,
		}

		solveMinerBlock(&minerBlock)

		// genesisHash is the hash of the first block in the block chain for the main
		// network (genesis block)

		//	var genesisHash = genesisBlock.BlockHash()
		fmt.Printf("\n\nvar " + names[net] + "GenesisHash = []chainhash.Hash{\n")
		printhash(genesisHash)
		fmt.Printf(",\n")

		var genesisMinerHash = minerBlock.BlockHash()

		printhash(genesisMinerHash)
		fmt.Printf(",\n}")

		fmt.Printf("\n\nvar "+names[net]+"GenesisMinerBlock = wire.MingingRightBlock{"+
			"\n\tVersion: 0x50000,"+
			"\n\tPrevBlock:  chainhash.Hash{},"+
			"\n\tBestBlock: "+names[net]+"GenesisHash[0],"+
			"\n\t\tTimestamp:  time.Unix(0x%x, 0), "+
			"\n\tBits:      0x%x,"+
			"\n\tNonce:      %d,"+
			"\n\t\tMeanTPH:    1000,"+
			"\n\t\tContractLimit:    100000,"+
			"\n\tConnection:      []byte{", minerBlock.Timestamp.Unix(), minerBlock.Bits, minerBlock.Nonce)

		printKey(minerBlock.Connection)

		fmt.Printf("}," +
			"\n\tBlackList: []wire.BlackList{}," +
			"\n\tUtxos: []wire.OutPoint{}," +
			"\n\tMiner: " + params[net].Name + "creator," +
			"\n}")
	}
}

func printKey(k []byte) {
	for i := 0; i < len(k); i++ {
		if i%8 == 0 {
			fmt.Printf("\n\t\t\t\t")
		}
		fmt.Printf("0x%02x, ", k[i])
	}
}

func printCoinbase(name string, tx *wire.MsgTx) {
	fmt.Printf("\n\nvar %s = wire.MsgTx{"+
		"\n\tVersion: 0x11,"+
		"\n\tTxDef: []token.Definition{},", name)
	fmt.Printf("\n\tTxIn: []*wire.TxIn{" +
		"\n\t\t{" +
		"\n\t\t\tPreviousOutPoint: wire.OutPoint{" +
		"\n\t\t\tHash:  ")

	printhash(tx.TxIn[0].PreviousOutPoint.Hash)
	fmt.Printf("," +
		"\n\t\t\tIndex: 0," +
		"\n\t\t}," +
		"\n\t\tSignatureIndex: 0xffffffff," +
		"\n\t\tSequence: 0xffffffff," +
		"\n\t}," +
		"\n\t}," +
		"\n\tTxOut: []*wire.TxOut{" +
		"\n\t\t{" +
		"\n\t\t\tToken:coinToken," +
		"\n\t\t\tPkScript: []byte{")

	for i := 0; i < len(tx.TxOut[0].PkScript); i++ {
		if i%8 == 0 {
			fmt.Printf("\n\t\t\t\t")
		}
		fmt.Printf("0x%02x, ", tx.TxOut[0].PkScript[i])
	}

	fmt.Printf("\n\t\t\t}," +
		"\n\t\t}," +
		"\n\t}," +
		"\n\tSignatureScripts: [][]byte { []byte{")

	for i := 0; i < len(tx.SignatureScripts[0]); i++ {
		if i%8 == 0 {
			fmt.Printf("\n\t\t")
		}
		fmt.Printf("0x%02x, ", tx.SignatureScripts[0][i])
	}

	fmt.Printf("\n\t} }," +
		"\n\tLockTime: 0," +
		"\n}")
}

func printhash(h chainhash.Hash) {
	fmt.Printf("chainhash.Hash{")
	hb := h.CloneBytes()
	i := 0
	for _, b := range hb {
		if (i % 8) == 0 {
			fmt.Printf("\n\t\t")
		}
		i++
		fmt.Printf("0x%02x, ", b)
	}
	fmt.Printf("\n\t}")
}
