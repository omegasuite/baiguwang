// Copyright (c) 2013-2015 The omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package wire

import (
	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg/chainhash"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire/common"
	btcwire "github.com/btcsuite/btcd/wire"
	"io"
)

// MsgSolicitSigs  implements the Message interface and defines a bitcoin SolicitSigs
// message.
//

type MsgSolicitSigs struct {
	Tx     *btcwire.MsgTx
	Height uint32
	SigReq byte
	Hash   chainhash.Hash
}

// BtcDecode decodes r using the bitcoin protocol encoding into the receiver.
// This is part of the Message interface implementation.
func (msg *MsgSolicitSigs) OmcDecode(r io.Reader, pver uint32, enc MessageEncoding) error {
	var err error
	msg.Height, err = common.BinarySerializer.Uint32(r, common.LittleEndian)
	if err != nil {
		return err
	}
	err = common.ReadElements(r, &msg.SigReq, &msg.Hash)
	if err != nil {
		return err
	}

	msg.Tx = btcwire.NewMsgTx(btcwire.TxVersion)
	err = msg.Tx.Deserialize(r)
	if err != nil {
		msg.Tx = nil
	}
	return nil
}

// BtcEncode encodes the receiver to w using the bitcoin protocol encoding.
// This is part of the Message interface implementation.
func (msg *MsgSolicitSigs) OmcEncode(w io.Writer, pver uint32, enc MessageEncoding) error {
	err := common.BinarySerializer.PutUint32(w, common.LittleEndian, msg.Height)
	if err != nil {
		return err
	}
	err = common.WriteElements(w, msg.SigReq, &msg.Hash)
	if err != nil {
		return err
	}
	if msg.Tx == nil {
		return nil
	}

	return msg.Tx.Serialize(w)
}

// Command returns the protocol command string for the message.  This is part
// of the Message interface implementation.
func (msg *MsgSolicitSigs) Command() string {
	return CmdSolicitSigs
}

// MaxPayloadLength returns the maximum length the payload can be for the
// receiver.  This is part of the Message interface implementation.
func (msg *MsgSolicitSigs) MaxPayloadLength(pver uint32) uint32 {
	// Since this can vary depending on the message, make it the max
	// size allowed.
	return MaxMessagePayload
}

// NewMsgAlert returns a new bitcoin alert message that conforms to the Message
// interface.  See MsgAlert for details.
func NewMsgSolicitSigs() *MsgSolicitSigs {
	return &MsgSolicitSigs{}
}
