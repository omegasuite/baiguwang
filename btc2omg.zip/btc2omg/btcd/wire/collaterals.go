// Copyright (c) 2013-2016 The btcsuite developers
// Copyright (c) 2018-2021 The Omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package wire

import (
	"sync"
)

type Collaterals struct {
	StateLock         sync.Mutex
	LockedCollaterals map[OutPoint]struct{} // reference counts of them
}

func (s *Collaterals) Exists(p *OutPoint) bool {
	s.StateLock.Lock()
	_, ok := s.LockedCollaterals[*p]
	s.StateLock.Unlock()
	return ok
}

func (s *Collaterals) Delete(p *OutPoint) {
	s.StateLock.Lock()
	delete(s.LockedCollaterals, *p)
	s.StateLock.Unlock()
}

func (s *Collaterals) Add(p *OutPoint) {
	s.StateLock.Lock()
	s.LockedCollaterals[*p] = struct{}{}
	s.StateLock.Unlock()
}

func NewCollaterals() *Collaterals {
	return &Collaterals{
		LockedCollaterals: make(map[OutPoint]struct{}),
	}
}
