// Copyright (c) 2013-2016 The btcsuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package common

import (
	"bytes"
	"crypto/rand"
	"encoding/binary"
	"fmt"
	"github.com/btcsuite/btcd/wire"
	"io"
	"math"
	"time"

	"github.com/btcsuite/btcd/chaincfg/chainhash"
	"strconv"
	"strings"
)

const (
	// MaxVarIntPayload is the maximum payload size for a variable length integer.
	MaxVarIntPayload = 9

	// MinTxOutPayload is the minimum payload size for a transaction output.
	// Value 8 bytes + Varint for PkScript length 1 byte.
	MinTxOutPayload = 9

	// binaryFreeListMaxItems is the number of buffers to keep in the free
	// list to use for binary serialization and deserialization.
	BinaryFreeListMaxItems = 1024
	FeeCoinTyp             = 0 // type of coin for tx fee
	OmegaCoinTyp           = 0x10000000000
	NewChainConsensus      = 100
)

// InvType represents the allowed types of inventory vectors.  See InvVect.
type InvType uint32

// These constants define the various supported inventory vector types.
const (
	InvTypeError         InvType = 0
	InvTypeTx            InvType = 1
	InvTypeBlock         InvType = 2
	InvTypeFilteredBlock InvType = 3
	InvTypeTempBlock     InvType = InvTypeBlock | InvTempFlag
	InvTypeMinerBlock    InvType = 5
	InvTypeWitnessBlock  InvType = InvTypeBlock | InvWitnessFlag
	InvTypeMask          InvType = 7
	InvTypeWitnessTx     InvType = InvTypeTx | InvWitnessFlag
	//	InvTypeFilteredWitnessBlock InvType = InvTypeFilteredBlock | InvWitnessFlag
)

// These constants define the bucket names and meta keys.
const (
	INCOMINGPOOL         string = "IncomingPool"  // bucket for assets pending incoming transfer
	ROLLBACKPOOL         string = "ROLLBACKPOOL"  // key in INCOMINGPOOL bucket for the current SVP chain height
	BTCL2POOL            string = "BTC-L2Pool"    // bucket for assets pending transfer from BTC to L2
	BRIDGESIGNERS        string = "BridgeSigners" // bucket for those who having power to release assets in BTC treasury
	RetiredBRIDGESIGNERS        = "RetiredBRIDGESIGNERS"
	XCAssets             string = "XCAssets"   // bucket for assets transferred in from other chains
	XBTCAssets           string = "XBTCAssets" // bucket for BTC assets held in escrow of miners
	//	OUTASSETS            string = "OutAssets"     // bucket for assets transferred out to other chains
	L2BTCPOOL   string = "L2-BTCPool"    // bucket for assets pending transfer to BTC from L2
	BTCHeight   string = "BTCHeight"     // key in BTC-L2Pool bucket for the current BTC chain height
	BTCSpendlog string = "BTC Spend Log" // key for treasuery spendings in BTC
	BTCCHAINID         = 0x400002        // BTC L2 chain id = 2,  0x400000 to indicate a base chain of L2
	REDEEMDB    string = "REDEEMDB"      // BTC L2 chain id = 2,  0x400000 to indicate a base chain of L2
	BTCTXPOOL   string = "BTCTXPOOL"
)

// MaxMessagePayload is the maximum bytes a message can be regardless of other
// individual limits imposed by messages themselves.
const MaxMessagePayload = (1024 * 1024 * 32) // 32MB

const CommandSize = 12

// ServiceFlag identifies services supported by a bitcoin peer.
type ServiceFlag uint64

// OmegaNet represents which bitcoin network a message belongs to.
type OmegaNet uint32

// BloomUpdateType specifies how the filter is updated when a match is found
type BloomUpdateType uint8

// RejectCode represents a numeric value by which a remote peer indicates
// why a message was rejected.
type RejectCode uint8

var (
	// littleEndian is a convenience variable since binary.LittleEndian is
	// quite long.
	LittleEndian = binary.LittleEndian

	// bigEndian is a convenience variable since binary.BigEndian is quite
	// long.
	BigEndian = binary.BigEndian
)

// binaryFreeList defines a concurrent safe free list of byte slices (up to the
// maximum number defined by the binaryFreeListMaxItems constant) that have a
// cap of 8 (thus it supports up to a uint64).  It is used to provide temporary
// buffers for serializing and deserializing primitive numbers to and from their
// binary encoding in order to greatly reduce the number of allocations
// required.
//
// For convenience, functions are provided for each of the primitive unsigned
// integers that automatically obtain a buffer from the free list, perform the
// necessary binary conversion, read from or write to the given io.Reader or
// io.Writer, and return the buffer to the free list.
type binaryFreeList chan []byte

// Borrow returns a byte slice from the free list with a length of 8.  A new
// buffer is allocated if there are not any available on the free list.
func (l binaryFreeList) Borrow() []byte {
	var buf []byte
	select {
	case buf = <-l:
	default:
		buf = make([]byte, 8)
	}
	return buf[:8]
}

// Return puts the provided byte slice back on the free list.  The buffer MUST
// have been obtained via the Borrow function and therefore have a cap of 8.
func (l binaryFreeList) Return(buf []byte) {
	select {
	case l <- buf:
	default:
		// Let it go to the garbage collector.
	}
}

// Uint8 reads a single byte from the provided reader using a buffer from the
// free list and returns it as a uint8.
func (l binaryFreeList) Uint8(r io.Reader) (uint8, error) {
	buf := l.Borrow()[:1]
	if _, err := io.ReadFull(r, buf); err != nil {
		l.Return(buf)
		return 0, err
	}
	rv := buf[0]
	l.Return(buf)
	return rv, nil
}

// Uint16 reads two bytes from the provided reader using a buffer from the
// free list, converts it to a number using the provided byte order, and returns
// the resulting uint16.
func (l binaryFreeList) Uint16(r io.Reader, byteOrder binary.ByteOrder) (uint16, error) {
	buf := l.Borrow()[:2]
	if _, err := io.ReadFull(r, buf); err != nil {
		l.Return(buf)
		return 0, err
	}
	rv := byteOrder.Uint16(buf)
	l.Return(buf)
	return rv, nil
}

// Uint32 reads four bytes from the provided reader using a buffer from the
// free list, converts it to a number using the provided byte order, and returns
// the resulting uint32.
func (l binaryFreeList) Uint32(r io.Reader, byteOrder binary.ByteOrder) (uint32, error) {
	buf := l.Borrow()[:4]
	if _, err := io.ReadFull(r, buf); err != nil {
		l.Return(buf)
		return 0, err
	}
	rv := byteOrder.Uint32(buf)
	l.Return(buf)
	return rv, nil
}

// Uint64 reads eight bytes from the provided reader using a buffer from the
// free list, converts it to a number using the provided byte order, and returns
// the resulting uint64.
func (l binaryFreeList) Uint64(r io.Reader, byteOrder binary.ByteOrder) (uint64, error) {
	buf := l.Borrow()[:8]
	if _, err := io.ReadFull(r, buf); err != nil {
		l.Return(buf)
		return 0, err
	}
	rv := byteOrder.Uint64(buf)
	l.Return(buf)
	return rv, nil
}

// PutUint8 copies the provided uint8 into a buffer from the free list and
// writes the resulting byte to the given writer.
func (l binaryFreeList) PutUint8(w io.Writer, val uint8) error {
	buf := l.Borrow()[:1]
	buf[0] = val
	_, err := w.Write(buf)
	l.Return(buf)
	return err
}

// PutUint16 serializes the provided uint16 using the given byte order into a
// buffer from the free list and writes the resulting two bytes to the given
// writer.
func (l binaryFreeList) PutUint16(w io.Writer, byteOrder binary.ByteOrder, val uint16) error {
	buf := l.Borrow()[:2]
	byteOrder.PutUint16(buf, val)
	_, err := w.Write(buf)
	l.Return(buf)
	return err
}

// PutUint32 serializes the provided uint32 using the given byte order into a
// buffer from the free list and writes the resulting four bytes to the given
// writer.
func (l binaryFreeList) PutUint32(w io.Writer, byteOrder binary.ByteOrder, val uint32) error {
	buf := l.Borrow()[:4]
	byteOrder.PutUint32(buf, val)
	_, err := w.Write(buf)
	l.Return(buf)
	return err
}

// PutUint64 serializes the provided uint64 using the given byte order into a
// buffer from the free list and writes the resulting eight bytes to the given
// writer.
func (l binaryFreeList) PutUint64(w io.Writer, byteOrder binary.ByteOrder, val uint64) error {
	buf := l.Borrow()[:8]
	byteOrder.PutUint64(buf, val)
	_, err := w.Write(buf)
	l.Return(buf)
	return err
}

// binarySerializer provides a free list of buffers to use for serializing and
// deserializing primitive integer values to and from io.Readers and io.Writers.
var BinarySerializer binaryFreeList = make(chan []byte, BinaryFreeListMaxItems)

// errNonCanonicalVarInt is the common format string used for non-canonically
// encoded variable length integer errors.
var errNonCanonicalVarInt = "non-canonical varint %x - discriminant %x must " +
	"encode a value greater than %x"

// uint32Time represents a unix timestamp encoded with a uint32.  It is used as
// a way to signal the readElement function how to decode a timestamp into a Go
// time.Time since it is otherwise ambiguous.
type Uint32Time time.Time

// int64Time represents a unix timestamp encoded with an int64.  It is used as
// a way to signal the readElement function how to decode a timestamp into a Go
// time.Time since it is otherwise ambiguous.
type Int64Time time.Time

// ReadElement reads the next sequence of bytes from r using little endian
// depending on the concrete type of element pointed to.
func ReadElement(r io.Reader, element interface{}) error {
	// Attempt to read the element based on the concrete type via fast
	// type assertions first.
	switch e := element.(type) {
	case *int32:
		rv, err := BinarySerializer.Uint32(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = int32(rv)
		return nil

	case *uint32:
		rv, err := BinarySerializer.Uint32(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = rv
		return nil

	case *uint8:
		rv, err := BinarySerializer.Uint8(r)
		if err != nil {
			return err
		}
		*e = rv
		return nil

	case *int64:
		rv, err := BinarySerializer.Uint64(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = int64(rv)
		return nil

	case *uint64:
		rv, err := BinarySerializer.Uint64(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = rv
		return nil

	case *bool:
		rv, err := BinarySerializer.Uint8(r)
		if err != nil {
			return err
		}
		if rv == 0x00 {
			*e = false
		} else {
			*e = true
		}
		return nil

	// Unix timestamp encoded as a uint32.
	case *Uint32Time:
		rv, err := BinarySerializer.Uint32(r, binary.LittleEndian)
		if err != nil {
			return err
		}
		*e = Uint32Time(time.Unix(int64(rv), 0))
		return nil

	// Unix timestamp encoded as an int64.
	case *Int64Time:
		rv, err := BinarySerializer.Uint64(r, binary.LittleEndian)
		if err != nil {
			return err
		}
		*e = Int64Time(time.Unix(int64(rv), 0))
		return nil

	// Message header checksum.
	case *[4]byte:
		_, err := io.ReadFull(r, e[:])
		if err != nil {
			return err
		}
		return nil

	// Message header command.
	case *[CommandSize]uint8:
		_, err := io.ReadFull(r, e[:])
		if err != nil {
			return err
		}
		return nil

	// IP address.
	case *[16]byte:
		_, err := io.ReadFull(r, e[:])
		if err != nil {
			return err
		}
		return nil

	case *chainhash.Hash:
		_, err := io.ReadFull(r, e[:])
		if err != nil {
			return err
		}
		return nil

	case *ServiceFlag:
		rv, err := BinarySerializer.Uint64(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = ServiceFlag(rv)
		return nil

	case *InvType:
		rv, err := BinarySerializer.Uint32(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = InvType(rv)
		return nil

	case *OmegaNet:
		rv, err := BinarySerializer.Uint32(r, LittleEndian)
		if err != nil {
			return err
		}
		*e = OmegaNet(rv)
		return nil

	case *BloomUpdateType:
		rv, err := BinarySerializer.Uint8(r)
		if err != nil {
			return err
		}
		*e = BloomUpdateType(rv)
		return nil

	case *RejectCode:
		rv, err := BinarySerializer.Uint8(r)
		if err != nil {
			return err
		}
		*e = RejectCode(rv)
		return nil
	}

	// Fall back to the slower binary.Read if a fast path was not available
	// above.
	return binary.Read(r, LittleEndian, element)
}

// ReadElements reads multiple items from r.  It is equivalent to multiple
// calls to readElement.
func ReadElements(r io.Reader, elements ...interface{}) error {
	for _, element := range elements {
		err := ReadElement(r, element)
		if err != nil {
			return err
		}
	}
	return nil
}

// writeElement writes the little endian representation of element to w.
func WriteElement(w io.Writer, element interface{}) error {
	// Attempt to write the element based on the concrete type via fast
	// type assertions first.
	switch e := element.(type) {
	case int32:
		err := BinarySerializer.PutUint32(w, LittleEndian, uint32(e))
		if err != nil {
			return err
		}
		return nil

	case uint32:
		err := BinarySerializer.PutUint32(w, LittleEndian, e)
		if err != nil {
			return err
		}
		return nil

	case int64:
		err := BinarySerializer.PutUint64(w, LittleEndian, uint64(e))
		if err != nil {
			return err
		}
		return nil

	case uint64:
		err := BinarySerializer.PutUint64(w, LittleEndian, e)
		if err != nil {
			return err
		}
		return nil

	case bool:
		var err error
		if e {
			err = BinarySerializer.PutUint8(w, 0x01)
		} else {
			err = BinarySerializer.PutUint8(w, 0x00)
		}
		if err != nil {
			return err
		}
		return nil

	// Message header checksum.
	case [4]byte:
		_, err := w.Write(e[:])
		if err != nil {
			return err
		}
		return nil

	// Message header command.
	case [CommandSize]uint8:
		_, err := w.Write(e[:])
		if err != nil {
			return err
		}
		return nil

	// IP address.
	case [16]byte:
		_, err := w.Write(e[:])
		if err != nil {
			return err
		}
		return nil

	case *chainhash.Hash:
		_, err := w.Write(e[:])
		if err != nil {
			return err
		}
		return nil

	case ServiceFlag:
		err := BinarySerializer.PutUint64(w, LittleEndian, uint64(e))
		if err != nil {
			return err
		}
		return nil

	case InvType:
		err := BinarySerializer.PutUint32(w, LittleEndian, uint32(e))
		if err != nil {
			return err
		}
		return nil

	case OmegaNet:
		err := BinarySerializer.PutUint32(w, LittleEndian, uint32(e))
		if err != nil {
			return err
		}
		return nil

	case BloomUpdateType:
		err := BinarySerializer.PutUint8(w, uint8(e))
		if err != nil {
			return err
		}
		return nil

	case RejectCode:
		err := BinarySerializer.PutUint8(w, uint8(e))
		if err != nil {
			return err
		}
		return nil
	}

	// Fall back to the slower binary.Write if a fast path was not available
	// above.
	return binary.Write(w, LittleEndian, element)
}

// writeElements writes multiple items to w.  It is equivalent to multiple
// calls to writeElement.
func WriteElements(w io.Writer, elements ...interface{}) error {
	for _, element := range elements {
		err := WriteElement(w, element)
		if err != nil {
			return err
		}
	}
	return nil
}

// ReadVarInt reads a variable length integer from r and returns it as a uint64.
func ReadVarInt(r io.Reader, pver uint32) (uint64, error) {
	discriminant, err := BinarySerializer.Uint8(r)
	if err != nil {
		return 0, err
	}

	var rv uint64
	switch discriminant {
	case 0xff:
		sv, err := BinarySerializer.Uint64(r, LittleEndian)
		if err != nil {
			return 0, err
		}
		rv = sv

		// The encoding is not canonical if the value could have been
		// encoded using fewer bytes.
		min := uint64(0x100000000)
		if rv < min {
			return 0, NewMessageError("ReadVarInt", fmt.Sprintf(
				errNonCanonicalVarInt, rv, discriminant, min))
		}

	case 0xfe:
		sv, err := BinarySerializer.Uint32(r, LittleEndian)
		if err != nil {
			return 0, err
		}
		rv = uint64(sv)

		// The encoding is not canonical if the value could have been
		// encoded using fewer bytes.
		min := uint64(0x10000)
		if rv < min {
			return 0, NewMessageError("ReadVarInt", fmt.Sprintf(
				errNonCanonicalVarInt, rv, discriminant, min))
		}

	case 0xfd:
		sv, err := BinarySerializer.Uint16(r, LittleEndian)
		if err != nil {
			return 0, err
		}
		rv = uint64(sv)

		// The encoding is not canonical if the value could have been
		// encoded using fewer bytes.
		min := uint64(0xfd)
		if rv < min {
			return 0, NewMessageError("ReadVarInt", fmt.Sprintf(
				errNonCanonicalVarInt, rv, discriminant, min))
		}

	default:
		rv = uint64(discriminant)
	}

	return rv, nil
}

// WriteVarInt serializes val to w using a variable number of bytes depending
// on its value.
func WriteVarInt(w io.Writer, pver uint32, val uint64) error {
	if val < 0xfd {
		return BinarySerializer.PutUint8(w, uint8(val))
	}

	if val <= math.MaxUint16 {
		err := BinarySerializer.PutUint8(w, 0xfd)
		if err != nil {
			return err
		}
		return BinarySerializer.PutUint16(w, LittleEndian, uint16(val))
	}

	if val <= math.MaxUint32 {
		err := BinarySerializer.PutUint8(w, 0xfe)
		if err != nil {
			return err
		}
		return BinarySerializer.PutUint32(w, LittleEndian, uint32(val))
	}

	err := BinarySerializer.PutUint8(w, 0xff)
	if err != nil {
		return err
	}
	return BinarySerializer.PutUint64(w, LittleEndian, val)
}

// VarIntSerializeSize returns the number of bytes it would take to serialize
// val as a variable length integer.
func VarIntSerializeSize(val uint64) int {
	// The value is small enough to be represented by itself, so it's
	// just 1 byte.
	if val < 0xfd {
		return 1
	}

	// Discriminant 1 byte plus 2 bytes for the uint16.
	if val <= math.MaxUint16 {
		return 3
	}

	// Discriminant 1 byte plus 4 bytes for the uint32.
	if val <= math.MaxUint32 {
		return 5
	}

	// Discriminant 1 byte plus 8 bytes for the uint64.
	return 9
}

// ReadVarString reads a variable length string from r and returns it as a Go
// string.  A variable length string is encoded as a variable length integer
// containing the length of the string followed by the bytes that represent the
// string itself.  An error is returned if the length is greater than the
// maximum block payload size since it helps protect against memory exhaustion
// attacks and forced panics through malformed messages.
func ReadVarString(r io.Reader, pver uint32) (string, error) {
	count, err := ReadVarInt(r, pver)
	if err != nil {
		return "", err
	}

	// Prevent variable length strings that are larger than the maximum
	// message size.  It would be possible to cause memory exhaustion and
	// panics without a sane upper bound on this count.
	if count > MaxMessagePayload {
		str := fmt.Sprintf("variable length string is too long "+
			"[count %d, max %d]", count, MaxMessagePayload)
		return "", NewMessageError("ReadVarString", str)
	}

	buf := make([]byte, count)
	_, err = io.ReadFull(r, buf)
	if err != nil {
		return "", err
	}
	return string(buf), nil
}

// WriteVarString serializes str to w as a variable length integer containing
// the length of the string followed by the bytes that represent the string
// itself.
func WriteVarString(w io.Writer, pver uint32, str string) error {
	err := WriteVarInt(w, pver, uint64(len(str)))
	if err != nil {
		return err
	}
	_, err = w.Write([]byte(str))
	return err
}

// ReadVarBytes reads a variable length byte array.  A byte array is encoded
// as a varInt containing the length of the array followed by the bytes
// themselves.  An error is returned if the length is greater than the
// passed maxAllowed parameter which helps protect against memory exhaustion
// attacks and forced panics through malformed messages.  The fieldName
// parameter is only used for the error message so it provides more context in
// the error.
func ReadVarBytes(r io.Reader, pver uint32, maxAllowed uint32,
	fieldName string) ([]byte, error) {

	count, err := ReadVarInt(r, pver)
	if err != nil {
		return nil, err
	}

	// Prevent byte array larger than the max message size.  It would
	// be possible to cause memory exhaustion and panics without a sane
	// upper bound on this count.
	if count > uint64(maxAllowed) {
		str := fmt.Sprintf("%s is larger than the max allowed size "+
			"[count %d, max %d]", fieldName, count, maxAllowed)
		return nil, NewMessageError("ReadVarBytes", str)
	}

	b := make([]byte, count)
	_, err = io.ReadFull(r, b)
	if err != nil {
		return nil, err
	}
	return b, nil
}

// WriteVarBytes serializes a variable length byte array to w as a varInt
// containing the number of bytes, followed by the bytes themselves.
func WriteVarBytes(w io.Writer, pver uint32, bytes []byte) error {
	slen := uint64(len(bytes))
	err := WriteVarInt(w, pver, slen)
	if err != nil {
		return err
	}

	_, err = w.Write(bytes)
	return err
}

// randomUint64 returns a cryptographically random uint64 value.  This
// unexported version takes a reader primarily to ensure the error paths
// can be properly tested by passing a fake reader in the tests.
func randomUint64(r io.Reader) (uint64, error) {
	rv, err := BinarySerializer.Uint64(r, BigEndian)
	if err != nil {
		return 0, err
	}
	return rv, nil
}

// RandomUint64 returns a cryptographically random uint64 value.
func RandomUint64() (uint64, error) {
	return randomUint64(rand.Reader)
}

// MessageError describes an issue with a message.
// An example of some potential issues are messages from the wrong bitcoin
// network, invalid commands, mismatched checksums, and exceeding max payloads.
//
// This provides a mechanism for the caller to type assert the error to
// differentiate between general io errors such as io.EOF and issues that
// resulted from malformed messages.
type MessageError struct {
	Func        string // Function name
	Description string // Human readable description of the issue
}

// Error satisfies the error interface and prints human-readable errors.
func (e *MessageError) Error() string {
	if e.Func != "" {
		return fmt.Sprintf("%v: %v", e.Func, e.Description)
	}
	return e.Description
}

// messageError creates an error for the given function and description.
func NewMessageError(f string, desc string) *MessageError {
	return &MessageError{Func: f, Description: desc}
}

// These constants define the various supported inventory vector types.
const (
	// InvWitnessFlag denotes that the inventory vector type is requesting,
	// or sending a version which includes witness data.
	InvWitnessFlag = 1 << 30
	InvTempFlag    = 1 << 29
)

// Map of service flags back to their constant names for pretty printing.
var ivStrings = map[InvType]string{
	InvTypeError:         "ERROR",
	InvTypeTx:            "MSG_TX",
	InvTypeBlock:         "MSG_BLOCK",
	InvTypeMinerBlock:    "MSG_MINERBLOCK",
	InvTypeFilteredBlock: "MSG_FILTERED_BLOCK",
	InvTypeWitnessBlock:  "MSG_WITNESS_BLOCK",
	InvTypeWitnessTx:     "MSG_WITNESS_TX",
	//	InvTypeFilteredWitnessBlock: "MSG_FILTERED_WITNESS_BLOCK",
}

// String returns the InvType in human-readable form.
func (invtype InvType) String() string {
	if s, ok := ivStrings[invtype]; ok {
		return s
	}

	return fmt.Sprintf("Unknown InvType (%d)", uint32(invtype))
}

// These constants define the various supported reject codes.
const (
	RejectMalformed   RejectCode = 0x01
	RejectInvalid     RejectCode = 0x10
	RejectObsolete    RejectCode = 0x11
	RejectDuplicate   RejectCode = 0x12
	RejectNonstandard RejectCode = 0x40
	//	RejectDust            RejectCode = 0x41
	RejectInsufficientFee RejectCode = 0x42
	RejectCheckpoint      RejectCode = 0x43
)

// Map of reject codes back strings for pretty printing.
var rejectCodeStrings = map[RejectCode]string{
	RejectMalformed:   "REJECT_MALFORMED",
	RejectInvalid:     "REJECT_INVALID",
	RejectObsolete:    "REJECT_OBSOLETE",
	RejectDuplicate:   "REJECT_DUPLICATE",
	RejectNonstandard: "REJECT_NONSTANDARD",
	//	RejectDust:            "REJECT_DUST",
	RejectInsufficientFee: "REJECT_INSUFFICIENTFEE",
	RejectCheckpoint:      "REJECT_CHECKPOINT",
}

// String returns the RejectCode in human-readable form.
func (code RejectCode) String() string {
	if s, ok := rejectCodeStrings[code]; ok {
		return s
	}

	return fmt.Sprintf("Unknown RejectCode (%d)", uint8(code))
}

const (
	// SFNodeNetwork is a flag used to indicate a peer is a full node.
	SFNodeNetwork ServiceFlag = 1 << iota

	// SFNodeGetUTXO is a flag used to indicate a peer supports the
	// getutxos and utxos commands (BIP0064).
	SFNodeGetUTXO

	// SFNodeBloom is a flag used to indicate a peer supports bloom
	// filtering.
	SFNodeBloom

	// SFNodeXthin is a flag used to indicate a peer supports xthin blocks.
	SFNodeXthin

	// SFNodeBit5 is a flag used to indicate a peer supports a service
	// defined by bit 5.
	SFNodeBit5

	// SFNodeCF is a flag used to indicate a peer supports committed
	// filters (CFs).
	SFNodeCF

	// SFNode2X is a flag used to indicate a peer is running the Segwit2X
	// software.
	SFNode2X
)

// Map of service flags back to their constant names for pretty printing.
var sfStrings = map[ServiceFlag]string{
	SFNodeNetwork: "SFNodeNetwork",
	SFNodeGetUTXO: "SFNodeGetUTXO",
	SFNodeBloom:   "SFNodeBloom",
	SFNodeXthin:   "SFNodeXthin",
	SFNodeBit5:    "SFNodeBit5",
	SFNodeCF:      "SFNodeCF",
	SFNode2X:      "SFNode2X",
}

// orderedSFStrings is an ordered list of service flags from highest to
// lowest.
var orderedSFStrings = []ServiceFlag{
	SFNodeNetwork,
	SFNodeGetUTXO,
	SFNodeBloom,
	SFNodeXthin,
	SFNodeBit5,
	SFNodeCF,
	SFNode2X,
}

// String returns the ServiceFlag in human-readable form.
func (f ServiceFlag) String() string {
	// No flags are set.
	if f == 0 {
		return "0x0"
	}

	// Add individual bit flags.
	s := ""
	for _, flag := range orderedSFStrings {
		if f&flag == flag {
			s += sfStrings[flag] + "|"
			f -= flag
		}
	}

	// Add any remaining flags which aren't accounted for as hex.
	s = strings.TrimRight(s, "|")
	if f != 0 {
		s += "|0x" + strconv.FormatUint(uint64(f), 16)
	}
	s = strings.TrimLeft(s, "|")
	return s
}

// Constants used to indicate the message network.  They can also be
// used to seek to the next message when a stream's state is unknown, but
// this package does not provide that functionality since it's generally a
// better idea to simply disconnect clients that are misbehaving over TCP.
const (
	// MainNet represents the main bitcoin network.
	MainNet OmegaNet = 0xA117FE3D // 956ca366

	// RegNet represents the regression test network.
	RegNet OmegaNet = 0x7D7A63ED // 6241456c

	// TestNet represents the test network.
	TestNet OmegaNet = 0xD4FBED56 // 709c5fed

	// SimNet represents the simulation test network.
	SimNet OmegaNet = 0xFCC0C9C4 // e10b70ad
)

// bnStrings is a map of omega networks back to their constant names for
// pretty printing.
var bnStrings = map[OmegaNet]string{
	MainNet: "BTCL2Main",
	RegNet:  "BTCL2Reg",
	TestNet: "BTCL2Test",
	SimNet:  "BTCL2Sim",
}

// String returns the OmegaNet in human-readable form.
func (n OmegaNet) String() string {
	if s, ok := bnStrings[n]; ok {
		return s
	}

	return fmt.Sprintf("Unknown OmegaNet (%d)", uint32(n))
}

type MsgXrossL2 struct {
	Utxo     wire.OutPoint
	Value    int64
	PkScript []byte
	Redeem   []byte
}

func (t *MsgXrossL2) Serialize() []byte {
	res := make([]byte, 52, 100)
	copy(res, t.Utxo.Hash[:])
	LittleEndian.PutUint32(res[32:], t.Utxo.Index)
	LittleEndian.PutUint64(res[36:], uint64(t.Value))
	LittleEndian.PutUint32(res[44:], uint32(len(t.PkScript)))
	LittleEndian.PutUint32(res[48:], uint32(len(t.Redeem)))

	res = append(res, t.PkScript...)
	res = append(res, t.Redeem...)
	return res
}

func (t *MsgXrossL2) UnSerialize(d []byte) (int, error) {
	copy(t.Utxo.Hash[:], d)
	t.Utxo.Index = LittleEndian.Uint32(d[32:])
	t.Value = int64(LittleEndian.Uint64(d[36:]))
	m := LittleEndian.Uint32(d[44:])
	n := LittleEndian.Uint32(d[48:])

	t.PkScript = d[52 : 52+m]
	t.Redeem = d[52+m : 52+m+n]

	return int(52 + m + n), nil
}

func XrossL2(utxo *wire.OutPoint, Value int64, PkScript []byte) *MsgXrossL2 {
	return &MsgXrossL2{
		Utxo:     *utxo,
		Value:    Value,
		PkScript: PkScript,
	}
}

type BTCL2Data struct {
	Hash   chainhash.Hash
	Height int32
	Txs    []*MsgXrossL2
}

func (t *BTCL2Data) Serialize() []byte {
	var w bytes.Buffer
	w.Write(t.Hash[:])

	var h [4]byte
	LittleEndian.PutUint32(h[:], uint32(t.Height))
	w.Write(h[:])

	if t.Txs == nil || len(t.Txs) == 0 {
		LittleEndian.PutUint32(h[:], 0)
		w.Write(h[:])
		return w.Bytes()
	}

	LittleEndian.PutUint32(h[:], uint32(len(t.Txs)))
	w.Write(h[:])

	for _, txo := range t.Txs {
		var v [8]byte

		_ = WriteElements(&w, &txo.Utxo.Hash, txo.Utxo.Index)

		LittleEndian.PutUint64(v[:], uint64(txo.Value))
		w.Write(v[:])

		LittleEndian.PutUint32(h[:], uint32(len(txo.PkScript)))
		w.Write(h[:])
		w.Write(txo.PkScript)

		LittleEndian.PutUint32(h[:], uint32(len(txo.Redeem)))
		w.Write(h[:])
		w.Write(txo.Redeem)
	}
	return w.Bytes()
}

func (t *BTCL2Data) Unserialize(buf []byte) error {
	m := len(buf)

	if m < 40 {
		return fmt.Errorf("Insufficient data")
	}

	copy(t.Hash[:], buf)

	t.Height = int32(LittleEndian.Uint32(buf[32:36]))

	h := LittleEndian.Uint32(buf[36:40])
	if h == 0 {
		t.Txs = nil
		return nil
	}

	n := 40
	t.Txs = make([]*MsgXrossL2, h)

	for i := 0; i < int(h); i++ {
		t.Txs[i] = &MsgXrossL2{}
	}

	for _, txo := range t.Txs {
		if m < n+48 {
			return fmt.Errorf("Insufficient data")
		}

		copy(txo.Utxo.Hash[:], buf[n:n+32])
		n += 32
		txo.Utxo.Index = LittleEndian.Uint32(buf[n : n+4])
		n += 4

		txo.Value = int64(LittleEndian.Uint64(buf[n : n+8]))
		n += 8

		h := LittleEndian.Uint32(buf[n : n+4])
		n += 4

		if m < n+int(h) {
			return fmt.Errorf("Insufficient data")
		}

		txo.PkScript = make([]byte, h)
		copy(txo.PkScript, buf[n:n+int(h)])
		n += int(h)

		h = LittleEndian.Uint32(buf[n : n+4])
		n += 4

		txo.Redeem = make([]byte, h)
		copy(txo.Redeem, buf[n:n+int(h)])
		n += int(h)
	}
	return nil
}

func Absint32(v int32) int32 {
	if v < 0 {
		return -v
	}
	return v
}

func Absint64(v int64) int64 {
	if v < 0 {
		return -v
	}
	return v
}
