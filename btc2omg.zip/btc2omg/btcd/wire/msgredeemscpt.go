// Copyright (c) 2013-2015 The btcsuite developers
// Copyright (c) 2018-2024 The Omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package wire

import (
	"github.com/btcsuite/btcd/btc2omg/btcd/wire/common"
	"io"
)

// MsgRedeemScpt implements the Message interface and represents a redeem script
// message.
type MsgRedeemScpt struct {
	Address string // address of redeem script
	Script  []byte // redeem script, if nil, it is a request for redeem script
}

// OmcDecode decodes r using the bitcoin protocol encoding into the receiver.
// This is part of the Message interface implementation.
func (msg *MsgRedeemScpt) OmcDecode(r io.Reader, pver uint32, enc MessageEncoding) error {
	s, err := common.ReadVarString(r, pver)
	msg.Address = s
	if err != nil {
		return err
	}

	b, err := common.ReadVarBytes(r, pver, 34*20+2, "Script")
	if err != nil {
		return err
	}
	if b == nil || len(b) == 0 {
		msg.Script = nil
	} else {
		msg.Script = b
	}

	return nil
}

// OmcEncode encodes the receiver to w using the bitcoin protocol encoding.
// This is part of the Message interface implementation.
func (msg *MsgRedeemScpt) OmcEncode(w io.Writer, pver uint32, enc MessageEncoding) error {
	err := common.WriteVarString(w, pver, msg.Address)
	if err != nil {
		return err
	}

	return common.WriteVarBytes(w, pver, msg.Script)
}

// Command returns the protocol command string for the message.  This is part
// of the Message interface implementation.
func (msg *MsgRedeemScpt) Command() string {
	return CmdRedeemScpt
}

// MaxPayloadLength returns the maximum length the payload can be for the
// receiver.  This is part of the Message interface implementation.
func (msg *MsgRedeemScpt) MaxPayloadLength(pver uint32) uint32 {
	// Num inventory vectors (varInt) + max allowed inventory vectors.
	return 66 + 34*20
}

// NewMsgRedeemScpt returns a new bitcoin MsgRedeemScpt message that conforms to the
// Message interface.  See MsgRedeemScpt for details.
func NewMsgRedeemScpt(addr string) *MsgRedeemScpt {
	return &MsgRedeemScpt{
		Address: addr,
		Script:  nil,
	}
}

// NewMsgGetDataSizeHint returns a new bitcoin MsgRedeemScpt message that conforms to
// the Message interface.  See MsgGetData for details.
func NewMsgRedeemScptSizeHint(sizeHint uint) *MsgRedeemScpt {
	return &MsgRedeemScpt{
		Address: "",
		Script:  nil,
	}
}
