// Copyright (c) 2024-2024 The Omegasuite developers
// Use of this source code is governed by applicable
// patent laws.

package treasury

import (
	"bytes"
	"crypto/sha256"
	"fmt"
	"github.com/btcsuite/btcd/btc2omg/btcd/database"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire/common"
	"github.com/btcsuite/btcd/btc2omg/omega/ovm"
	"github.com/btcsuite/btcd/btcec"
	"github.com/btcsuite/btcd/btcutil"
	"github.com/btcsuite/btcd/txscript"
	"sort"
)

var PrivKeys []*btcec.PrivateKey

type PlgAsset struct {
	Utxo     wire.OutPoint
	Amount   uint64
	Firstuse uint32 // height when it becomes a signer
}

func (p *PlgAsset) serialize() []byte {
	var res []byte

	res = make([]byte, 48)
	copy(res, p.Utxo.ToBytes())
	common.LittleEndian.PutUint64(res[36:], p.Amount)
	common.LittleEndian.PutUint32(res[44:], p.Firstuse)

	return res[:]
}

func (p *PlgAsset) deserialize(d []byte) (int, error) {
	if len(d) < 36+4 {
		return 0, fmt.Errorf("Insufficient asset data")
	}
	f := 0
	if len(d) < 48 {
		f++
	}
	p.Utxo.Hash.SetBytes(d[f : f+32])
	p.Utxo.Index = common.LittleEndian.Uint32(d[f+32 : f+36])
	p.Amount = common.LittleEndian.Uint64(d[f+36:])
	if len(d) >= 48 {
		p.Firstuse = common.LittleEndian.Uint32(d[f+44:])
		return 48, nil
	}

	return 1 + 36 + 8, nil
}

type Signers struct {
	Address   [20]byte    // Address of signer
	Pubkey    []byte      // Pubkey of signer
	Voting    uint8       // Voting power in %
	Retiring  bool        // whether is Retiring
	Joined    uint32      // height when it becomes a signer
	Pledged   []*PlgAsset // Assets Pledged
	Btcprofit uint64      // profits in BTC
}

func (s *Signers) serialize() []byte {
	res := make([]byte, 8)
	res[0] = 0
	if s.Retiring {
		res[0] = 1
	}
	res[1] = s.Voting
	common.LittleEndian.PutUint32(res[2:], s.Joined)
	res[6] = uint8(len(s.Pubkey))

	res[7] = uint8(len(s.Pledged))
	res = append(res, s.Pubkey...)
	for _, plg := range s.Pledged {
		res = append(res, plg.serialize()...)
	}

	var h [8]byte
	common.LittleEndian.PutUint64(h[:], s.Btcprofit)
	res = append(res, h[:]...)

	return res
}

func (s *Signers) Deserialize(p []byte) (int, error) {
	if p[0] == 0 {
		s.Retiring = false
	} else {
		s.Retiring = true
	}
	s.Voting = p[1]
	s.Joined = common.LittleEndian.Uint32(p[2:])
	s.Pubkey = make([]byte, p[6])
	if p[6] == 20 { // tmp code
		return 6, fmt.Errorf("error")
	}
	d := p[7]
	copy(s.Pubkey, p[8:8+p[6]])
	n := int(8 + p[6])
	for i := 0; i < int(d); i++ {
		plg := &PlgAsset{}
		m, err := plg.deserialize(p[n:])
		if err != nil {
			return n, err
		}
		n += m
		s.Pledged = append(s.Pledged, plg)
	}

	s.Btcprofit = 0
	if n < len(p) {
		s.Btcprofit = common.LittleEndian.Uint64(p[n:])
		n += 8
	}
	return n, nil
}

func IsPledged(u *wire.OutPoint) bool {
	return collaterals.Exists(u)
}

func IsEldest(miner []byte) bool {
	return bytes.Compare(eldest.Address[:], miner[:]) == 0 && len(miner) == 20
}
func Declared(miner [20]byte) bool {
	_, ok := signers[miner]
	return ok
}

func Declare(dbTx database.Tx, miner [20]byte, pubkey []byte, height uint32) {
	if _, ok := signers[miner]; ok {
		return
	}

	sn := &Signers{
		Retiring: false,
		Address:  miner,
		Joined:   height,
		Pledged:  []*PlgAsset{},
	}

	sn.Pubkey = make([]byte, len(pubkey))
	copy(sn.Pubkey, pubkey)
	if len(signers) == 0 {
		eldest = sn
	}
	signers[miner] = sn

	bucket := dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
	bucket.Put(miner[:], sn.serialize())
}

func UnDeclare(dbTx database.Tx, miner [20]byte) {
	if sn, ok := signers[miner]; !ok {
		return
	} else {
		if eldest == sn {
			return
		}

		delete(signers, miner)

		bucket := dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
		bucket.Delete(miner[:])
	}
}

func UnPledge(dbTx database.Tx, u *wire.OutPoint, miner [20]byte) error {
	sn, ok := signers[miner]
	if !ok {
		return fmt.Errorf("Pledge before declaration")
	}

	has := false
	var amount int64
	for i, p := range sn.Pledged {
		if u.Equal(&p.Utxo) {
			has = true
			amount = int64(p.Amount)
			sn.Pledged = append(sn.Pledged[:i], sn.Pledged[i+1:]...)
			break
		}
	}
	if !has {
		return nil
	}

	totalOmg -= uint64(amount)
	collaterals.Delete(u)

	bucket := dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
	for w, s := range signers {
		s.Voting = VotingPower(w)
		bucket.Put(w[:], s.serialize())
	}
	return nil
}

func Pledge(dbTx database.Tx, u *wire.OutPoint, miner [20]byte, amount int64, height uint32) error {
	sn, ok := signers[miner]
	if !ok {
		return fmt.Errorf("Pledge before declaration")
	}

	for _, p := range sn.Pledged {
		if u.Equal(&p.Utxo) {
			return nil
		}
	}

	plg := &PlgAsset{
		Utxo:     *u,
		Amount:   uint64(amount),
		Firstuse: height,
	}

	totalOmg += plg.Amount

	collaterals.Add(u)
	sn.Pledged = append(sn.Pledged, plg)

	bucket := dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
	for w, s := range signers {
		s.Voting = VotingPower(w)
		bucket.Put(w[:], s.serialize())
	}
	return nil
}

func VotingPower(owner [20]byte) uint8 {
	s, ok := signers[owner]
	if !ok {
		return 0
	}
	if s.Retiring {
		return 0
	}
	omgs := uint64(0)
	for _, t := range s.Pledged {
		omgs += t.Amount
	}
	p := uint32(omgs) * 10000 / uint32(totalOmg)
	return uint8(p / 100)
}

func IsMatching(script []byte) bool {
	return len(script) == 34 && script[0] == 0 && script[1] == txscript.OP_DATA_32
}

/*
func Matching(script []byte) int32 {
	return isMatching(script)
}
*/

func GetMSScript(dest [20]byte) ([]byte, []byte, []byte, [][20]byte) {
	// MS Address, MS redeem script, Pkscript, addresses involved
	if eldest == nil {
		return nil, nil, nil, nil
	}

	n := 1
	addrs := make([][20]byte, 0, 4)
	pubkeys := make([]*btcutil.AddressPubKey, 0)

	k, _ := btcutil.NewAddressPubKey(eldest.Pubkey, BTCParams) // txsparser.BTCParams)
	pubkeys = append(pubkeys, k)
	addrs = append(addrs, eldest.Address)

	src := signers
	if len(signers) > txscript.MaxPubKeysPerMultiSig {
		f := make([]*Signers, 0, len(signers))
		i := 0
		for _, s := range signers {
			if s.Retiring {
				continue
			}
			f = append(f, s)
			i++
		}
		sort.Slice(f, func(i, j int) bool {
			return f[i].Voting > f[j].Voting
		})
		src = make(map[[20]byte]*Signers)
		if len(f) > txscript.MaxPubKeysPerMultiSig {
			f = f[:txscript.MaxPubKeysPerMultiSig]
		}
		for _, s := range f {
			src[s.Address] = s
		}
	}

	for _, s := range src {
		if s.Retiring || s == eldest {
			continue
		}
		addrs = append(addrs, s.Address)
		n++
		k, _ := btcutil.NewAddressPubKey(s.Pubkey, BTCParams) // txsparser.BTCParams)
		pubkeys = append(pubkeys, k)
	}

	if n < 2 {
		return nil, nil, nil, nil
	}
	req := (n*3 + 3) / 4

	rms, _ := txscript.MultiSigScript(pubkeys, req)

	hash := btcutil.Hash160(rms)

	builder := txscript.NewScriptBuilder()
	// This check signature of the eldest
	builder.AddOp(txscript.OP_DUP).AddOp(txscript.OP_HASH160).AddData(hash).
		AddOp(txscript.OP_EQUALVERIFY).AddOp(txscript.OP_CHECKMULTISIG)
	pks, _ := builder.Script()

	return hash, rms, pks, addrs
}

/*
func isMatching(script []byte) int32 {
	// check if it is a transaction that transfers asset to Layer 2
	// 1. To a designated MS Address holding Bitcoins for bridge

	if len(script) < 26 {
		return -1
	}

	m := script[0] - (txscript.OP_1 - 1)
	p, pm := 1, true
	for p < len(script)-2 {
		if !pm {
			return -1
		}
		if script[p] != btcec.PubKeyBytesLenCompressed {
			return -1
		}

		if p+1+btcec.PubKeyBytesLenCompressed >= len(script) {
			return -1
		}

		key := script[p+1 : p+1+btcec.PubKeyBytesLenCompressed]
		p += btcec.PubKeyBytesLenCompressed + 1

		pm = false

		for _, s := range signers {
			if bytes.Compare(s.Pubkey, key) == 0 {
				pm = true
				break
			}
		}
	}
	if p+2 != len(script) {
		return -1
	}
	n := script[p] - (txscript.OP_1 - 1)
	if m > n {
		return -1
	}
	if script[p+1] == byte(txscript.OP_CHECKMULTISIG) {
		return 0
	}
	return -1
}
*/

func RecoverBTCScript(tx database.Tx, script []byte) ([]byte, bool) { // convert to omg script
	address, err := btcutil.NewAddressWitnessScriptHash(script[2:], BTCParams)
	if err != nil {
		return nil, false
	}

	addressBech32 := address.EncodeAddress()

	bucket := tx.Metadata().Bucket([]byte(common.REDEEMDB))
	rdm := bucket.Get([]byte(addressBech32))
	if rdm == nil || len(rdm) < 10 {
		Server.GetRedeemScript(&wire.MsgRedeemScpt{Address: addressBech32, Script: nil})
		return script, false
	}

	res := []byte{0}
	res = append(res, rdm[len(rdm)-34:len(rdm)-14]...)
	res = append(res, []byte{ovm.OP_PAY2PKH, 0, 0, 0}...)

	return res, true
}

/*
func OnNewRedeemScript(tx database.Tx, msg *wire.MsgRedeemScpt) {
	bucket := tx.Metadata().Bucket([]byte(common.BTCL2POOL))
	address, _ := btcutil.DecodeAddress(msg.Address, BTCParams)
	if address == nil {
		return
	}
	key := address.ScriptAddress()

	txs := bucket.Get(key)
	if txs == nil || len(txs) == 0 {
		return
	}
	bucket2 := tx.Metadata().Bucket([]byte(common.INCOMINGPOOL))
	for i := 0; i < len(txs); {
		n := common.LittleEndian.Uint32(txs[i:])
		buf := txs[i : i+int(n)]
		i += 4 + int(n)
		xchain := &wire.XchainData{}
		xchain.DeSerialize(buf)

		scp, ok := RecoverBTCScript(tx, xchain.Txs[0].Txo.PkScript)
		if scp == nil {
			continue
		}

		if ok {
			xchain.Txs[0].Txo.PkScript = scp
			var k [36]byte
			copy(k[:], xchain.Hash[:])
			common.LittleEndian.PutUint32(k[32:], uint32(xchain.ChainID|wire.CrossChainFalg))
			bucket2.Put(k[:], xchain.Serialize())
		}
	}
	bucket.Delete(key)
}
*/

func matchsigners(script []byte) (bool, []byte, []*Signers, byte) {
	// check if it is a transaction that transfers asset to Layer 2
	// 1. To a designated MS Address holding Bitcoins for bridge

	if len(script) < 33 {
		return false, nil, nil, 0
	}

	sig := make([]*Signers, 0)

	m := script[0] - (txscript.OP_1 - 1)
	p := 1
	last := []byte{}
	for p < len(script)-2 {
		if script[p] != btcec.PubKeyBytesLenCompressed {
			return false, nil, nil, 0
		}
		key := script[p+1 : p+1+btcec.PubKeyBytesLenCompressed]
		for _, s := range signers {
			if bytes.Compare(s.Pubkey, key) == 0 {
				sig = append(sig, s)
				break
			}
		}
		last = script[p+1 : p+21]
		p += 1 + btcec.PubKeyBytesLenCompressed
	}
	return true, last, sig, m
}

func Get75pctMSScript(dest [20]byte) (string, []byte, [][20]byte) {
	// TBD: for now, we use straight multi-sig script. in the future, we will switch to
	// Taproot. We will make one master key as controling and the rest as m-in-n
	// now, we just make the master key appear in a m+1 in n+1 multi-sig script

	// Pkscript and signers
	// get a BTC multi-signature Pkscript
	// the signature required by the script is:
	// signature of the eldest AND 75% of all other signers
	// if dest is a 20-byte hash, the script is for a BTC-L2 transfer
	// if dest is a Pubkey of a signer, it is meant to pledge asset
	if eldest == nil {
		return "", nil, nil
	}

	n := 0
	addrs := make([][20]byte, 0, 4)
	pubkeys := make([]*btcutil.AddressPubKey, 0)

	addrs = append(addrs, eldest.Address)

	for _, s := range signers {
		if s.Retiring || s == eldest {
			continue
		}
		if txscript.MaxPubKeysPerMultiSig == n+2 {
			break
		}
		addrs = append(addrs, s.Address)
		n++
		k, _ := btcutil.NewAddressPubKey(s.Pubkey, BTCParams) // txsparser.BTCParams)
		pubkeys = append(pubkeys, k)
	}
	/*
		if n < 2 {
			return nil, nil
		}
	*/
	req := (n*3 + 3) / 4

	req++
	k, _ := btcutil.NewAddressPubKey(eldest.Pubkey, BTCParams) // txsparser.BTCParams)
	pubkeys = append(pubkeys, k)

	builder := txscript.NewScriptBuilder()

	var header [1]byte
	header[0] = 0x0a
	builder.AddOps(header[:])

	builder.AddInt64(int64(req))
	for _, key := range pubkeys {
		builder.AddData(key.ScriptAddress())
	}

	var fakeaddraspubkey [33]byte
	fakeaddraspubkey[0] = 0x02
	copy(fakeaddraspubkey[1:], dest[:])

	builder.AddData(fakeaddraspubkey[:])

	builder.AddInt64(int64(len(pubkeys) + 1))
	builder.AddOp(txscript.OP_CHECKMULTISIG)

	a, _ := builder.Script()

	//	fmt.Println(a)
	witnessadress, _ := RedeemScriptToP2WSH(a[1:])
	if witnessadress == nil {
		return "", nil, nil
	}
	addressBech32 := witnessadress.EncodeAddress()

	mydb.Update(func(tx database.Tx) error {
		bucket := tx.Metadata().Bucket([]byte(common.REDEEMDB))
		bucket.Put([]byte(addressBech32), a)
		return nil
	})
	Server.GetRedeemScript(&wire.MsgRedeemScpt{
		Address: addressBech32,
		Script:  a,
	})

	return addressBech32, a, addrs

	//	rms, _ := txscript.MultiSigScript(pubkeys, req)
	//	rms[len(rms)-1] = txscript.OP_CHECKSIGVERIFY

	// This check signature of the eldest
	//	a, _ := txscript.NewScriptBuilder().AddOp(txscript.OP_DUP).AddOp(txscript.OP_NOTIF).AddOp(txscript.OP_RETURN).AddData(dest[:]).AddOp(txscript.OP_ENDIF).Script()

	//	builder := txscript.NewScriptBuilder()
	// This check signature of the eldest
	//	builder.AddOp(txscript.OP_DUP).AddOp(txscript.OP_HASH160).AddData(eldest.Address[:]).
	//		AddOp(txscript.OP_EQUALVERIFY).AddOp(txscript.OP_CHECKSIGVERIFY).AddOp(txscript.OP_DUP).AddOp(txscript.OP_NOTIF).AddOp(txscript.OP_RETURN).AddData(dest[:]).AddOp(txscript.OP_ENDIF)

	//	pks, _ := builder.Script()
	//	pks = append(pks, rms...)
	//	a, _ := txscript.NewScriptBuilder().AddOp(txscript.OP_DUP).AddOp(txscript.OP_NOTIF).AddOp(txscript.OP_RETURN).AddData(dest[:]).AddOp(txscript.OP_ENDIF).Script()
	//	pks = append(pks, a...)

	//	return rms, addrs
}

func RedeemScriptToP2WSH(pkScript []byte) (*btcutil.AddressWitnessScriptHash, error) {
	shaHash := sha256.Sum256(pkScript)

	address, err := btcutil.NewAddressWitnessScriptHash(shaHash[:], BTCParams)
	if err != nil {
		return nil, err
	}

	//	addressBech32 := address.EncodeAddress()

	return address, nil
}

func Create75pctMSScript(dest [20]byte) ([]byte, [][20]byte) {

	if eldest == nil {
		return nil, nil
	}

	n := 0
	addrs := make([][20]byte, 0, 4)
	pubkeys := make([]*btcutil.AddressPubKey, 0)

	addrs = append(addrs, eldest.Address)

	for _, s := range signers {
		if s.Retiring || s == eldest {
			continue
		}
		if txscript.MaxPubKeysPerMultiSig == n {
			continue
		}
		addrs = append(addrs, s.Address)
		n++
		k, _ := btcutil.NewAddressPubKey(s.Pubkey, BTCParams) // txsparser.BTCParams)
		pubkeys = append(pubkeys, k)
		break // std ms script allows no more than 3 pubkeys, and we need one to fake dest
	}

	req := (n*3 + 3) / 4

	req++
	k, _ := btcutil.NewAddressPubKey(eldest.Pubkey, BTCParams) // txsparser.BTCParams)
	pubkeys = append(pubkeys, k)

	builder := txscript.NewScriptBuilder()
	builder.AddOp(txscript.OP_1 - 1 + byte(req)) // 添加 OP_M

	for _, key := range pubkeys {
		builder.AddData(key.ScriptAddress())
	}

	var fakeaddraspubkey [33]byte
	fakeaddraspubkey[0] = 0x02
	copy(fakeaddraspubkey[1:], dest[:])

	builder.AddData(fakeaddraspubkey[:])
	builder.AddOp(txscript.OP_1 - 1 + byte(len(pubkeys)+1)) // 添加 OP_M
	builder.AddOp(txscript.OP_CHECKMULTISIG)

	a, _ := builder.Script()
	return a, addrs
}

func PlantoRetire(dbTx database.Tx, who [20]byte) {
	s, ok := signers[who]
	if !ok || s.Retiring {
		return
	}
	s.Retiring = true
	bucket := dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
	bucket.Put(who[:], s.serialize())

	if s == eldest {
		eldest = nil
		for _, s := range signers {
			if s.Retiring {
				continue
			}
			if eldest == nil || s.Joined < eldest.Joined {
				eldest = s
			}
		}
	}
}

func UnPlantoRetire(dbTx database.Tx, who [20]byte) {
	s, ok := signers[who]
	if !ok || !s.Retiring {
		return
	}
	s.Retiring = false
	mydb.Update(func(tx database.Tx) error {
		bucket := tx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
		bucket.Put(who[:], s.serialize())
		return nil
	})
}

func Retire(dbTx database.Tx, who [20]byte, height uint32) {
	if !MayRetire(who) {
		return
	}
	s := signers[who]
	for _, p := range s.Pledged {
		collaterals.Delete(&p.Utxo)
		totalOmg -= p.Amount
	}
	delete(signers, who)

	bucket := dbTx.Metadata().Bucket([]byte(common.RetiredBRIDGESIGNERS))
	var h [28]byte
	common.LittleEndian.PutUint32(h[:], height)
	copy(h[4:], who[:])
	bucket.Put(h[:], s.serialize())

	bucket = dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
	bucket.Delete(who[:])
	for w, s := range signers {
		s.Voting = VotingPower(w)
		bucket.Put(w[:], s.serialize())
	}
}

func UnRetire(dbTx database.Tx, who [20]byte, height uint32) {
	_, ok := signers[who]
	if ok {
		return
	}

	bucket := dbTx.Metadata().Bucket([]byte(common.RetiredBRIDGESIGNERS))
	var h [28]byte
	common.LittleEndian.PutUint32(h[:], height)
	copy(h[4:], who[:])
	d := bucket.Get(h[:])

	sn := &Signers{}
	sn.Deserialize(d)
	signers[sn.Address] = sn
	for _, p := range sn.Pledged {
		collaterals.Add(&p.Utxo)
		totalOmg += p.Amount
	}

	bucket.Delete(h[:])

	bucket = dbTx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
	for w, s := range signers {
		s.Voting = VotingPower(w)
		bucket.Put(w[:], s.serialize())
	}
}

func Withdraw(u *wire.OutPoint) error {
done:
	for k, s := range signers {
		for i, p := range s.Pledged {
			if p.Utxo.Hash.IsEqual(&u.Hash) && p.Utxo.Index == u.Index {
				totalOmg -= p.Amount
				if len(s.Pledged) == 1 {
					mydb.Update(func(tx database.Tx) error {
						bucket := tx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
						bucket.Delete(k[:])
						return nil
					})
					delete(signers, k)
					break done
				}
				if i == len(s.Pledged)-1 {
					s.Pledged = s.Pledged[:i]
				} else if i == 0 {
					s.Pledged = s.Pledged[1:]
				} else {
					s.Pledged = append(s.Pledged[:i], s.Pledged[i+1:]...)
				}
				mydb.Update(func(tx database.Tx) error {
					bucket := tx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
					v := make([]byte, 0)
					for _, plg := range s.Pledged {
						v = append(v, plg.serialize()...)
					}
					bucket.Put(k[:], v)
					return nil
				})
				break done
			}
		}
	}

	collaterals.Delete(u)

	return nil
}
