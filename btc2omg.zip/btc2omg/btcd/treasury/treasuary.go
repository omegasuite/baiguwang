// Copyright (c) 2024-2024 The Omegasuite developers
// Use of this source code is governed by applicable
// patent laws.

package treasury

import (
	"bytes"
	"crypto/ecdsa"
	"encoding/hex"
	"fmt"
	"github.com/btcsuite/btcd/btc2omg/btcd/btcec"
	l2param "github.com/btcsuite/btcd/btc2omg/btcd/chaincfg"
	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg/chainhash"
	"github.com/btcsuite/btcd/btc2omg/btcd/database"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire/common"
	l2btcutil "github.com/btcsuite/btcd/btc2omg/btcutil"
	btcec2 "github.com/btcsuite/btcd/btcec"
	btcecedcsa "github.com/btcsuite/btcd/btcec/v2/ecdsa"
	"github.com/btcsuite/btcd/btcutil"
	"github.com/btcsuite/btcd/chaincfg"
	bhash "github.com/btcsuite/btcd/chaincfg/chainhash"
	"github.com/btcsuite/btcd/mempool"
	"github.com/btcsuite/btcd/txscript"
	btcwire "github.com/btcsuite/btcd/wire"
	"sort"
)

// here we record all assets trusted to us in BTC including those in collateral
type RPC interface {
	DoSendRawTransaction(tx *btcutil.Tx) (interface{}, error)
}

var Rpc RPC
var BTCMempool mempool.TxMempool
var BTCParams *chaincfg.Params
var ActiveNetParams *l2param.Params

type Fetcher struct {
	utxoMap map[btcwire.OutPoint]*btcwire.TxOut // 模拟一个 UTXO 集合
}

const (
	BITCOIN   = string("Bitcoin")
	feepolicy = int64(40)
)

func (f *Fetcher) FetchPrevOutput(outpoint btcwire.OutPoint) *btcwire.TxOut {
	if txOut, ok := f.utxoMap[outpoint]; ok {
		return txOut
	}
	return nil // 如果找不到对应的前置输出，返回 nil
}

func createFetcher(asset Asset) *Fetcher {
	utxoMap := make(map[btcwire.OutPoint]*btcwire.TxOut)

	// 将 asset.Outpoint 对应的前置输出（TxOut）添加到 UTXO 集合中
	utxoMap[asset.Outpoint] = &btcwire.TxOut{
		Value:    int64(asset.Amount), // 前置输出的金额
		PkScript: asset.Pkscript,      // 前置输出的公钥脚本
	}

	return &Fetcher{utxoMap: utxoMap}
}

type Asset struct {
	Amount   uint64 //
	Outpoint btcwire.OutPoint
	// Locked in32		// time locked, will release after 1 day
	Owners   [][20]byte // signatures required
	Pkscript []byte
}

func (p *Asset) serialize() []byte {
	res := make([]byte, 49)
	common.LittleEndian.PutUint64(res[:], p.Amount)
	copy(res[8:], p.Outpoint.Hash[:])
	common.LittleEndian.PutUint32(res[40:], p.Outpoint.Index)

	//	common.LittleEndian.PutUint16(res[44:], uint32(p.Locked))
	//	common.LittleEndian.PutUint16(res[48:], uint16(len(p.Owners)*20))
	//	common.LittleEndian.PutUint16(res[50:], uint16(len(p.Pkscript)))

	common.LittleEndian.PutUint16(res[44:], uint16(len(p.Owners)*20))
	common.LittleEndian.PutUint16(res[46:], uint16(len(p.Pkscript)))

	for _, own := range p.Owners {
		res = append(res, own[:]...)
	}

	res = append(res, p.Pkscript...)
	return res
}

func (p *Asset) Deserialize(d []byte) (int, error) {
	if len(d) < 76 {
		return 0, fmt.Errorf("Insufficient asset data")
	}
	p.Amount = common.LittleEndian.Uint64(d[:])
	copy(p.Outpoint.Hash[:], d[8:])
	p.Outpoint.Index = common.LittleEndian.Uint32(d[40:])

	//	p.Locked := common.LittleEndian.Uint32(d[44:])
	//	n := common.LittleEndian.Uint16(d[48:])
	//	m := common.LittleEndian.Uint16(d[50:])
	//	k := 52

	n := common.LittleEndian.Uint16(d[44:])
	m := common.LittleEndian.Uint16(d[46:])
	k := 48

	if n == 0 {
		p.Owners = nil
	} else {
		p.Owners = make([][20]byte, n/20)
		for i, _ := range p.Owners {
			copy(p.Owners[i][:], d[k:])
			k += 20
		}
	}
	p.Pkscript = make([]byte, m)
	copy(p.Pkscript, d[k:])

	return k + int(m), nil
}

type server interface {
	SolicitSigs(tx *btcwire.MsgTx, hash *chainhash.Hash, height uint32)
	GetTxBlock(h int32) *l2btcutil.Block
	GetRedeemScript(scpt *wire.MsgRedeemScpt)
}

var treasury map[wire.OutPoint]*Asset
var signers map[[20]byte]*Signers
var mydb database.DB
var totalOmg uint64
var collaterals *wire.Collaterals
var eldest *Signers
var Server server

func BuildTx(dbtx database.Tx, sendto []*btcwire.TxOut) *btcwire.MsgTx {
	total, fee := int64(0), int64(10000)

	tx := &btcwire.MsgTx{
		Version:  1,
		TxIn:     []*btcwire.TxIn{},
		TxOut:    []*btcwire.TxOut{},
		LockTime: 0,
	}
	for _, txo := range sendto {
		fee += 1000
		total += txo.Value
		tx.TxOut = append(tx.TxOut, txo)
	}
	assets := make([]*Asset, len(treasury))
	i := 0
	for _, t := range treasury {
		assets[i] = t
		i++
	}
	sort.Slice(assets, func(i int, j int) bool {
		if assets[i].Amount != assets[j].Amount {
			return assets[i].Amount > assets[j].Amount
		}
		bc := bytes.Compare(assets[i].Outpoint.Hash[:], assets[j].Outpoint.Hash[:])
		if bc != 0 {
			return bc > 0
		}
		return assets[i].Outpoint.Index > assets[j].Outpoint.Index
	})
	used := int64(0)
	txin := make([]*btcwire.TxIn, 0)

	var last *Asset

	for _, t := range assets {
		//		if t.Locked != 0 {
		//			continue
		//		}
		if used < total+fee {
			last = t
			txin = append(txin, &btcwire.TxIn{PreviousOutPoint: t.Outpoint, SignatureScript: []byte{}, Witness: nil, Sequence: 0xFFFFFFFF})
			used += int64(t.Amount)
		} else {
			break
		}
	}
	if used-total < fee {
		return nil
	}
	if used-total-fee > 1000 {
		sendto = append(sendto, &btcwire.TxOut{Value: used - total - fee, PkScript: last.Pkscript})
	}
	tx.TxIn = txin
	tx.TxOut = sendto

	return tx
}

func BtcIncome(haos uint64) {
	sum := uint64(0)
	last := (*Signers)(nil)
	for _, s := range signers {
		if s.Retiring {
			continue
		}
		t := haos * (uint64(s.Voting)) / 100
		if t > haos-sum {
			t = haos - sum
		}
		s.Btcprofit += t
		sum += t
		last = s
	}
	if haos > sum {
		last.Btcprofit += haos - sum
	}
}

func BtcSpend(haos uint64) {
	sum := uint64(0)
	last := (*Signers)(nil)
	for _, s := range signers {
		if s.Retiring {
			continue
		}
		t := haos * (uint64(s.Voting)) / 100
		if t > haos-sum {
			t = haos - sum
		}
		s.Btcprofit -= t
		sum += t
		last = s
	}
	if haos > sum {
		last.Btcprofit -= haos - sum
	}
}

func InTreasury(p *btcwire.OutPoint) bool {
	outp := wire.OutPoint{Index: p.Index}
	copy(outp.Hash[:], p.Hash[:])
	if _, ok := treasury[outp]; ok {
		return true
	}
	return false
}

func Boutp2l2outp(in *btcwire.OutPoint) *wire.OutPoint {
	r := wire.OutPoint{
		Index: in.Index,
	}
	copy(r.Hash[:], in.Hash[:])
	return &r
}

func L2outp2boutp(in *wire.OutPoint) *btcwire.OutPoint {
	r := btcwire.OutPoint{
		Index: in.Index,
	}
	copy(r.Hash[:], in.Hash[:])
	return &r
}

func Bhash2l2hash(in bhash.Hash) *chainhash.Hash {
	var h chainhash.Hash
	copy(h[:], in[:])
	return &h
}

func L2hash2Bhash(in chainhash.Hash) *bhash.Hash {
	var h bhash.Hash
	copy(h[:], in[:])
	return &h
}

func HasSpend(p *btcwire.OutPoint) bool {
	r := false
	mydb.Update(func(tx database.Tx) error {
		spendbucket := tx.Metadata().Bucket([]byte(common.BTCSpendlog))
		if spendbucket == nil {
			spendbucket, _ = tx.Metadata().CreateBucket([]byte(common.BTCSpendlog))
		}
		var key [36]byte
		copy(key[:], p.Hash[:])
		common.LittleEndian.PutUint32(key[32:], p.Index)
		v := spendbucket.Get(key[:])
		if v != nil && len(v) != 0 {
			r = true
		}
		return nil
	})
	return r
}

func Restore(p *btcwire.OutPoint) {
	// called in btc block disconnect
	mydb.Update(func(tx database.Tx) error {
		bucket := tx.Metadata().Bucket([]byte(common.XBTCAssets))
		spendbucket := tx.Metadata().Bucket([]byte(common.BTCSpendlog))

		var key [36]byte
		copy(key[:], p.Hash[:])
		common.LittleEndian.PutUint32(key[32:], p.Index)

		v := spendbucket.Get(key[:])
		if v == nil || len(v) == 0 {
			return nil
		}

		plg := &Asset{}
		_, err := plg.Deserialize(v)
		if err != nil {
			return err
		}

		spendbucket.Delete(key[:])
		bucket.Put(key[:], v)

		treasury[*Boutp2l2outp(p)] = plg
		return nil
	})
}

func Spend(p *btcwire.OutPoint) {
	outp := wire.OutPoint{Index: p.Index}
	copy(outp.Hash[:], p.Hash[:])
	if _, ok := treasury[outp]; !ok {
		return
	}

	// called when btc finds an asset being spent
	mydb.Update(func(tx database.Tx) error {
		bucket := tx.Metadata().Bucket([]byte(common.XBTCAssets))
		spendbucket := tx.Metadata().Bucket([]byte(common.BTCSpendlog))

		var key [36]byte
		copy(key[:], outp.Hash[:])
		common.LittleEndian.PutUint32(key[32:], p.Index)

		d := bucket.Get(key[:])
		spendbucket.Put(key[:], d)
		bucket.Delete(key[:])

		delete(treasury, *Boutp2l2outp(p))
		return nil
	})
}

func Joined(p *wire.OutPoint) uint32 {
	for _, s := range signers {
		for _, u := range s.Pledged {
			if p.Equal(&u.Utxo) {
				return u.Firstuse
			}
		}
	}
	return 0
}

func Load(db database.DB, coll *wire.Collaterals) error {
	mydb = db
	collaterals = coll
	treasury = make(map[wire.OutPoint]*Asset)

	signers = make(map[[20]byte]*Signers)
	totalOmg = 0
	eldest = nil

	return db.Update(func(tx database.Tx) error {
		fmt.Printf("XCAssets\n")

		bucket := tx.Metadata().Bucket([]byte(common.XBTCAssets))
		cursor := bucket.Cursor()
		for ok := cursor.First(); ok; ok = cursor.Next() {
			var outp wire.OutPoint
			key := cursor.Key()
			outp.Hash.SetBytes(key[:32])
			outp.Index = common.LittleEndian.Uint32(key[32:])
			plg := &Asset{}
			_, err := plg.Deserialize(cursor.Value())
			if err != nil {
				return err
			}

			/*			fmt.Printf("Asset: %s => Amount: %d, Outpoint: %s, Pkscript: %x, Owners: %d,", outp.String(), plg.Amount, plg.Outpoint.String(), plg.Pkscript, len(plg.Owners))
						if len(plg.Owners) > 0 {
							fmt.Printf(" Owners: ")
							for _, p := range plg.Owners {
								fmt.Printf(" %x\n", p)
							}
						}
						fmt.Printf("\n") */
			treasury[outp] = plg
		}

		fmt.Printf("REDEEMDB\n")
		bucket = tx.Metadata().Bucket([]byte(common.REDEEMDB))
		cursor = bucket.Cursor()
		for ok := cursor.First(); ok; ok = cursor.Next() {
			if len(cursor.Value()) == 1 && cursor.Value()[0] == 0 {
				bucket.Delete(cursor.Key())
			} else {
				fmt.Printf("Address: %s, Redeem script: %s\n", string(cursor.Key()), hex.EncodeToString(cursor.Value()))
			}
		}

		fmt.Printf("BRIDGESIGNERS\n")
		bucket = tx.Metadata().Bucket([]byte(common.BRIDGESIGNERS))
		cursor = bucket.Cursor()
		for ok := cursor.First(); ok; ok = cursor.Next() {
			var addr [20]byte
			copy(addr[:], cursor.Key())

			t := &Signers{}
			copy(t.Address[:], addr[:])
			t.Pledged = make([]*PlgAsset, 0)

			_, err := t.Deserialize(cursor.Value())
			if err != nil {
				bucket.Delete(cursor.Key())
				continue
				//				return err
			}

			fmt.Printf("%x: Address: %x, Joined: %d, Retiring: %d, Voting: %d, Pubkey: %x, pledges： %d\n", addr, t.Address, t.Joined, t.Retiring, t.Voting, t.Pubkey, len(t.Pledged))
			for _, p := range t.Pledged {
				fmt.Printf("Pledged: Utxo: %s Firstuse: %d Amount: %d\n", p.Utxo.String(), p.Firstuse, p.Amount)
			}

			signers[addr] = t

			if !t.Retiring && (eldest == nil || t.Joined < eldest.Joined) {
				eldest = t
			}

			for _, plg := range t.Pledged {
				if !t.Retiring {
					totalOmg += plg.Amount
				}
				collaterals.Add(&plg.Utxo)
			}
		}
		if eldest != nil {
			fmt.Printf("Eldest: %x\n", eldest.Address)
		}
		return nil
	})
}

func Intake(tx database.Tx, utxo *wire.OutPoint, amount uint64, script []byte) {
	asset := &Asset{
		Outpoint: btcwire.OutPoint{
			Index: utxo.Index,
		},
		Amount:   amount,
		Pkscript: script,
	}
	copy(asset.Outpoint.Hash[:], utxo.Hash[:])
	/*
		ispledge, _, addresses, _ := matchsigners(script)
		if ispledge {
			return
		}
		asset.Owners = make([][20]byte, len(addresses))
		for i, addr := range addresses {
			copy(asset.Owners[i][:], addr.Address[:])
		}
	*/

	treasury[*utxo] = asset

	bucket := tx.Metadata().Bucket([]byte(common.XBTCAssets))

	bucket.Put(utxo.ToBytes(), asset.serialize())
}

func Putout(amount int64) map[wire.OutPoint]uint64 {
	res := make(map[wire.OutPoint]uint64)

	// use assest that need Retiring signers to sign
	for utxo, t := range treasury {
		ret := false
		for _, s := range t.Owners {
			u := signers[s]
			if u.Retiring {
				ret = true
				break
			}
		}
		if !ret {
			continue
		}
		amount -= int64(t.Amount)
		res[utxo] = t.Amount
		if amount <= 0 {
			return res
		}
	}

	for utxo, t := range treasury {
		if _, ok := res[utxo]; ok {
			continue
		}
		amount -= int64(t.Amount)
		res[utxo] = t.Amount
		if amount <= 0 {
			return res
		}
	}
	return nil
}

func MayRetire(who [20]byte) bool {
	// a signer is allowed to restire only if he is not
	// involved in any asset in treasury
	for _, t := range treasury {
		for _, s := range t.Owners {
			if bytes.Compare(who[:], s[:]) == 0 {
				return false
			}
		}
	}
	return true
}

/*
func HandleL2BTC(height int32) {
	// a L2 notification call back. called when a L2 block is connected
	mydb.Update(func(tx database.Tx) error {
		bucket := tx.Metadata().Bucket([]byte(common.L2BTCPOOL))
		cursor := bucket.Cursor()

		// for all pending xfers from L2 to BTC, i.e. those in L2BTCPOOL

		for ok := cursor.First(); ok; ok = cursor.Next() {
			if len(cursor.Key()) != 4 {
				continue
			}
			// a pending L2=>BTC tx
			h := int32(common.LittleEndian.Uint32(cursor.Key()))
			if height-h < wire.MINER_RORATE_FREQ*2 {
				// not mature yet
				continue
			}
			d := common.BTCL2Data{}
			d.Unserialize(cursor.Value())
			if h != d.Height { // must
				continue
			}
			// if it is finalized, make a BTC tx and broadcast it
			btx := btcwire.NewMsgTx(btcwire.TxVersion)
			total := int64(0)
			for _, txo := range d.Txs {
				if txo.Value == 0 || bytes.Compare(txo.PkScript[22:25], []byte{0xFF, 0xFF, 0xFF}) != 0 {
					// no value or a xfer to other chains
					continue
				}
				if len(txo.Redeem) == 0 || txo.Redeem[0] == 0 {
					txo.Redeem = []byte{1}
				} else {
					// intentionally allow overflow from 255 to 0
					// prevent making tx repeatedly and yet allow creating a new tx
					// when no confirmation for long time
					txo.Redeem[0]++
					continue
				}
				total += txo.Value
				to := btcwire.NewTxOut(txo.Value, BtcScriptConvert(txo.PkScript, ActiveNetParams))
				btx.AddTxOut(to)
			}
			if total == 0 {
				continue
			}

			feereq := int64(btx.SerializeSize()) * feepolicy
			sum := total + feereq
			lastpks := ([]byte)(nil)
			for _, s := range treasury {
				if sum >= 0 {
					break
				}
				ti := btcwire.NewTxIn(&s.Outpoint, []byte{}, nil)
				btx.AddTxIn(ti)
				df := int64(ti.SerializeSize()) * feepolicy
				feereq += df
				sum -= int64(s.Amount) - df
				lastpks = s.Pkscript
			}
			/*
				fu, mu, mfu := int64(0), 0, int64(0)
				for i, txo := range btx.TxOut {
					u := feereq * txo.Value / total
					txo.Value -= u
					fu += u
					if u > mfu {
						mfu, mu = u, i
					}
				}
				if feereq > fu {
					btx.TxOut[mu].Value -= mfu
				}
			* /
			if sum < -feepolicy*int64(len(lastpks)+8+40) { // more than 2 txous (MS + PKH) left, claim it
				to := btcwire.NewTxOut(-sum-feepolicy*int64(len(lastpks)+8), lastpks)
				btx.AddTxOut(to)
			}
			bucket.Put(cursor.Key(), d.Serialize())
			m := &wire.MsgSolicitSigs{
				Tx:     btx,                   // the BTC tx
				Height: uint32(h),             // the L2 block height for txo sources
				Hash:   *Bhash2l2hash(d.Hash), // the L2 block hash for txo sources
			}
			_, btx = Signtx(m)
		}
		return nil
	})
}
*/

func validateL2Tx(d *common.BTCL2Data, tx *btcwire.MsgTx) bool {
	btx := btcwire.NewMsgTx(btcwire.TxVersion)
	total := int64(0)
	for _, txo := range d.Txs {
		if txo.Value == 0 || bytes.Compare(txo.PkScript[22:25], []byte{0xFF, 0xFF, 0xFF}) != 0 {
			continue
		}
		total += txo.Value
		to := btcwire.NewTxOut(txo.Value, BtcScriptConvert(txo.PkScript, ActiveNetParams))
		btx.AddTxOut(to)
	}
	if total == 0 {
		return false
	}

	// Fee Policy is 40 sat/vbyte
	feereq := int64(btx.SerializeSize()) * feepolicy
	sum := total + feereq
	lastpks := ([]byte)(nil)

	for _, txin := range tx.TxIn {
		outp := wire.OutPoint{Index: txin.PreviousOutPoint.Index}
		copy(outp.Hash[:], txin.PreviousOutPoint.Hash[:])
		if t, ok := treasury[outp]; !ok {
			return false
		} else {
			df := int64(txin.SerializeSize()) * feepolicy
			feereq += df
			sum -= int64(t.Amount) - df
			lastpks = t.Pkscript
		}
	}

	if sum > 0 {
		return false
	}

	/*
		// spread tx fees among outputs proportional to their amounts
		fu, mu, mfu := int64(0), 0, int64(0)
		for i, txo := range btx.TxOut {
			u := feereq * txo.Value / total
			txo.Value -= u
			fu += u
			if u > mfu {
				mfu, mu = u, i
			}
		}
		// make up discrepency from the largest output
		if feereq > fu {
			btx.TxOut[mu].Value -= mfu
		}
	*/
	if sum < -feepolicy*int64(len(lastpks)+8+40) {
		to := btcwire.NewTxOut(-sum-feepolicy*int64(len(lastpks)+8), lastpks)
		btx.AddTxOut(to)
	}
	// verify contents of msg.Tx
	if len(tx.TxOut) != len(btx.TxOut) {
		return false
	}
	txob := make(map[int]int)
	for i, txo := range btx.TxOut {
		for j, otx := range tx.TxOut {
			if txo.Value == otx.Value && bytes.Compare(txo.PkScript, otx.PkScript) == 0 {
				if _, ok := txob[j]; !ok {
					txob[j] = i
					break
				}
			}
		}
	}
	if len(tx.TxOut) != len(btx.TxOut) {
		return false
	}
	return true
}

func Signtx(msg *wire.MsgSolicitSigs) (bool, *btcwire.MsgTx) {
	/*
		l2blk := Server.GetTxBlock(int32(msg.Height))
		if l2blk == nil || !msg.Hash.IsEqual(l2blk.Hash()) {
			// we don't have the block, so broadcast it w/o signing
			Server.SolicitSigs(msg.Tx, &msg.Hash, msg.Height)
			return false
		}
	*/
	/*
		mydb.View(func(tx database.Tx) error {
			bucket := tx.Metadata().Bucket([]byte(common.L2BTCPOOL))
			var h [4]byte

			copy(h[:], bucket.Get([]byte("ChainHeight")))
			ht := common.LittleEndian.Uint32(h[:])

			if msg.Height+wire.MINER_RORATE_FREQ*2 > ht {
				return nil
			}

			common.LittleEndian.PutUint32(h[:], msg.Height)

			d := common.BTCL2Data{}
			d.Unserialize(bucket.Get(h[:]))

			if !msg.Hash.IsEqual(Bhash2l2hash(d.Hash)) {
				return nil
			}

			if !validateL2Tx(&d, msg.Tx) {
				return nil
			}
	*/

	// sign it
	allsigned := true
	for i, txin := range msg.Tx.TxIn {
		outp := Boutp2l2outp(&txin.PreviousOutPoint)
		asset := treasury[*outp]

		var redeem []byte

		witnessadress, err := btcutil.NewAddressWitnessScriptHash(asset.Pkscript[2:], BTCParams)
		if err != nil {
			return false, msg.Tx
		}

		address := witnessadress.EncodeAddress()

		mydb.View(func(tx database.Tx) error {
			bucket := tx.Metadata().Bucket([]byte(common.REDEEMDB))
			redeem = bucket.Get([]byte(address))
			return nil
		})
		if redeem == nil || len(redeem) <= 10 {
			// make a request for redeem script
			Server.GetRedeemScript(
				&wire.MsgRedeemScpt{
					Address: address,
					Script:  nil,
				})
			allsigned = false
			continue
		}

		fetcher := createFetcher(*asset)
		r, _, snr, m := matchsigners(redeem[1:])

		if !r {
			continue
		}

		var t int

		sigclass, _, _, err := txscript.ExtractPkScriptAddrs(asset.Pkscript, BTCParams)
		if err != nil {
			continue
		}

		if sigclass == txscript.WitnessV0ScriptHashTy {
			t = enoughWitnessSigs(m, txin.Witness)
		} else {
			t = enoughSigs(m, txin.SignatureScript)
		}

		switch t {
		case 1:
			continue
		case 0: // need a MS sig
			if signed(msg.Tx, i, int64(asset.Amount), snr, txin.SignatureScript) {
				// already signed the txin
				allsigned = false
				continue
			}

			sig := signing(msg.Tx, i, asset, snr[1:])
			if sig != nil {
				if len(txin.SignatureScript) == 0 {
					txin.SignatureScript = []byte{0}
				}
				txin.SignatureScript = append(txin.SignatureScript, sig...)
			}
			allsigned = allsigned && enoughSigs(m, txin.SignatureScript) == 1

		case 2:
			if signedP2WSH(msg.Tx, i, int64(asset.Amount), snr, txin.Witness) {
				allsigned = false
				continue
			}
			witness, _ := SignWitnessMultiSigScript(msg.Tx, i, asset, int64(asset.Amount), redeem[1:], fetcher, snr)

			allsigned = allsigned && enoughWitnessSigs(m, witness) == 1
			/*
				case 2: // need eldest sig
					if signed(msg.Tx, i, int64(asset.Amount), snr, txin.SignatureScript) {
						// already signed the txin
						allsigned = false
						continue
					}

					sig := signing(msg.Tx, i, asset, snr[:1])
					if sig != nil {
						txin.SignatureScript = append(txin.SignatureScript, sig...)
					} else {
						allsigned = false
					}
			*/
		}
	}
	if allsigned {
		// all signed, add it to mempool and broadcast it
		btx := btcutil.NewTx(msg.Tx)
		Rpc.DoSendRawTransaction(btx)
		//	} else {
		//		Server.SolicitSigs(msg.Tx, &msg.Hash, msg.Height)
	}
	return allsigned, msg.Tx
	//		return nil
	//	})
}

//func Signtx(msg *wire.MsgSolicitSigs) {
//	l2blk := Server.GetTxBlock(int32(msg.Height))
//	if l2blk == nil || !msg.Hash.IsEqual(l2blk.Hash()) {
//		// we don't have the block, so broadcast it w/o signing
//		Server.SolicitSigs(msg.Tx, &msg.Hash, msg.Height)
//		return
//	}
//
//	mydb.View(func(tx database.Tx) error {
//		bucket := tx.Metadata().Bucket([]byte(common.L2BTCPOOL))
//		var h [4]byte
//
//		copy(h[:], bucket.Get([]byte("ChainHeight")))
//		ht := common.LittleEndian.Uint32(h[:])
//
//		if msg.Height+wire.MINER_RORATE_FREQ*2 > ht {
//			return nil
//		}
//
//		common.LittleEndian.PutUint32(h[:], msg.Height)
//
//		d := common.BTCL2Data{}
//		d.Unserialize(bucket.Get(h[:]))
//
//		if !msg.Hash.IsEqual(Bhash2l2hash(d.Hash)) {
//			return nil
//		}
//
//		if !validateL2Tx(&d, msg.Tx) {
//			return nil
//		}
//
//		// sign it
//		allsigned := true
//		for i, txin := range msg.Tx.TxIn {
//			outp := wire.OutPoint{Index: txin.PreviousOutPoint.Index}
//			copy(outp.Hash[:], txin.PreviousOutPoint.Hash[:])
//			asset := treasury[outp]
//
//			r, _, snr, m := matchsigners(asset.Pkscript)
//			if !r {
//				return nil
//			}
//
//			var script []byte
//			if txin.Witness != nil && len(txin.Witness) > 0 {
//				// 这是一个隔离见证交易
//				script = txin.Witness[1]
//			} else {
//				script = txin.SignatureScript
//			}
//
//			t := enoughSigs(m, script)
//
//			switch t {
//			case 1:
//				continue
//			case 0: // need a MS sig
//				if signed(msg.Tx, i, int64(asset.Amount), snr, script) {
//					// already signed the txin
//					allsigned = false
//					continue
//				}
//
//				sig := signing(msg.Tx, i, asset, snr[1:])
//				if sig != nil {
//					if len(script) == 0 {
//						script = []byte{0}
//					}
//					script = append(script, sig...)
//				}
//				allsigned = allsigned && enoughSigs(m, script) == 1
//
//				if txin.Witness != nil && len(txin.Witness) > 0 {
//					// Update the witness
//					witness := make([][]byte, len(txin.Witness), 2)
//					witness[0] = nil
//					witness[1] = script
//					txin.Witness = witness
//				} else {
//					// Update the SignatureScript
//					txin.SignatureScript = script
//				}
//			}
//		}
//		if allsigned {
//			// all signed, add it to mempool and broadcast it
//			btx := btcutil.NewTx(msg.Tx)
//			Rpc.DoSendRawTransaction(btx)
//		} else {
//			Server.SolicitSigs(msg.Tx, &msg.Hash, msg.Height)
//		}
//		return nil
//	})
//}

func convSecpPrivKey(privKey *btcec.PrivateKey) *btcec2.PrivateKey {
	ecdsaKey := ecdsa.PrivateKey{
		PublicKey: ecdsa.PublicKey{
			Curve: privKey.PublicKey.Curve,
			X:     privKey.PublicKey.X,
			Y:     privKey.PublicKey.Y,
		},
		D: privKey.D,
	}

	scepKey := btcec2.ConvertPrivateKey(ecdsaKey)

	return scepKey
}

func signing(tx *btcwire.MsgTx, idx int, input *Asset, snr []*Signers) []byte {
	for _, k := range PrivKeys {
		pubKey := k.PubKey()
		pkc := pubKey.SerializeCompressed()
		pkuc := pubKey.SerializeUncompressed()
		for _, s := range snr {
			if bytes.Compare(s.Pubkey, pkc) == 0 || bytes.Compare(s.Pubkey, pkuc) == 0 {
				//p := convSecpPrivKey(k)
				sig, err := txscript.RawTxInSignature(tx, idx, input.Pkscript, txscript.SigHashAll, k)
				if err != nil {
					continue
				}
				return sig
			}
		}
	}
	return nil
}

func SignWitnessMultiSigScript(tx *btcwire.MsgTx, inputIndex int, input *Asset, inputAmount int64, redeemScript []byte, prevOutputs txscript.PrevOutputFetcher, snr []*Signers) (btcwire.TxWitness, error) {
	sigHashes := txscript.NewTxSigHashes(tx, prevOutputs)

	builder := txscript.NewScriptBuilder()

	signed := 0

	var sigscript []byte

	_, realaddresses, _, err := txscript.ExtractPkScriptAddrs(redeemScript, BTCParams)
	if err != nil {
		return nil, err
	}

	for _, k := range PrivKeys {

		pubKey := k.PubKey()
		pkc := pubKey.SerializeCompressed()
		pkuc := pubKey.SerializeUncompressed()

		for _, s := range snr {
			if bytes.Compare(s.Pubkey, pkc) == 0 || bytes.Compare(s.Pubkey, pkuc) == 0 {
				signature, err := txscript.RawTxInWitnessSignature(tx, sigHashes, inputIndex, inputAmount, redeemScript, txscript.SigHashAll, k)
				if err != nil {
					continue
				}
				signed++
				builder.AddOps(signature)
			}
		}
	}

	if signed == 0 {
		sigscript = nil
	} else {
		sigscript, _ = builder.Script()
	}

	witness := make([][]byte, 0, 1)
	witness = append(witness, []byte{})
	witness = append(witness, sigscript)
	witness = append(witness, redeemScript)

	finalwitness := txscript.MergeWitnessMultiSig(tx, inputIndex, realaddresses, input.Pkscript, witness, tx.TxIn[inputIndex].Witness, int64(input.Amount), sigHashes)

	return finalwitness, nil
}

func extractPubKeysFromRedeemScript(redeemScript []byte) ([][]byte, error) {
	var pubKeys [][]byte

	// 读取公钥数量
	if len(redeemScript) < 2 {
		return nil, fmt.Errorf("invalid redeem script length")
	}

	// 第一个字节是 M 值
	m := redeemScript[0] - txscript.OP_1 + 1 // 获取 M 值
	if m < 1 || m > 16 {                     // M 值的范围是 1 到 16
		return nil, fmt.Errorf("invalid M value: %d", m)
	}

	// 计算公钥数量
	numPubKeys := int(redeemScript[len(redeemScript)-1]) - txscript.OP_1 + 1 // 获取 N 值（第一个公钥之前的字节）
	if numPubKeys < 1 || numPubKeys > 16 {
		return nil, fmt.Errorf("invalid N value: %d", numPubKeys)
	}

	// 提取公钥
	pos := 2 // 从第三个字节开始解析
	for i := 0; i < numPubKeys; i++ {
		if pos >= len(redeemScript) {
			return nil, fmt.Errorf("redeem script ended unexpectedly")
		}

		// 公钥长度
		pubKeyLen := int(redeemScript[pos])
		if pubKeyLen != btcec.PubKeyBytesLenCompressed {
			return nil, fmt.Errorf("invalid public key length: %d", pubKeyLen)
		}

		// 提取公钥
		pubKey := redeemScript[pos+1 : pos+1+pubKeyLen]
		pubKeys = append(pubKeys, pubKey)

		// 移动到下一个公钥的位置
		pos += pubKeyLen + 1 // +1 是为了包括长度字节
	}

	return pubKeys, nil
}

func MergeWitnessMultiSig(tx *btcwire.MsgTx, idx int, addresses []btcutil.Address,
	pkScript []byte, witness [][]byte, prevWitness [][]byte, amount int64, sighashes *txscript.TxSigHashes) [][]byte {

	// 如果新的或者之前的 witness 为空，则直接返回另一个
	if len(witness) == 0 {
		return prevWitness
	}
	if len(prevWitness) == 0 {
		return witness
	}

	// 函数从 witness 的第二个到倒数第二个数据中提取签名
	var possibleSigs [][]byte
	extractWitnessSigs := func(w [][]byte) error {
		if len(w) > 2 {
			for _, data := range w[1 : len(w)-1] {
				if len(data) != 0 {
					possibleSigs = append(possibleSigs, data)
				}
			}
		}
		return nil
	}

	// 提取新 witness 和之前的 witness 的签名
	if err := extractWitnessSigs(witness); err != nil {
		return prevWitness
	}
	if err := extractWitnessSigs(prevWitness); err != nil {
		return witness
	}

	// 存储地址对应的签名
	addrToSig := make(map[string][]byte)

sigLoop:
	for _, sig := range possibleSigs {

		// 确保签名至少有 hash type 字节
		if len(sig) < 1 {
			continue
		}
		tSig := sig[:len(sig)-1]
		hashType := txscript.SigHashType(sig[len(sig)-1])

		// 解析 DER 格式的签名
		pSig, err := btcecedcsa.ParseDERSignature(tSig)
		if err != nil {
			continue
		}

		// 计算签名哈希
		hash, _ := txscript.CalcWitnessSigHash(pkScript, sighashes, hashType, tx, idx, amount)

		// 验证签名是否与公钥匹配
		for _, addr := range addresses {
			pkaddr := addr.(*btcutil.AddressPubKey)
			pubKey := pkaddr.PubKey()

			if pSig.Verify(hash, pubKey) {
				aStr := addr.EncodeAddress()
				if _, ok := addrToSig[aStr]; !ok {
					addrToSig[aStr] = sig
				}
				continue sigLoop
			}
		}
	}

	// 构建最终的合并 witness
	finalWitness := make([][]byte, 0, len(addresses)+2)
	finalWitness = append(finalWitness, []byte{}) // P2WSH 的初始空元素

	// 按照地址顺序将签名插入 witness
	for _, addr := range addresses {
		aStr := addr.EncodeAddress()
		if sig, ok := addrToSig[aStr]; ok {
			finalWitness = append(finalWitness, sig)
		}
	}

	// 在 witness 的最后追加 redeem script
	finalWitness = append(finalWitness, pkScript)

	return finalWitness
}

func checkScripts(tx *btcwire.MsgTx, idx int, inputAmt int64, sigScript, pkScript []byte) bool {
	tx.TxIn[idx].SignatureScript = sigScript
	vm, err := txscript.NewEngine(pkScript, tx, idx,
		txscript.ScriptBip16|txscript.ScriptVerifyDERSignatures, nil, nil, inputAmt, nil)
	if err != nil {
		return false
	}

	err = vm.Execute()
	if err != nil {
		return false
	}

	return true
}

func checkWitnessScripts(tx *btcwire.MsgTx, idx int, inputAmt int64, witness btcwire.TxWitness, pkScript []byte) bool {
	tx.TxIn[idx].Witness = witness

	vm, err := txscript.NewEngine(pkScript, tx, idx,
		txscript.ScriptVerifyWitness|txscript.ScriptVerifyDERSignatures, nil, nil, inputAmt, nil)
	if err != nil {
		return false
	}

	err = vm.Execute()
	if err != nil {
		return false
	}

	return true
}

func signed(tx *btcwire.MsgTx, idx int, inputAmt int64, snr []*Signers, sigs []byte) bool {
	if len(sigs) == 0 {
		return false
	}
	for n := 1; n < len(sigs); {
		p := sigs[n]
		n += int(p) + 1
		sig := sigs[n+1 : n+1+int(p)]
		for _, k := range PrivKeys {
			pubKey := k.PubKey()
			pkc := pubKey.SerializeCompressed()
			for _, s := range snr {
				if bytes.Compare(s.Pubkey, pkc) == 0 {
					pks, _ := txscript.NewScriptBuilder().AddData(s.Pubkey).AddOp(txscript.OP_CHECKSIG).Script()
					valid := checkScripts(tx, idx, inputAmt, sig, pks)
					if valid {
						return true
					}
				}
			}
		}
	}
	return false
}

func signedP2WSH(tx *btcwire.MsgTx, idx int, inputAmt int64, snr []*Signers, witness btcwire.TxWitness) bool {

	if len(witness) < 2 {
		return false
	}

	//redeemScript := witness[len(witness)-1]
	sigs := witness[1 : len(witness)-1]

	for _, sig := range sigs {
		if len(sig) == 0 {
			continue
		}

		for _, k := range PrivKeys {
			pubKey := k.PubKey()
			pkc := pubKey.SerializeCompressed()
			for _, s := range snr {
				if bytes.Compare(s.Pubkey, pkc) == 0 {
					pks, _ := txscript.NewScriptBuilder().AddData(s.Pubkey).AddOp(txscript.OP_CHECKSIG).Script()
					valid := checkScripts(tx, idx, inputAmt, sig, pks)
					if valid {
						return true
					}
				}
			}
		}
	}
	return false
}

func enoughSigs(m byte, sig []byte) int {
	if len(sig) == 0 {
		return 0
	}
	if sig[0] != 0 {
		return -1
	}

	p := 1
	for m > 0 && len(sig) > p+btcec.PubKeyBytesLenCompressed+btcec.MinSigLen+2 {
		if sig[p] == btcec.PubKeyBytesLenCompressed {
			p += btcec.PubKeyBytesLenCompressed + 1
		} else {
			return -1
		}
		sl := sig[p]
		if len(sig) < p+int(sl)+1 {
			return -1
		}
		p += int(sl) + 1
		m--
	}
	if m == 0 {
		return 1
	}

	return 0
}

func enoughWitnessSigs(m byte, witness btcwire.TxWitness) int {
	// 校验 witness 堆栈的长度是否为 0
	if len(witness) == 0 {
		return 0
	}

	// witness 堆栈的第一个元素通常为占位符，必须是一个空项
	if len(witness[0]) != 0 {
		return -1 // witness 第一项不是占位符，返回错误
	}

	p := 1 // 从第二个元素开始遍历 witness 堆栈
	for m > 0 && p < len(witness) {
		// 每个 witness 项应该是一个有效签名
		sig := witness[p]

		// 验证签名的长度是否符合预期
		if len(sig) < btcec.MinSigLen || len(sig) > 75 {
			return -1 // 签名长度不符合要求
		}

		// 验证签名是否有效（可以根据需求调用特定的签名校验函数）
		// 如果这里需要校验签名是否是一个有效的ECDSA签名，可以在此添加具体的验证逻辑

		p++ // 处理下一个签名
		m-- // 已找到一个有效签名，减少需要的签名数量
	}

	// 如果 m 减到 0，说明签名数量足够
	if m == 0 {
		return 1
	}

	// 如果 m 还大于 0，说明签名数量不够
	return 2
}

func BtcScriptConvert(script []byte, params *l2param.Params) []byte {
	builder := txscript.NewScriptBuilder()
	switch script[0] {
	case params.PubKeyHashAddrID:
		builder.AddOp(txscript.OP_DUP).AddOp(txscript.OP_HASH160).AddData(script[1:21]).
			AddOp(txscript.OP_EQUALVERIFY).AddOp(txscript.OP_CHECKSIG)

	case params.ScriptHashAddrID:
		builder.AddOp(txscript.OP_HASH160).AddData(script[1:21]).
			AddOp(txscript.OP_EQUAL)
	}
	r, _ := builder.Script()
	return r
}

/*
func ScriptConvert(script []byte) []byte {
	// convert a BTC pk script to L2 pk script
	m := Matching(script)

	switch m {
	case 0: // BTC => L2
		res := []byte{ActiveNetParams.PubKeyHashAddrID}
		ln := len(script)
		res = append(res, script[ln-34:ln-14]...)
		res = append(res, []byte{0x41, 0, 0, 0}...)
		return res

	case 1: // Omni
		return nil
	case 2: // BRC
		return nil
	case 3: // SRC
		return nil
	case 10: // Pledge
		return nil
	}

	return nil
}

*/
