// Copyright (c) 2014-2017 The btcsuite developers
// Copyright (c) 2018-2021 The Omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package btcjson

import (
	"encoding/json"
	"github.com/btcsuite/btcd/btc2omg/btcd/treasury"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire"
)

// GetBlockHeaderVerboseResult models the data from the getblockheader command when
// the verbose flag is set.  When the verbose flag is not set, getblockheader
// returns a hex-encoded string.
type GetBlockHeaderVerboseResult struct {
	Hash          string `json:"hash"`
	Confirmations int64  `json:"confirmations"`
	Height        int32  `json:"height"`
	Version       uint32 `json:"version"`
	VersionHex    string `json:"versionHex"`
	MerkleRoot    string `json:"merkleroot"`
	Time          int64  `json:"time"`
	Nonce         int64  `json:"nonce"`
	//	Bits          string  `json:"bits"`
	//	Difficulty    float64 `json:"difficulty"`
	PreviousHash string `json:"previousblockhash,omitempty"`
	NextHash     string `json:"nextblockhash,omitempty"`
}

// GetBlockVerboseResult models the data from the getblock command when the
// verbose flag is set.  When the verbose flag is not set, getblock returns a
// hex-encoded string.
type GetBlockVerboseResult struct {
	Hash          string `json:"hash"`
	Confirmations int64  `json:"confirmations"`
	StrippedSize  int32  `json:"strippedsize"`
	Size          int32  `json:"size"`
	//	Weight        int32         `json:"weight"`
	Height       int64         `json:"height"`
	Version      uint32        `json:"version"`
	VersionHex   string        `json:"versionHex"`
	MerkleRoot   string        `json:"merkleroot"`
	Tx           []string      `json:"tx,omitempty"`
	RawTx        []TxRawResult `json:"rawtx,omitempty"`
	Time         int64         `json:"time"`
	Nonce        int32         `json:"nonce"`
	PreviousHash string        `json:"previousblockhash"`
	NextHash     string        `json:"nextblockhash,omitempty"`
}

type Instruction struct {
	InstCode uint32
	InstData string
}

type GetMinerBlockVerboseResult struct {
	Hash          string             `json:"hash"`
	Confirmations int64              `json:"confirmations"`
	Size          int32              `json:"size"`
	Height        int64              `json:"height"`
	Version       uint32             `json:"version"`
	VersionHex    string             `json:"versionHex"`
	Time          int64              `json:"time"`
	Nonce         int32              `json:"nonce"`
	PreviousHash  string             `json:"previousblockhash"`
	NextHash      string             `json:"nextblockhash,omitempty"`
	Bits          string             `json:"bits"`
	Difficulty    float64            `json:"difficulty"`
	Address       string             `json:"address"`
	Best          string             `json:"best"`
	Collateral    string             `json:"collateral"`
	Violations    []*wire.Violations `json:"violations"`
	Instructions  []Instruction      `json:"instructions"`
}

// CreateMultiSigResult models the data returned from the createmultisig
// command.
type CreateMultiSigResult struct {
	Address      string `json:"address"`
	RedeemScript string `json:"redeemScript"`
}

// DecodeScriptResult models the data returned from the decodescript command.
type DecodeScriptResult struct {
	Asm string `json:"asm"`
	//	ReqSigs   int32    `json:"reqSigs,omitempty"`
	Type      string   `json:"type"`
	Addresses []string `json:"addresses,omitempty"`
	P2sh      string   `json:"p2sh,omitempty"`
}

// GetAddedNodeInfoResultAddr models the data of the addresses portion of the
// getaddednodeinfo command.
type GetAddedNodeInfoResultAddr struct {
	Address   string `json:"address"`
	Connected string `json:"connected"`
}

// GetAddedNodeInfoResult models the data from the getaddednodeinfo command.
type GetAddedNodeInfoResult struct {
	AddedNode string                        `json:"addednode"`
	Connected *bool                         `json:"connected,omitempty"`
	Addresses *[]GetAddedNodeInfoResultAddr `json:"addresses,omitempty"`
}

// SoftForkDescription describes the current state of a soft-fork which was
// deployed using a super-majority block signalling.
type SoftForkDescription struct {
	ID      string `json:"id"`
	Version uint32 `json:"version"`
	Reject  struct {
		Status bool `json:"status"`
	} `json:"reject"`
}

type AddMiningKeyResult struct {
	Status int32 `json:"status"`
}

// GetBlockChainInfoResult models the data returned from the getblockchaininfo
// command.
type GetBlockChainInfoResult struct {
	Chain   string `json:"chain"`
	Current bool   `json:"current"`
	Blocks  int32  `json:"blocks"`
	//	Headers              int32                               `json:"headers"`
	Rotate        int32  `json:"rotate"`
	BestBlockHash string `json:"bestblockhash"`
	//	Difficulty           float64                             `json:"difficulty"`
	MedianTime           int64   `json:"mediantime"`
	VerificationProgress float64 `json:"verificationprogress,omitempty"`
	//	Pruned               bool                                `json:"pruned"`
	//	PruneHeight          int32                               `json:"pruneheight,omitempty"`
	ChainWork string `json:"chainwork,omitempty"`
	//	SoftForks            []*SoftForkDescription              `json:"softforks"`

	MinerBlocks int32 `json:"minerblocks"`
	//	MinerHeaders              int32                          `json:"minerheaders"`
	MinerBestBlockHash        string  `json:"minerbestblockhash"`
	MinerDifficulty           float64 `json:"minerdifficulty"`
	MinerMedianTime           int64   `json:"minermediantime"`
	MinerVerificationProgress float64 `json:"minerverificationprogress,omitempty"`
	MinerChainWork            string  `json:"minerchainwork,omitempty"`
}

// GetBlockTemplateResultTx models the transactions field of the
// getblocktemplate command.
type GetBlockTemplateResultTx struct {
	Data    string  `json:"data"`
	Hash    string  `json:"hash"`
	Depends []int64 `json:"depends"`
	Fee     int64   `json:"fee"`
	SigOps  int64   `json:"sigops"`
	Weight  int64   `json:"weight"`
}

// GetBlockTemplateResultAux models the coinbaseaux field of the
// getblocktemplate command.
type GetBlockTemplateResultAux struct {
	Flags string `json:"flags"`
}

// GetBlockTemplateResult models the data returned from the getblocktemplate
// command.
type GetBlockTemplateResult struct {
	// Base fields from BIP 0022.  CoinbaseAux is optional.  One of
	// CoinbaseTxn or CoinbaseValue must be specified, but not both.
	Bits         string `json:"bits"`
	CurTime      int64  `json:"curtime"`
	Height       int64  `json:"height"`
	PreviousHash string `json:"previousblockhash"`
	SigOpLimit   int64  `json:"sigoplimit,omitempty"`
	//	SizeLimit     int64                      `json:"sizelimit,omitempty"`
	//	WeightLimit   int64                      `json:"weightlimit,omitempty"`
	Transactions  []GetBlockTemplateResultTx `json:"transactions"`
	Version       uint32                     `json:"version"`
	CoinbaseAux   *GetBlockTemplateResultAux `json:"coinbaseaux,omitempty"`
	CoinbaseTxn   *GetBlockTemplateResultTx  `json:"coinbasetxn,omitempty"`
	CoinbaseValue *int64                     `json:"coinbasevalue,omitempty"`
	WorkID        string                     `json:"workid,omitempty"`

	// Witness commitment defined in BIP 0141.
	DefaultWitnessCommitment string `json:"default_witness_commitment,omitempty"`

	// Optional long polling from BIP 0022.
	LongPollID  string `json:"longpollid,omitempty"`
	LongPollURI string `json:"longpolluri,omitempty"`
	SubmitOld   *bool  `json:"submitold,omitempty"`

	// Basic pool extension from BIP 0023.
	Target  string `json:"target,omitempty"`
	Expires int64  `json:"expires,omitempty"`

	// Mutations from BIP 0023.
	MaxTime    int64    `json:"maxtime,omitempty"`
	MinTime    int64    `json:"mintime,omitempty"`
	Mutable    []string `json:"mutable,omitempty"`
	NonceRange string   `json:"noncerange,omitempty"`

	// Block proposal from BIP 0023.
	Capabilities  []string `json:"capabilities,omitempty"`
	RejectReasion string   `json:"reject-reason,omitempty"`
}

// GetMempoolEntryResult models the data returned from the getmempoolentry
// command.
type GetMempoolEntryResult struct {
	Size             int32    `json:"size"`
	Fee              float64  `json:"fee"`
	ModifiedFee      float64  `json:"modifiedfee"`
	Time             int64    `json:"time"`
	Height           int64    `json:"height"`
	StartingPriority float64  `json:"startingpriority"`
	CurrentPriority  float64  `json:"currentpriority"`
	DescendantCount  int64    `json:"descendantcount"`
	DescendantSize   int64    `json:"descendantsize"`
	DescendantFees   float64  `json:"descendantfees"`
	AncestorCount    int64    `json:"ancestorcount"`
	AncestorSize     int64    `json:"ancestorsize"`
	AncestorFees     float64  `json:"ancestorfees"`
	Depends          []string `json:"depends"`
}

// GetMempoolInfoResult models the data returned from the getmempoolinfo
// command.
type GetMempoolInfoResult struct {
	Size  int64 `json:"size"`
	Bytes int64 `json:"bytes"`
}

// NetworksResult models the networks data from the getnetworkinfo command.
type NetworksResult struct {
	Name                      string `json:"name"`
	Limited                   bool   `json:"limited"`
	Reachable                 bool   `json:"reachable"`
	Proxy                     string `json:"proxy"`
	ProxyRandomizeCredentials bool   `json:"proxy_randomize_credentials"`
}

// LocalAddressesResult models the localaddresses data from the getnetworkinfo
// command.
type LocalAddressesResult struct {
	Address string `json:"address"`
	Port    uint16 `json:"port"`
	Score   int32  `json:"score"`
}

// GetNetworkInfoResult models the data returned from the getnetworkinfo
// command.
type GetNetworkInfoResult struct {
	Version         int32                  `json:"version"`
	SubVersion      string                 `json:"subversion"`
	ProtocolVersion int32                  `json:"protocolversion"`
	LocalServices   string                 `json:"localservices"`
	LocalRelay      bool                   `json:"localrelay"`
	TimeOffset      int64                  `json:"timeoffset"`
	Connections     int32                  `json:"connections"`
	NetworkActive   bool                   `json:"networkactive"`
	Networks        []NetworksResult       `json:"networks"`
	RelayFee        float64                `json:"relayfee"`
	IncrementalFee  float64                `json:"incrementalfee"`
	LocalAddresses  []LocalAddressesResult `json:"localaddresses"`
	Warnings        string                 `json:"warnings"`
}

// GetPeerInfoResult models the data returned from the getpeerinfo command.
type GetPeerInfoResult struct {
	ID                  int32   `json:"id"`
	Addr                string  `json:"addr"`
	AddrLocal           string  `json:"addrlocal,omitempty"`
	Services            string  `json:"services"`
	RelayTxes           bool    `json:"relaytxes"`
	LastSend            int64   `json:"lastsend"`
	LastRecv            int64   `json:"lastrecv"`
	BytesSent           uint64  `json:"bytessent"`
	BytesRecv           uint64  `json:"bytesrecv"`
	ConnTime            int64   `json:"conntime"`
	TimeOffset          int64   `json:"timeoffset"`
	PingTime            float64 `json:"pingtime"`
	PingWait            float64 `json:"pingwait,omitempty"`
	Version             uint32  `json:"version"`
	SubVer              string  `json:"subver"`
	Inbound             bool    `json:"inbound"`
	RpcPort             string  `json:"rpcport"`
	StartingHeight      int32   `json:"startingheight"`
	StartingMinerHeight int32   `json:"startingminerheight"`
	CurrentHeight       int32   `json:"currentheight,omitempty"`
	CurrentMinerHeight  int32   `json:"currentminerheight,omitempty"`
	BanScore            int32   `json:"banscore"`
	FeeFilter           int64   `json:"feefilter"`
	SyncNode            bool    `json:"syncnode"`
}

// GetRawMempoolVerboseResult models the data returned from the getrawmempool
// command when the verbose flag is set.  When the verbose flag is not set,
// getrawmempool returns an array of transaction hashes.
type GetRawMempoolVerboseResult struct {
	Size             int32    `json:"size"`
	Vsize            int32    `json:"vsize"`
	Fee              float64  `json:"fee"`
	Time             int64    `json:"time"`
	Height           int64    `json:"height"`
	StartingPriority float64  `json:"startingpriority"`
	CurrentPriority  float64  `json:"currentpriority"`
	Depends          []string `json:"depends"`
}

// ScriptPubKeyResult models the scriptPubKey data of a tx script.  It is
// defined separately since it is used by multiple commands.
type ScriptPubKeyResult struct {
	Asm       string   `json:"asm"`
	Hex       string   `json:"hex,omitempty"`
	Type      string   `json:"type"`
	Addresses []string `json:"addresses,omitempty"`
}

type GetCrossChainDBResult struct {
	IncomingPool  []*wire.XchainData  `json:"incomingpool"`
	Btc2L2Pool    []*wire.XchainData  `json:"btc2l2pool"`
	L2BtcPool     []*wire.XchainData  `json:"l2btcpool"`
	BridgeSigners []*treasury.Signers `json:"bridgesigners"`
	XBTCAssets    []*treasury.Asset   `json:"xbtcassets"`
	XCAssets      []*wire.XchainData  `json:"xcassets"`
	RedeemDB      map[string]string   `json:"redeemdb"`
}

// GetTxOutResult models the data from the gettxout command.
type GetTxOutResult struct {
	BestBlock     string             `json:"bestblock"`
	Confirmations int64              `json:"confirmations"`
	Height        int32              `json:"height"`
	TokenType     uint64             `json:"tokentype"` // a wire.TokenType
	Value         interface{}        `json:"value"`     // a wire.TokenValue
	Rights        string             `json:"rights"`
	ScriptPubKey  ScriptPubKeyResult `json:"scriptPubKey"`
	Coinbase      bool               `json:"coinbase"`
}

type VertexDefinition struct {
	Lat int32 `json:"lat"` // a wire.Vertex
	Lng int32 `json:"lng"` // a wire.Vertex
	Alt int32 `json:"alt"` // a wire.Vertex
}
type BorderDefinition struct {
	Kind   int32            `json:"kind"` // 1
	Father string           `json:"father"`
	Begin  VertexDefinition `json:"begin"`
	End    VertexDefinition `json:"end"`
}
type PolygonDefinition struct {
	Kind    int32      `json:"kind"` // 2
	Polygon [][]string `json:"polygon"`
}
type RightDefinition struct {
	Kind   int32  `json:"kind"` // 4
	Father string `json:"father"`
	Desc   string `json:"desc"` // a wire.Vertex
	Attrib uint32 `json:"attrib"`
}
type RightSetDefinition struct {
	Kind   int32    `json:"kind"` // 5
	Rights []string `json:"rights"`
}

// GetTxOutResult models the data from the getdefine command.
type GetDefineResult struct {
	Definition map[string]interface{} `json:"definition"` // a wire.Vertex, Border, Polygon, or Right
}

// GetNetTotalsResult models the data returned from the getnettotals command.
type GetNetTotalsResult struct {
	TotalBytesRecv uint64 `json:"totalbytesrecv"`
	TotalBytesSent uint64 `json:"totalbytessent"`
	TimeMillis     int64  `json:"timemillis"`
}

// ScriptSig models a signature script.  It is defined separately since it only
// applies to non-coinbase.  Therefore the field in the Vin structure needs
// to be a pointer.
type ScriptSig struct {
	Asm string `json:"asm"`
	Hex string `json:"hex"`
}

// Vin models parts of the tx data.  It is defined separately since
// getrawtransaction, decoderawtransaction, and searchrawtransaction use the
// same structure.
type Vin struct {
	Coinbase       bool       `json:"coinbase"`
	Txid           string     `json:"txid"`
	Vout           uint32     `json:"vout"`
	ScriptSig      *ScriptSig `json:"scriptSig"`
	Sequence       uint32     `json:"sequence"`
	SignatureIndex uint32     `json:"signatureIndex"`
}

type Vdef struct {
	Type uint8 `json:"type"`
	// definition
	Father string   `json:"father"`
	Desc   string   `json:"desc"`
	Attrib uint8    `json:"attrib"`
	Hashes []string `json:"hashes"`
	Script string   `json:"script"`
}

// IsCoinBase returns a bool to show if a Vin is a Coinbase one or not.
func (v *Vin) IsCoinBase() bool {
	return v.Coinbase
}

// MarshalJSON provides a custom Marshal method for Vin.
func (v *Vin) MarshalJSON() ([]byte, error) {
	if v.IsCoinBase() {
		coinbaseStruct := struct {
			Coinbase       bool   `json:"coinbase"`
			Sequence       uint32 `json:"sequence"`
			SignatureIndex uint32 `json:"signatureIndex,omitempty"`
		}{
			Coinbase:       v.Coinbase,
			Sequence:       v.Sequence,
			SignatureIndex: v.SignatureIndex,
		}
		return json.Marshal(coinbaseStruct)
	}

	if v.SignatureIndex != 0 {
		txStruct := struct {
			Txid           string     `json:"txid"`
			Vout           uint32     `json:"vout"`
			ScriptSig      *ScriptSig `json:"scriptSig"`
			SignatureIndex uint32     `json:"signatureIndex"`
			Sequence       uint32     `json:"sequence"`
		}{
			Txid:           v.Txid,
			Vout:           v.Vout,
			ScriptSig:      v.ScriptSig,
			SignatureIndex: v.SignatureIndex,
			Sequence:       v.Sequence,
		}
		return json.Marshal(txStruct)
	}

	txStruct := struct {
		Txid      string     `json:"txid"`
		Vout      uint32     `json:"vout"`
		ScriptSig *ScriptSig `json:"scriptSig"`
		Sequence  uint32     `json:"sequence"`
	}{
		Txid:      v.Txid,
		Vout:      v.Vout,
		ScriptSig: v.ScriptSig,
		Sequence:  v.Sequence,
	}
	return json.Marshal(txStruct)
}

// PrevOut represents previous output for an input Vin.
type PrevOut struct {
	Addresses []string `json:"addresses,omitempty"`
	Value     float64  `json:"value"`
}

// VinPrevOut is like Vin except it includes PrevOut.  It is used by searchrawtransaction
type VinPrevOut struct {
	Coinbase       bool       `json:"coinbase"`
	Txid           string     `json:"txid"`
	Vout           uint32     `json:"vout"`
	ScriptSig      *ScriptSig `json:"scriptSig"`
	SignatureIndex uint32     `json:"signatureIndex"`
	PrevOut        *PrevOut   `json:"prevOut"`
	Sequence       uint32     `json:"sequence"`
}

// IsCoinBase returns a bool to show if a Vin is a Coinbase one or not.
func (v *VinPrevOut) IsCoinBase() bool {
	return v.Coinbase
}

// MarshalJSON provides a custom Marshal method for VinPrevOut.
func (v *VinPrevOut) MarshalJSON() ([]byte, error) {
	if v.IsCoinBase() {
		coinbaseStruct := struct {
			Coinbase bool   `json:"coinbase"`
			Sequence uint32 `json:"sequence"`
		}{
			Coinbase: v.Coinbase,
			Sequence: v.Sequence,
		}
		return json.Marshal(coinbaseStruct)
	}

	if v.SignatureIndex != 0 {
		txStruct := struct {
			Txid           string     `json:"txid"`
			Vout           uint32     `json:"vout"`
			ScriptSig      *ScriptSig `json:"scriptSig"`
			SignatureIndex uint32     `json:"signatureIndex"`
			PrevOut        *PrevOut   `json:"prevOut,omitempty"`
			Sequence       uint32     `json:"sequence"`
		}{
			Txid:           v.Txid,
			Vout:           v.Vout,
			ScriptSig:      v.ScriptSig,
			SignatureIndex: v.SignatureIndex,
			PrevOut:        v.PrevOut,
			Sequence:       v.Sequence,
		}
		return json.Marshal(txStruct)
	}

	txStruct := struct {
		Txid      string     `json:"txid"`
		Vout      uint32     `json:"vout"`
		ScriptSig *ScriptSig `json:"scriptSig"`
		PrevOut   *PrevOut   `json:"prevOut,omitempty"`
		Sequence  uint32     `json:"sequence"`
	}{
		Txid:      v.Txid,
		Vout:      v.Vout,
		ScriptSig: v.ScriptSig,
		PrevOut:   v.PrevOut,
		Sequence:  v.Sequence,
	}
	return json.Marshal(txStruct)
}

// Vout models parts of the tx data.  It is defined separately since both
// getrawtransaction and decoderawtransaction use the same structure.
type Vout struct {
	TokenType    uint64                 `json:"tokentype"`
	Value        map[string]interface{} `json:"value"`
	Rights       string                 `json:"rights"`
	N            uint32                 `json:"n"`
	ScriptPubKey ScriptPubKeyResult     `json:"scriptPubKey"`
}

// GetMiningInfoResult models the data from the getmininginfo command.
type GetMiningInfoResult struct {
	Blocks           int64  `json:"blocks"`
	CurrentBlockSize uint64 `json:"currentblocksize"`
	//	CurrentBlockLimit uint64  `json:"currentblocklimit"`
	CurrentBlockTx uint64  `json:"currentblocktx"`
	Difficulty     float64 `json:"difficulty"`
	Errors         string  `json:"errors"`
	Generate       bool    `json:"generate"`
	GenProcLimit   int32   `json:"genproclimit"`
	HashesPerSec   int64   `json:"hashespersec"`
	NetworkHashPS  int64   `json:"networkhashps"`
	PooledTx       uint64  `json:"pooledtx"`
	TestNet        bool    `json:"testnet"`
}

// GetWorkResult models the data from the getwork command.
type GetWorkResult struct {
	Data     string `json:"data"`
	Hash1    string `json:"hash1"`
	Midstate string `json:"midstate"`
	Target   string `json:"target"`
}

// InfoChainResult models the data returned by the chain server getinfo command.
type InfoChainResult struct {
	Version         int32   `json:"version"`
	ProtocolVersion int32   `json:"protocolversion"`
	Blocks          int32   `json:"blocks"`
	TimeOffset      int64   `json:"timeoffset"`
	Connections     int32   `json:"connections"`
	Proxy           string  `json:"proxy"`
	Difficulty      float64 `json:"difficulty"`
	TestNet         bool    `json:"testnet"`
	RelayFee        float64 `json:"relayfee"`
	Errors          string  `json:"errors"`
}

// TxRawResult models the data from the getrawtransaction command.
type TxRawResult struct {
	Hex  string `json:"hex"`
	Txid string `json:"txid"`
	Hash string `json:"hash,omitempty"`
	Size int32  `json:"size,omitempty"`
	//	Vsize         int32  `json:"vsize,omitempty"`
	Version       int32  `json:"version"`
	LockTime      uint32 `json:"locktime"`
	Vdef          []Vdef `json:"vdef"`
	Vin           []Vin  `json:"vin"`
	Vout          []Vout `json:"vout"`
	BlockHash     string `json:"blockhash,omitempty"`
	Confirmations uint64 `json:"confirmations,omitempty"`
	Time          int64  `json:"time,omitempty"`
	Blocktime     int64  `json:"blocktime,omitempty"`
}

// DebugReply
type DebugReply struct {
	Result string `json:"result"` // Min Relay Fee per KB for priority Tx
	Line   uint32 `json:"line"`
}

// MiningPolicy, miner specific policy
type MiningPolicy struct {
	RelayFee        int64 `json:"relayfee"`        // Min Relay Fee per KB for priority Tx
	BorderFee       int64 `json:"borderfee"`       // Fee per top border
	SubBorderFee    int64 `json:"borderfee"`       // Fee per sub border
	MaxExecSteps    int32 `json:"maxexecsteps"`    // max allowed contract exec steps
	ContractExecFee int64 `json:"contractexecfee"` // Contract Exec Fee per K steps
	MinContractFee  int64 `json:"mincontractfee"`  // minimal contract exec fee
}

// MultiSigAddr
type MultiSigAddr struct {
	Address string `json:"address"`
	Script  string `json:"script"`
}

type BtcL2Script struct {
	Addresses []string `json:"addresses"`
	Script    string   `json:"script"`
}

// Try result
type TryResult struct {
	Result string `json:"result"`
	Tx     string `json:"tx"`
}

// SearchRawTransactionsResult models the data from the searchrawtransaction
// command.
type SearchRawTransactionsResult struct {
	Hex           string       `json:"hex,omitempty"`
	Txid          string       `json:"txid"`
	Hash          string       `json:"hash"`
	Size          string       `json:"size"`
	Version       int32        `json:"version"`
	LockTime      uint32       `json:"locktime"`
	Vin           []VinPrevOut `json:"vin"`
	Vout          []Vout       `json:"vout"`
	BlockHash     string       `json:"blockhash,omitempty"`
	Confirmations uint64       `json:"confirmations,omitempty"`
	Height        uint32       `json:"height,omitempty"`
	Blocktime     int64        `json:"blocktime,omitempty"`
}

type SearchRawTransactionsRawResult struct {
	Height    uint32 `json:"height"`
	Txid      string `json:"txid"`
	Hex       string `json:"hex"`
	BlockHash string `json:"blockhash"`
	Blocktime int64  `json:"blocktime"`
}

// TxRawDecodeResult models the data from the decoderawtransaction command.
type TxRawDecodeResult struct {
	Txid     string `json:"txid"`
	Version  int32  `json:"version"`
	Locktime uint32 `json:"locktime"`
	Vdef     []Vdef `json:"vdef"`
	Vin      []Vin  `json:"vin"`
	Vout     []Vout `json:"vout"`
}

// ValidateAddressChainResult models the data returned by the chain server
// validateaddress command.
type ValidateAddressChainResult struct {
	IsValid bool   `json:"isvalid"`
	Address string `json:"address,omitempty"`
}
