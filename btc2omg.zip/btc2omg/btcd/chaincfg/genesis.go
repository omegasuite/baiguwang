// Copyright (c) 2014-2016 The btcsuite developers
// Copyright (c) 2018-2021 The Omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package chaincfg

import (
	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg/chainhash"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire"
	"github.com/btcsuite/btcd/btc2omg/omega"
)

// GenesisMerkleRoot is the hash of the first transaction in the genesis block
// for the main network. ----
var GenesisMerkleRoot = map[uint32]chainhash.Hash{
	0xA117FE3D: omega.MainNetGenesisMerkleRoot,
	0x956ca476: omega.MainNetGenesisMerkleRoot956ca476,
}

// GenesisBlock defines the genesis block of the block chain which serves as the
// public transaction ledger for the main network.
var GenesisBlock = map[uint32]*wire.MsgBlock{
	0xA117FE3D: &omega.MainNetGenesisBlock,
	0x956ca476: &omega.MainNetGenesisBlock956ca476,
}

var GenesisMinerBlock = map[uint32]*wire.MingingRightBlock{
	0xA117FE3D: &omega.MainNetGenesisMinerBlock,
	0x956ca476: &omega.MainNetGenesisMinerBlock956ca476,
}

// GenesisHash is the hash of the first block in the block chain for the main
// network (genesis block). ----
var GenesisHash = map[uint32]*chainhash.Hash{
	0xA117FE3D: &omega.MainNetGenesisHash[0],
	0x956ca476: &omega.MainNetGenesisHash956ca476[0],
}
var GenesisMinerHash = map[uint32]*chainhash.Hash{
	0xA117FE3D: &omega.MainNetGenesisHash[1],
	0x956ca476: &omega.MainNetGenesisHash956ca476[1],
}

// RegTestGenesisHash is the hash of the first block in the block chain for the
// regression test network (genesis block).
var RegTestGenesisHash = map[uint32]chainhash.Hash{
	0xA117FE3D: chainhash.Hash{},
	0x956ca476: chainhash.Hash{},
}
var RegTestGenesisMinerHash = map[uint32]chainhash.Hash{
	0xA117FE3D: chainhash.Hash{},
	0x956ca476: chainhash.Hash{},
}

// RegTestGenesisMerkleRoot is the hash of the first transaction in the genesis
// block for the regression test network.  It is the same as the merkle root for
// the main network.
var RegTestGenesisMerkleRoot = map[uint32]chainhash.Hash{
	0xA117FE3D: chainhash.Hash{},
	0x956ca476: chainhash.Hash{},
}

// TestNet3GenesisHash is the hash of the first block in the block chain for the
// test network (version 3).
var TestNet3GenesisHash = map[uint32]*chainhash.Hash{
	0xA117FE3D: &omega.TestNetGenesisHash[0],
	0x956ca476: &omega.TestNetGenesisHash956ca476[0],
}
var TestNet3GenesisMinerHash = map[uint32]*chainhash.Hash{
	0xA117FE3D: &omega.TestNetGenesisHash[1],
	0x956ca476: &omega.TestNetGenesisHash956ca476[1],
}

// TestNet3GenesisMerkleRoot is the hash of the first transaction in the genesis
// block for the test network (version 3).  It is the same as the merkle root
// for the main network.
var TestNet3GenesisMerkleRoot = map[uint32]chainhash.Hash{
	0xA117FE3D: omega.TestNetGenesisMerkleRoot,
	0x956ca476: omega.TestNetGenesisMerkleRoot956ca476,
}

// TestNet3GenesisBlock defines the genesis block of the block chain which
// serves as the public transaction ledger for the test network (version 3).
var TestNet3GenesisBlock = map[uint32]*wire.MsgBlock{
	0xA117FE3D: &omega.TestNetGenesisBlock,
	0x956ca476: &omega.TestNetGenesisBlock956ca476,
}
var TestNet3GenesisMinerBlock = map[uint32]*wire.MingingRightBlock{
	0xA117FE3D: &omega.TestNetGenesisMinerBlock,
	0x956ca476: &omega.TestNetGenesisMinerBlock956ca476,
}

// SimNetGenesisHash is the hash of the first block in the block chain for the
// simulation test network.
var SimNetGenesisHash = map[uint32]*chainhash.Hash{
	0xA117FE3D: &chainhash.Hash{},
	0x956ca476: &chainhash.Hash{},
}
var SimNetGenesisMinerHash = map[uint32]*chainhash.Hash{
	0xA117FE3D: &chainhash.Hash{},
	0x956ca476: &chainhash.Hash{},
}

// SimNetGenesisMerkleRoot is the hash of the first transaction in the genesis
// block for the simulation test network.  It is the same as the merkle root for
// the main network.
var SimNetGenesisMerkleRoot = map[uint32]chainhash.Hash{
	0xA117FE3D: chainhash.Hash{},
	0x956ca476: chainhash.Hash{},
}
