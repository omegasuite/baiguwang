// Copyright (c) 2013-2017 The btcsuite developers
// Copyright (c) 2018-2021 The Omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package blockchain

import (
	"bytes"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"github.com/btcsuite/btcd/btc2omg/btcd/blockchain/chainutil"
	"github.com/btcsuite/btcd/btc2omg/btcd/btcec"
	"github.com/btcsuite/btcd/btc2omg/btcd/database"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire/common"
	"github.com/btcsuite/btcd/btc2omg/omega/chainmap"
	"github.com/btcsuite/btcd/btc2omg/omega/ovm"
	"math"
	"math/big"
	"time"

	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg"
	"github.com/btcsuite/btcd/btc2omg/btcd/chaincfg/chainhash"
	"github.com/btcsuite/btcd/btc2omg/btcd/wire"
	"github.com/btcsuite/btcd/btc2omg/btcutil"
	"github.com/btcsuite/btcd/btc2omg/omega/token"
	//	"sort"
	"github.com/btcsuite/btcd/btc2omg/omega/validate"
	"github.com/btcsuite/btcd/btc2omg/omega/viewpoint"
)

const (
	// MaxTimeOffsetSeconds is the maximum number of seconds a block time
	// is allowed to be ahead of the current time.  This is currently 2
	// hours.
	MaxTimeOffsetSeconds = 2 * 60 * 60

	// baseSubsidy is the starting subsidy amount for mined blocks.  This
	// value is halved every SubsidyHalvingInterval blocks.
	baseSubsidy = 6 * btcutil.HaoPerBitcoin
)

var (
	// zeroHash is the zero value for a chainhash.Hash and is defined as
	// a package level variable to avoid the need to create a new instance
	// every time a check is needed.
	zeroHash chainhash.Hash
)

// isNullOutpoint determines whether or not a previous transaction output point
// is set.
func isNullOutpoint(outpoint *wire.OutPoint) bool {
	if outpoint.Hash == zeroHash { // outpoint.Index == math.MaxUint32 &&
		return true
	}
	return false
}

// IsCoinBaseTx determines whether or not a transaction is a coinbase.  A coinbase
// is a special transaction created by miners that has no inputs.  This is
// represented in the block chain by a transaction with a single input that has
// a previous output transaction index set to the maximum value along with a
// zero hash.
//
// This function only differs from IsCoinBase in that it works with a raw wire
// transaction as opposed to a higher level util transaction.
func IsCoinBaseTx(msgTx *wire.MsgTx) bool {
	// A coin base must only have one transaction input.
	if len(msgTx.TxIn) != 1 {
		return false
	}

	// The previous output of a coin base must have a max value index and
	// a zero hash.
	prevOut := &msgTx.TxIn[0].PreviousOutPoint
	if prevOut.Hash != zeroHash { // prevOut.Index != math.MaxUint32 ||
		return false
	}

	if len(msgTx.TxDef) != 0 {
		return false
	}

	for _, to := range msgTx.TxOut {
		if to.IsSeparator() {
			continue
		}
		if to.TokenType != common.FeeCoinTyp {
			return false
		}
	}

	return true
}

// IsCoinBase determines whether or not a transaction is a coinbase.  A coinbase
// is a special transaction created by miners that has no inputs.  This is
// represented in the block chain by a transaction with a single input that has
// a previous output transaction index set to the maximum value along with a
// zero hash.
//
// This function only differs from IsCoinBaseTx in that it works with a higher
// level util transaction as opposed to a raw wire transaction.
func IsCoinBase(tx *btcutil.Tx) bool {
	return tx.IsCoinBase()
}

func (b *BlockChain) isCoinBase(tx *btcutil.Tx) bool {
	if b.IsSVP {
		// A coin base must only have one transaction input.
		msgTx := tx.MsgTx()
		if len(msgTx.TxIn) != 1 {
			return false
		}

		// The previous output of a coin base must have a zero hash. index is height of the block.
		prevOut := &msgTx.TxIn[0].PreviousOutPoint
		if !prevOut.Hash.IsEqual(&chainhash.Hash{}) { // prevOut.Index != math.MaxUint32 ||
			return false
		}

		return true
	}
	return IsCoinBase(tx)
}

// SequenceLockActive determines if a transaction's sequence locks have been
// met, meaning that all the inputs of a given transaction have reached a
// height or time sufficient for their relative lock-time maturity.
func SequenceLockActive(sequenceLock *SequenceLock, blockHeight int32,
	medianTimePast time.Time) bool {

	// If either the seconds, or height relative-lock time has not yet
	// reached, then the transaction is not yet mature according to its
	// sequence locks.
	if sequenceLock.Seconds >= medianTimePast.Unix() ||
		sequenceLock.BlockHeight >= blockHeight {
		return false
	}

	return true
}

const (
	// LockTimeThreshold is the number below which a lock time is
	// interpreted to be a block number.
	LockTimeThreshold = 0x5effa4cf // genesis time
)

// IsFinalizedTransaction determines whether or not a transaction is finalized.
func IsFinalizedTransaction(tx *btcutil.Tx, blockHeight int32, blockTime time.Time) bool {
	msgTx := tx.MsgTx()

	// Lock time of zero means the transaction is finalized.
	lockTime := msgTx.LockTime
	if (msgTx.Version&wire.TxExpire != 0) || lockTime == 0 {
		return true
	}

	// The lock time field of a transaction is either a block height at
	// which the transaction is finalized or a timestamp depending on if the
	// value is before the txscript.LockTimeThreshold.  When it is under the
	// threshold it is a block height.
	blockTimeOrHeight := int64(0)
	if lockTime < LockTimeThreshold {
		blockTimeOrHeight = int64(blockHeight)
	} else {
		blockTimeOrHeight = blockTime.Unix()
	}
	if int64(lockTime) < blockTimeOrHeight {
		return true
	}

	// At this point, the transaction's lock time hasn't occurred yet, but
	// the transaction might still be finalized if the sequence number
	// for all transaction inputs is maxed out.

	// miner packed cross chain
	if !msgTx.IsCrossChain() {
		for _, txIn := range msgTx.TxIn {
			if txIn.PreviousOutPoint.Hash.IsEqual(&zerohash) {
				continue
			}
			if txIn.Sequence != math.MaxUint32 {
				return false
			}
		}
	}

	return true
}

// CalcBlockSubsidy returns the subsidy amount a block at the provided height
// should have. This is mainly used for determining how much the coinbase for
// newly generated blocks awards as well as validating the coinbase for blocks
// has the expected value.
//
// The subsidy is halved every SubsidyReductionInterval blocks.  Mathematically
// this is: baseSubsidy / 2^(height/SubsidyReductionInterval)
//
// At the target block generation rate for the main network, this is
// approximately every 4 years.
func CalcBlockSubsidy(height int32, chainParams *chaincfg.Params, prevPows uint) int64 {
	if chainParams.SubsidyReductionInterval == 0 {
		return baseSubsidy
	}

	// Equivalent to: baseSubsidy / 2^(height/subsidyHalvingInterval)
	return baseSubsidy >> (prevPows + uint(height/chainParams.SubsidyReductionInterval))
}

// CheckTransactionSanity performs some preliminary checks on a transaction to
// ensure it is sane.  These checks are context free.
func CheckTransactionSanity(tx *btcutil.Tx) error {
	// A transaction must have at least one input.
	msgTx := tx.MsgTx()

	if (msgTx.Version & (wire.TxExpire | wire.TxNoLock)) == (wire.TxExpire | wire.TxNoLock) {
		return ruleError(ErrNoTxInputs, "transaction has conflicting version flags")
	}

	forfeit := msgTx.Version&wire.TxTypeMask == wire.ForfeitTxVersion

	contract := false
	for _, to := range msgTx.TxOut {
		if to.IsSeparator() {
			continue
		}
		contract = contract || to.PkScript[0] == 0x88 // IsContract(to.PkScript[0])
	}

	if (forfeit || contract) && (msgTx.Version&wire.TxExpire) == 0 && msgTx.LockTime != 0 {
		return ruleError(ErrBadTxInput, "transaction has contract call and LockTime is not 0")
	}

	if forfeit && len(msgTx.TxDef) > 0 {
		return ruleError(ErrBadTxInput, "forfeiture transaction may not have definition")
	}

	if len(msgTx.TxIn) == 0 && !contract {
		// coin base Tx has len = 1
		return ruleError(ErrNoTxInputs, "transaction has no inputs")
	}

	// A transaction must have at least one output.
	if len(msgTx.TxOut) == 0 {
		return ruleError(ErrNoTxOutputs, "transaction has no outputs")
	}

	// Ensure the transaction amounts are in range.  Each transaction
	// output must not be negative or more than the max allowed per
	// transaction.  Also, the total of all outputs must abide by the same
	// restrictions.
	totals := make(map[uint64]int64)
	for _, txOut := range msgTx.TxOut {
		if txOut.IsSeparator() || !txOut.IsNumeric() {
			// ignore those none numeric tokens here
			continue
		}

		if txOut.IsCrossChain() {
			continue
		}

		v := txOut.Value.(*token.NumToken)
		hao := v.Val
		if hao < 0 {
			str := fmt.Sprintf("transaction output has negative "+
				"value of %v", hao)
			return ruleError(ErrBadTxOutValue, str)
		}
		if txOut.TokenType == common.FeeCoinTyp && hao > btcutil.MaxHao {
			str := fmt.Sprintf("transaction output value of %v is "+
				"higher than max allowed value of %v", hao,
				btcutil.MaxHao)
			return ruleError(ErrBadTxOutValue, str)
		}

		// Two's complement int64 overflow guarantees that any overflow
		// is detected and reported.  This is impossible for Bitcoin, but
		// perhaps possible if an alt increases the total money supply.
		if _, ok := totals[txOut.TokenType]; ok {
			totals[txOut.TokenType] += hao
		} else {
			totals[txOut.TokenType] = hao
		}

		if totals[txOut.TokenType] < 0 {
			str := fmt.Sprintf("transaction output is negative")
			return ruleError(ErrBadTxOutValue, str)
		}
		if txOut.TokenType == common.FeeCoinTyp && totals[txOut.TokenType] > btcutil.MaxHao {
			str := fmt.Sprintf("total value of all transaction "+
				"outputs is %v which is higher than max "+
				"allowed value of %v", totals[txOut.TokenType],
				btcutil.MaxHao)
			return ruleError(ErrBadTxOutValue, str)
		}
	}

	// check welformness of defitions w/i this tx (regardless reference)
	if err := validate.CheckDefinitions(msgTx); err != nil {
		return err
	}

	var zerohash chainhash.Hash
	// Check for duplicate transaction inputs.
	existingTxOut := make(map[wire.OutPoint]struct{})
	for _, txIn := range msgTx.TxIn {
		if txIn.PreviousOutPoint.Hash.IsEqual(&zerohash) {
			continue
		}
		if txIn.SignatureIndex == 0xFFFFFFFF && len(tx.MsgTx().TxOut) == 0 {
			continue
		}
		if _, exists := existingTxOut[txIn.PreviousOutPoint]; exists {
			return ruleError(ErrDuplicateTxInputs, "transaction "+
				"contains duplicate inputs")
		}
		if contract && txIn.Sequence != 0xFFFFFFFF {
			return ruleError(ErrBadTxInput, "transaction with contract call and unfinalized input")
		}
		existingTxOut[txIn.PreviousOutPoint] = struct{}{}
	}

	// Coinbase script length must be between min and max length.
	if !tx.MsgTx().TxIn[0].PreviousOutPoint.Hash.IsEqual(&zerohash) { // !coinbase
		// Previous transaction outputs referenced by the inputs to this
		// transaction must not be null.
		for _, txIn := range msgTx.TxIn {
			if txIn.PreviousOutPoint.Hash.IsEqual(&zerohash) {
				continue
			}
			if txIn.SignatureIndex == 0xFFFFFFFF && len(tx.MsgTx().TxOut) == 0 {
				continue
			}
			if isNullOutpoint(&txIn.PreviousOutPoint) {
				return ruleError(ErrBadTxInput, "transaction "+
					"input refers to previous output that "+
					"is null")
			}
		}
	}

	return nil
}

func (b *BlockChain) Rotation(hash chainhash.Hash) int32 {
	best := b.BestSnapshot()
	rotate := int32(best.LastRotation)
	p := b.NodeByHash(&best.Hash)
	if p.Height > best.Height {
		return -1
	}
	for ; p != nil && !p.Hash.IsEqual(&hash); p = b.ParentNode(p) {
		switch {
		case p.Data.GetNonce() > 0:
			rotate -= wire.POWRotate

		case p.Data.GetNonce() <= -wire.MINER_RORATE_FREQ:
			rotate = -(p.Data.GetNonce() + wire.MINER_RORATE_FREQ) - 1
		}
	}
	if p == nil {
		return -1
	}
	return rotate
}

// checkProofOfWork ensures the block header bits which indicate the target
// difficulty is in min/max range and that the block hash is less than the
// target difficulty as claimed.
//
// The flags modify the behavior of this function as follows:
//  - BFNoPoWCheck: The check to ensure the block hash is less than the target
//    difficulty is not performed.

// if return value is nil,false, the block is ok. if nil,true, it may be added as orphan
// but can not be connected. if err,_, it is a bad block and should be discarded
func (b *BlockChain) checkProofOfWork(block *btcutil.Block, parent *chainutil.BlockNode, powLimit *big.Int, flags BehaviorFlags) (error, bool) {
	best := b.BestSnapshot()
	//	bits := best.Bits
	rotate := best.LastRotation

	header := &block.MsgBlock().Header

	if parent.Hash != best.Hash {
		pn := b.NodeByHash(&parent.Hash)
		fork := b.FindFork(pn)

		if fork == nil {
			return nil, true
		}

		// parent is not the tip, go back to find correct rotation
		for p := b.BestChain.Tip(); p != nil && p != fork; p = b.ParentNode(p) {
			switch {
			case p.Data.GetNonce() > 0:
				rotate -= wire.POWRotate

			case p.Data.GetNonce() <= -wire.MINER_RORATE_FREQ:
				rotate--
			}
		}
		for p := pn; p != nil && p != fork; p = b.ParentNode(p) {
			switch {
			case p.Data.GetNonce() > 0:
				rotate += wire.POWRotate

			case p.Data.GetNonce() <= -wire.MINER_RORATE_FREQ:
				rotate++
			}
		}
	}

	if header.Nonce > 0 {
		s, err := b.Miners.BlockByHeight(int32(rotate))
		if err != nil || s == nil {
			// will make the block orphan, because miner chain is not ready
			return nil, true
		}

		bits := s.MsgBlock().Bits

		// The target difficulty must be larger than zero.
		target := CompactToBig(bits)
		if target.Sign() <= 0 {
			str := fmt.Sprintf("block target difficulty of %064x is too low",
				target)
			return ruleError(ErrUnexpectedDifficulty, str), false
		}

		// The target difficulty must be less than the maximum allowed.
		if target.Cmp(powLimit) > 0 && flags&BFEasyBlocks == 0 {
			str := fmt.Sprintf("block target difficulty of %064x is "+
				"higher than max of %064x", target, powLimit)
			return ruleError(ErrUnexpectedDifficulty, str), false
		}

		// The block hash must be less than the claimed target unless the flag
		// to avoid proof of work checks is set.
		if flags&BFNoPoWCheck != BFNoPoWCheck {
			// The block hash must be less than the claimed target.
			hash := header.BlockHash()
			hashNum := HashToBig(&hash)
			target = target.Mul(target, big.NewInt(40))

			if hashNum.Cmp(target) > 0 {
				str := fmt.Sprintf("block hash of %064x is higher than expected max of %064x", hashNum, target)
				return ruleError(ErrHighHash, str), false
			}
		}
	} else {
		if parent == nil { // never
			return nil, true
		}

		pnonce := parent.Data.GetNonce()

		// examine nonce
		if pnonce > 0 {
			// if previous block was a POW block, this block must be either a POW block, or a rotate block
			if header.Nonce != -1 {
				return fmt.Errorf("The previous block was a POW block, this block must be either a POW block, or a rotate block."), true
			}
		} else {
			switch {
			case pnonce == -wire.MINER_RORATE_FREQ+1:
				// this is a rotation block, nonce must be -(height of next Miner block)
				if header.Nonce != -int32(rotate+1+wire.MINER_RORATE_FREQ) {
					//					str := fmt.Sprintf("The this is a rotation block, nonce %d must be height of next Miner block %d.", -header.Nonce, rotate + 1 + wire.MINER_RORATE_FREQ)
					return fmt.Errorf("The this is a rotation block, nonce %d must be height of next Miner block %d.", -header.Nonce, rotate+1+wire.MINER_RORATE_FREQ), true
					// ruleError(ErrHighHash, str)
				}

			case pnonce <= -wire.MINER_RORATE_FREQ:
				// previous block is a rotation block, this block none must be -1
				if header.Nonce != -1 {
					//					str := fmt.Sprintf("Previous block is a rotation block, this block nonce must be -1.")
					return fmt.Errorf("Previous block is a rotation block, this block nonce must be -1."), true
				}

			default:
				if header.Nonce != pnonce-1 {
					// if parent.Nonce < 0 && header.Nonce != -((-parent.Nonce + 1) % ROT) { error }
					//					str := fmt.Sprintf("The previous block is a block in a series, this block must be the next in the series (%d vs. %d).", header.Nonce, parent.nonce)
					return fmt.Errorf("The previous block is a block in a series, this block must be the next in the series (%d vs. %d).", header.Nonce, parent.Data.GetNonce()), true
				}
			}
		}

		if wire.CommitteeSize > 1 && flags&(BFNoConnect|BFSubmission) != 0 {
			return fmt.Errorf("Unexpected flags"), true
		}

		if len(block.MsgBlock().Transactions[0].SignatureScripts) <= wire.CommitteeSigs {
			return fmt.Errorf("Insufficient signature"), false
		}
		if len(block.MsgBlock().Transactions[0].SignatureScripts[1]) < btcec.PubKeyBytesLenCompressed {
			return fmt.Errorf("Incorrect signature"), false
		}

		// examine signatures
		hash := MakeMinerSigHash(block.Height(), *block.Hash())

		committee := make(map[[20]byte]struct{})
		nsigned := 0

		var imin = false
		var meme btcutil.Address

		var mbs [3]*wire.MinerBlock

		for i := rotate - wire.CommitteeSize + 1; i <= rotate; i++ {
			mb, _ := b.Miners.BlockByHeight(int32(i))
			if mb == nil {
				continue
			}
			mbs[i-(rotate-wire.CommitteeSize+1)] = mb
		}

		awardto := make(map[[20]byte]struct{})
		if !b.IsSVP {
			awd := make(map[uint64]int64)
			for _, txo := range block.MsgBlock().Transactions[0].TxOut {
				if _, ok := awd[txo.TokenType]; !ok {
					_, awd[txo.TokenType] = txo.Value.Value()
				}
			}
			for _, txo := range block.MsgBlock().Transactions[0].TxOut {
				if txo.IsSeparator() {
					break
				}
				if txo.TokenType != common.FeeCoinTyp && txo.TokenType != (common.BTCCHAINID<<40) && txo.TokenType != common.OmegaCoinTyp {
					return fmt.Errorf("Coinbase output tokentype is not 0."), false
				}
				dif := txo.Value.(*token.NumToken).Val - awd[txo.TokenType]
				if dif < 0 {
					dif = -dif
				}
				if dif > 1 {
					return fmt.Errorf("Award is not evenly distributed among quanlified miners."), false
				}
				var tw [20]byte
				copy(tw[:], txo.PkScript[1:21])
				awardto[tw] = struct{}{}
			}
		}

		for i := rotate - wire.CommitteeSize + 1; i <= rotate; i++ {
			mb := mbs[i-(rotate-wire.CommitteeSize+1)]
			if mb == nil {
				continue
			}

			if !b.IsSVP {
				if _, err := b.CheckCollateral(mb, &parent.Hash, BFNone); err != nil {
					if _, ok := awardto[mb.MsgBlock().Miner]; ok {
						return fmt.Errorf("Coinbase award to miner with insufficient collateral."), false
					}
				} else {
					if _, ok := awardto[mb.MsgBlock().Miner]; !ok {
						return nil, true
					}
				}
			}

			committee[mb.MsgBlock().Miner] = struct{}{}
			delete(awardto, mb.MsgBlock().Miner)

			if !imin {
				for j, me := range b.Miner {
					imin = bytes.Compare(me.ScriptAddress(), mb.MsgBlock().Miner[:]) == 0
					if imin {
						meme = b.Miner[j]
						break
					}
				}
			}
		}
		if !b.IsSVP && len(awardto) != 0 {
			return nil, true
		}

		tbr := make([]int, 0, 3)

		for k, sign := range block.MsgBlock().Transactions[0].SignatureScripts[1:] {
			signer, err := btcutil.VerifySigScript(sign, hash, b.ChainParams)
			if err != nil {
				return err, false
			}

			pkh := signer.Hash160()
			if _, ok := committee[*pkh]; !ok {
				tbr = append(tbr, k+1)
				continue
			}
			delete(committee, *pkh)

			imin = imin && bytes.Compare(meme.ScriptAddress(), (*pkh)[:]) != 0

			nsigned++
		}

		for k := len(tbr) - 1; k >= 0; k-- {
			block.MsgBlock().Transactions[0].SignatureScripts =
				append(block.MsgBlock().Transactions[0].SignatureScripts[:tbr[k]], block.MsgBlock().Transactions[0].SignatureScripts[tbr[k]+1:]...)
		}

		if nsigned < wire.CommitteeSigs {
			return fmt.Errorf("Insufficient number of Miner signatures."), false
		}
	}

	return nil, false
}

// CheckProofOfWork ensures the block header bits which indicate the target
// difficulty is in min/max range and that the block hash is less than the
// target difficulty as claimed.
func (b *BlockChain) CheckProofOfWork(block *btcutil.Block, powLimit *big.Int) error {
	behaviorFlags := BFNone
	if b.ChainParams.Net == common.TestNet || b.ChainParams.Net == common.SimNet || b.ChainParams.Net == common.RegNet {
		behaviorFlags |= BFEasyBlocks
	}
	err, _ := b.checkProofOfWork(block, b.BestChain.Tip(), powLimit, behaviorFlags)
	return err
}

func CheckProofOfWork(stubBlock *btcutil.Block, powLimit *big.Int) error {
	return nil
}

func (b *BlockChain) MainChainTx(txHash chainhash.Hash) *wire.MsgTx {
	// Look up the location of the transaction.
	blockRegion, err := b.indexManager.TxBlockRegion(&txHash)
	if err != nil || blockRegion == nil {
		return nil
	}

	var txBytes []byte
	err = b.db.View(func(dbTx database.Tx) error {
		var err error
		txBytes, err = dbTx.FetchBlockRegion(blockRegion)
		return err
	})

	if err != nil {
		return nil
	}

	// Deserialize the transaction
	var msgTx wire.MsgTx
	err = msgTx.Deserialize(bytes.NewReader(txBytes))
	if err != nil {
		return nil
	}
	return &msgTx
}

func (b *BlockChain) TxInMainChain(txHash *chainhash.Hash, height int32) bool {
	// Look up the location of the transaction.
	blockRegion, err := b.indexManager.TxBlockRegion(txHash)
	if err != nil || blockRegion == nil {
		return false
	}

	blkHeight, err := b.BlockHeightByHash(blockRegion.Hash)
	return err == nil && blkHeight <= height
}

// CountSigOps returns the number of signature operations for all transaction
// input and output scripts in the provided transaction.  This uses the
// quicker, but imprecise, signature operation counting mechanism from
// txscript.
func CountSigOps(tx *btcutil.Tx) int {
	if tx.IsCoinBase() {
		return 0
	}
	return len(tx.MsgTx().SignatureScripts)
}

func MakeMinerSigHash(height int32, hash chainhash.Hash) []byte {
	s1 := "Omega chain Miner block "
	s2 := " at height "
	lenth := 36 + len(s1) + len(s2)
	t := make([]byte, lenth)
	copy(t[:], []byte(s1))
	copy(t[len(s1):], hash[:])
	binary.LittleEndian.PutUint32(t[len(s1)+32:], uint32(height))
	return chainhash.DoubleHashB(t[:])
}

// checkBlockHeaderSanity performs some preliminary checks on a block header to
// ensure it is sane before continuing with processing.  These checks are
// context free.
//
// The flags do not modify the behavior of this function directly, however they
// are needed to pass along to checkProofOfWork.
func checkBlockHeaderSanity(header *wire.BlockHeader, powLimit *big.Int, timeSource chainutil.MedianTimeSource, flags BehaviorFlags) error {
	// A block timestamp must not have a greater precision than one second.
	// This check is necessary because Go time.Time values support
	// nanosecond precision whereas the consensus rules only apply to
	// seconds and it's much nicer to deal with standard Go time values
	// instead of converting to seconds everywhere.
	if !header.Timestamp.Equal(time.Unix(header.Timestamp.Unix(), 0)) {
		str := fmt.Sprintf("block timestamp of %v has a higher "+
			"precision than one second", header.Timestamp)
		return ruleError(ErrInvalidTime, str)
	}

	// Ensure the block time is not too far in the future.
	maxTimestamp := timeSource.AdjustedTime().Add(time.Second *
		MaxTimeOffsetSeconds)
	if header.Timestamp.After(maxTimestamp) {
		str := fmt.Sprintf("block timestamp of %v is too far in the "+
			"future", header.Timestamp)
		return ruleError(ErrTimeTooNew, str)
	}

	return nil
}

// checkBlockSanity performs some preliminary checks on a block to ensure it is
// sane before continuing with block processing.  These checks are context free.
//
// The flags do not modify the behavior of this function directly, however they
// are needed to pass along to checkBlockHeaderSanity.
func (b *BlockChain) checkBlockSanity(block *btcutil.Block, powLimit *big.Int, timeSource chainutil.MedianTimeSource, flags BehaviorFlags) error {
	msgBlock := block.MsgBlock()
	header := &msgBlock.Header
	err := checkBlockHeaderSanity(header, powLimit, timeSource, flags)
	if err != nil {
		return err
	}

	// A block must have at least one transaction.
	numTx := len(msgBlock.Transactions)
	if numTx == 0 {
		return ruleError(ErrNoTransactions, "block does not contain "+
			"any transactions")
	}

	// The first transaction in a block must be a coinbase.
	transactions := block.Transactions()
	if !b.isCoinBase(transactions[0]) {
		return ruleError(ErrFirstTxNotCoinbase, "first transaction in "+
			"block is not a coinbase")
	}

	// All forfeiture txs must be immediately after coinbase
	minrtx := 0
	for i, tx := range transactions[1:] {
		if b.isCoinBase(tx) {
			str := fmt.Sprintf("block contains second coinbase at "+
				"index %d", i+1)
			return ruleError(ErrMultipleCoinbases, str)
		}
		// forfeiture txs must be immediately after coinbase. there could be more than one
		if tx.MsgTx().Version&wire.TxTypeMask == wire.ForfeitTxVersion && i > minrtx {
			str := fmt.Sprintf("block contains forfeiture coinbase at "+
				"index %d", i+1)
			return ruleError(ErrMultipleCoinbases, str)
		} else if tx.MsgTx().Version&wire.TxTypeMask == wire.ForfeitTxVersion {
			minrtx++
		}
		if len(tx.MsgTx().TxIn) > 1000 {
			str := fmt.Sprintf("Too many inputs in a transactions %d", len(tx.MsgTx().TxIn))
			return ruleError(ErrMultipleCoinbases, str)
		}
		if len(tx.MsgTx().TxOut) > 1000 {
			str := fmt.Sprintf("Too many outputs in a transactions %d", len(tx.MsgTx().TxOut))
			return ruleError(ErrMultipleCoinbases, str)
		}
		if len(tx.MsgTx().TxDef) > 1000 {
			str := fmt.Sprintf("Too many definitions in a transactions %d", len(tx.MsgTx().TxDef))
			return ruleError(ErrMultipleCoinbases, str)
		}
	}

	// Do some preliminary checks on each transaction to ensure they are
	// sane before continuing.
	for _, tx := range transactions {
		if (tx.MsgTx().Version&wire.TxExpire) != 0 && tx.MsgTx().LockTime < uint32(block.Height()) {
			// tx lock time must not after block time
			str := fmt.Sprintf("block contains transaction whose execution time has expired")
			return ruleError(ErrExpiredTx, str)
		}

		err := CheckTransactionSanity(tx)
		if err != nil {
			return err
		}
	}

	// There are two hashes in a full block. One in header and one as coinbase's first
	// signature. The one in header hash is merkle root of all full tx w/o signature.
	// i.e., they include tx items generated by contracts. The one in coinbase is merkle
	// root of all raw tx w signature. i.e., they don't include tx items generated by
	// contracts. A SVP client will take a partial block w/o the hash in coinbase.
	/*
		if len(block.MsgBlock().Transactions[0].SignatureScripts) > 0 {
			merkles := BuildMerkleTreeStore(block.Transactions(), true, block.MsgBlock().Header.Version)
			calculatedMerkleRoot := merkles[len(merkles)-1]
			if bytes.Compare(block.MsgBlock().Transactions[0].SignatureScripts[0], calculatedMerkleRoot[:]) != 0 {
				str := fmt.Sprintf("block signature merkle root is invalid - block "+
					"indicates %v, but calculated value is %v",
					block.MsgBlock().Transactions[0].SignatureScripts[0], calculatedMerkleRoot)
				return ruleError(ErrBadMerkleRoot, str)
			}
		}
	*/

	// Check for duplicate transactions.  This check will be fairly quick
	// since the transaction hashes are already cached due to building the
	// merkle tree above.
	existingTxHashes := make(map[chainhash.Hash]struct{})
	for _, tx := range transactions {
		hash := tx.Hash()
		if _, exists := existingTxHashes[*hash]; exists {
			str := fmt.Sprintf("block contains duplicate transaction %v", hash)
			return ruleError(ErrDuplicateTx, str)
		}
		existingTxHashes[*hash] = struct{}{}
	}

	// The number of signature operations must be less than the maximum
	// allowed per block.
	totalSigOps := 0
	for _, tx := range transactions {
		// We could potentially overflow the accumulator so check for
		// overflow.
		lastSigOps := totalSigOps
		totalSigOps += CountSigOps(tx) // * chaincfg.WitnessScaleFactor)
		if totalSigOps < lastSigOps || totalSigOps > chaincfg.MaxBlockSigOpsCost {
			str := fmt.Sprintf("block contains too many signature "+
				"operations - got %v, max %v", totalSigOps,
				chaincfg.MaxBlockSigOpsCost)
			return ruleError(ErrTooManySigOps, str)
		}
	}

	return nil
}

// CheckBlockSanity performs some preliminary checks on a block to ensure it is
// sane before continuing with block processing.  These checks are context free.
//func CheckBlockSanity(block *btcutil.Block, powLimit *big.Int, timeSource chainutil.MedianTimeSource) error {
//	return checkBlockSanity(block, powLimit, timeSource, BFNone)
//}

// checkBlockHeaderContext performs several validation checks on the block header
// which depend on its position within the block chain.
//
// The flags modify the behavior of this function as follows:
//   - BFFastAdd: All checks except those involving comparing the header against
//     the checkpoints are not performed.
//
// This function MUST be called with the chain state lock held (for writes).
func (b *BlockChain) checkBlockHeaderContext(header *wire.BlockHeader, prevNode *chainutil.BlockNode, flags BehaviorFlags) error {
	fastAdd := flags&BFFastAdd == BFFastAdd
	if !fastAdd {
		// Ensure the timestamp for the block header is after the
		// median time of the last several blocks (medianTimeBlocks).
		medianTime := prevNode.CalcPastMedianTime()
		if !header.Timestamp.After(medianTime) {
			str := "block timestamp of %v is not after expected %v"
			str = fmt.Sprintf(str, header.Timestamp, medianTime)
			return ruleError(ErrTimeTooOld, str)
		}
	}

	var rotate int32
	if prevNode == nil {
		rotate = 0
	} else {
		dr := int32(0)
		p := prevNode
		for ; p != nil && p.Data.GetNonce() > -wire.MINER_RORATE_FREQ; p = p.Parent {
			if p.Data.GetNonce() > 0 {
				dr += wire.POWRotate
			}
		}
		if p == nil {
			rotate = dr - wire.POWRotate
		} else {
			rotate = -p.Data.GetNonce() - wire.MINER_RORATE_FREQ + dr
		}
	}

	mb, _ := b.Miners.BlockByHeight(rotate)
	if mb != nil && header.Version&^0xFFFF != mb.MsgBlock().Version&^0xFFFF {
		return ruleError(ErrBlockVersionTooOld, "Incorrect block version")
	}

	// The height of this block is one more than the referenced previous
	// block.
	blockHeight := prevNode.Height + 1

	// Ensure chain matches up to predetermined checkpoints.
	blockHash := header.BlockHash()
	if !b.verifyCheckpoint(blockHeight, &blockHash) {
		str := fmt.Sprintf("block at height %d does not match "+
			"checkpoint hash", blockHeight)
		return ruleError(ErrBadCheckpoint, str)
	}

	// Find the previous checkpoint and prevent blocks which fork the main
	// chain before it.  This prevents storage of new, otherwise valid,
	// blocks which build off of old blocks that are likely at a much easier
	// difficulty and therefore could be used to waste cache and disk space.
	checkpointNode, err := b.findPreviousCheckpoint()
	if err != nil {
		return err
	}
	if checkpointNode != nil && blockHeight < checkpointNode.Height {
		str := fmt.Sprintf("block at height %d forks the main chain "+
			"before the previous checkpoint at height %d",
			blockHeight, checkpointNode.Height)
		return ruleError(ErrForkTooOld, str)
	}

	return nil
}

// checkBlockContext peforms several validation checks on the block which depend
// on its position within the block chain.
//
// The flags modify the behavior of this function as follows:
//   - BFFastAdd: The transaction are not checked to see if they are finalized
//     and the somewhat expensive BIP0034 validation is not performed.
//
// The flags are also passed to checkBlockHeaderContext.  See its documentation
// for how the flags modify its behavior.
//
// This function MUST be called with the chain state lock held (for writes).
func (b *BlockChain) checkBlockContext(block *btcutil.Block, prevNode *chainutil.BlockNode, flags BehaviorFlags) error {
	// Perform all block header related validation checks.
	header := &block.MsgBlock().Header
	err := b.checkBlockHeaderContext(header, prevNode, flags)
	if err != nil {
		return err
	}

	fastAdd := flags&BFFastAdd == BFFastAdd
	if !fastAdd {
		if len(block.MsgBlock().Transactions) > wire.MaxTxPerBlock {
			str := fmt.Sprintf("Transactions exceed %d limit", wire.MaxTxPerBlock)
			return ruleError(ErrBlockWeightTooHigh, str)
		}

		// using the current median time past of the past block's
		// timestamps for all lock-time based checks.
		blockTime := header.Timestamp

		if blockTime.Unix() < prevNode.Data.TimeStamp() {
			str := fmt.Sprintf("block time is older than the previous block's: %s", header.BlockHash().String())
			return ruleError(ErrBlockTimeOutOfOrder, str)
		}

		blockTime = prevNode.CalcPastMedianTime()

		// The height of this block is one more than the referenced
		// previous block.
		blockHeight := prevNode.Height + 1

		if !b.IsSVP {
			// Ensure all transactions in the block are finalized.
			for _, tx := range block.Transactions() {
				if !IsFinalizedTransaction(tx, blockHeight, blockTime) {
					str := fmt.Sprintf("block contains unfinalized "+
						"transaction %v", tx.Hash())
					return ruleError(ErrUnfinalizedTx, str)
				}
			}
		}

		coinbaseTx := block.Transactions()[0]
		if len(coinbaseTx.MsgTx().TxIn) == 0 || blockHeight != int32(coinbaseTx.MsgTx().TxIn[0].PreviousOutPoint.Index) {
			str := fmt.Sprintf("Bad blockHeight in coinbaseTx"+
				"transaction %v", block.Hash())
			return ruleError(ErrBadCoinbaseScriptLen, str)
		}
	}

	// Validate the witness commitment (if any) within the
	// block.  This involves asserting that if the coinbase
	// contains the special commitment output, then this
	// merkle root matches a computed merkle root of all
	// the wtxid's of the transactions within the block. In
	// addition, various other checks against the
	// coinbase's witness stack.
	if err := ValidateWitnessCommitment(block); err != nil {
		return err
	}

	return nil
}

// CheckTransactionInputs performs a series of checks on the inputs to a
// transaction to ensure they are valid.  An example of some of the checks
// include verifying all inputs exist, ensuring the coinbase seasoning
// requirements are met, detecting double spends, validating all values and fees
// are in the legal range and the total output amount doesn't exceed the input
// amount, and verifying the signatures to prove the spender was the owner of
// the bitcoins and therefore allowed to spend them.  As it checks the inputs,
// it also calculates the total fees for the transaction and returns that value.
//
// NOTE: The transaction MUST have already been sanity checked with the
// CheckTransactionSanity function prior to calling this function.
func CheckTransactionInputs(tx *btcutil.Tx, txHeight int32, views *viewpoint.ViewPointSet, chainParams *chaincfg.Params) error {
	// Coinbase transactions have no inputs.
	if tx.MsgTx().IsBtcL2() || tx.MsgTx().IsCrossChain() {
		return nil
	}
	if tx.MsgTx().TxIn[0].PreviousOutPoint.Hash.IsEqual(&zerohash) { // coinbase
		return nil
	}

	utxoView := views.Utxo

	// polygon check
	if err := validate.CheckTransactionInputs(tx, views); err != nil {
		// actually check definitions only
		return err
	}
	//	var zerohash chainhash.Hash

	totalIns := make(map[uint64]int64)
	for txInIndex, txIn := range tx.MsgTx().TxIn {
		if txIn.IsSeparator() {
			break
		}
		if txIn.IsSepadding() {
			continue
		}

		// Ensure the referenced input transaction is available.
		utxo := utxoView.LookupEntry(txIn.PreviousOutPoint)
		if utxo == nil || utxo.IsSpent() {
			var wbuf bytes.Buffer
			tx.MsgTx().SerializeFull(&wbuf)

			str := fmt.Sprintf("validate: output %v referenced from "+
				"transaction %s:%d either does not exist or "+
				"has already been spent. tx = %s", txIn.PreviousOutPoint,
				tx.Hash(), txInIndex, hex.EncodeToString(wbuf.Bytes()))
			return ruleError(ErrMissingTxOut, str)
		}

		// Ensure the transaction is not spending coins which have not
		// yet reached the required coinbase maturity.
		if utxo.IsCoinBase() {
			originHeight := utxo.BlockHeight()
			blocksSincePrev := txHeight - originHeight
			coinbaseMaturity := int32(chainParams.CoinbaseMaturity)
			if originHeight != 0 && blocksSincePrev < coinbaseMaturity {
				str := fmt.Sprintf("tried to spend coinbase "+
					"transaction output %v from height %v "+
					"at height %v before required maturity "+
					"of %v blocks", txIn.PreviousOutPoint,
					originHeight, txHeight,
					coinbaseMaturity)
				return ruleError(ErrImmatureSpend, str)
			}
		}

		// Ensure the transaction amounts are in range.  Each of the
		// output values of the input transactions must not be negative
		// or more than the max allowed per transaction.  All amounts in
		// a transaction are in a unit value known as a hao.  One
		// bitcoin is a quantity of hao as defined by the
		// HaoPerBitcoin constant.
		if utxo.TokenType&1 != 0 {
			continue
		}

		originTxHao := utxo.Amount.(*token.NumToken).Val
		if originTxHao < 0 {
			str := fmt.Sprintf("transaction output has negative "+
				"value of %v", btcutil.Amount(originTxHao))
			return ruleError(ErrBadTxOutValue, str)
		}
		if utxo.TokenType == common.FeeCoinTyp && originTxHao > btcutil.MaxHao {
			str := fmt.Sprintf("transaction output value of %v is "+
				"higher than max allowed value of %v",
				btcutil.Amount(originTxHao),
				btcutil.MaxHao)
			return ruleError(ErrBadTxOutValue, str)
		}

		// The total of all outputs must not be more than the max
		// allowed per transaction.  Also, we could potentially overflow
		// the accumulator so check for overflow.
		lastHaoIn := totalIns[utxo.TokenType]
		totalIns[utxo.TokenType] += originTxHao
		if totalIns[utxo.TokenType] < lastHaoIn ||
			(utxo.TokenType == common.OmegaCoinTyp && totalIns[utxo.TokenType] > btcutil.MaxHao) ||
			(utxo.TokenType == common.FeeCoinTyp && totalIns[common.FeeCoinTyp] > btcutil.MaxHao) {
			str := fmt.Sprintf("total value of all transaction "+
				"inputs is %v which is higher than max "+
				"allowed value of %v", totalIns[utxo.TokenType],
				btcutil.MaxHao)
			return ruleError(ErrBadTxOutValue, str)
		}
	}

	return nil
}

func CheckAdditionalTransactionInputs(tx *btcutil.Tx, txHeight int32, views *viewpoint.ViewPointSet, chainParams *chaincfg.Params) error {
	// Coinbase transactions have no inputs.
	if tx.MsgTx().TxIn[0].PreviousOutPoint.Hash.IsEqual(&zerohash) {
		return nil
	}

	utxoView := views.Utxo

	if err := validate.CheckTransactionAdditionalInputs(tx, views); err != nil {
		// actually check definitions only
		return err
	}

	totalIns := make(map[uint64]int64)
	additional := false
	for txInIndex, txIn := range tx.MsgTx().TxIn {
		if txIn.IsSeparator() {
			additional = true
			continue
		}
		if txIn.PreviousOutPoint.Hash.IsEqual(&zerohash) {
			continue
		}
		if txIn.SignatureIndex == 0xFFFFFFFF && len(tx.MsgTx().TxOut) == 0 {
			continue
		}
		if !additional {
			continue
		}
		// Ensure the referenced input transaction is available.
		utxo := utxoView.LookupEntry(txIn.PreviousOutPoint)
		if utxo == nil || utxo.IsSpent() {
			str := fmt.Sprintf("output %v referenced from "+
				"transaction %s:%d either does not exist or "+
				"has already been spent", txIn.PreviousOutPoint,
				tx.Hash(), txInIndex)
			return ruleError(ErrMissingTxOut, str)
		}

		// Ensure the transaction amounts are in range.  Each of the
		// output values of the input transactions must not be negative
		// or more than the max allowed per transaction.  All amounts in
		// a transaction are in a unit value known as a hao.  One
		// bitcoin is a quantity of hao as defined by the
		// HaoPerBitcoin constant.
		if utxo.TokenType&1 != 0 {
			continue
		}

		originTxHao := utxo.Amount.(*token.NumToken).Val
		if originTxHao < 0 {
			str := fmt.Sprintf("transaction output has negative "+
				"value of %v", btcutil.Amount(originTxHao))
			return ruleError(ErrBadTxOutValue, str)
		}
		if originTxHao > btcutil.MaxHao {
			str := fmt.Sprintf("transaction output value of %v is "+
				"higher than max allowed value of %v",
				btcutil.Amount(originTxHao),
				btcutil.MaxHao)
			return ruleError(ErrBadTxOutValue, str)
		}

		// The total of all outputs must not be more than the max
		// allowed per transaction.  Also, we could potentially overflow
		// the accumulator so check for overflow.
		lastHaoIn := totalIns[utxo.TokenType]
		totalIns[utxo.TokenType] += originTxHao
		if totalIns[utxo.TokenType] < lastHaoIn ||
			(totalIns[utxo.TokenType] > btcutil.MaxHao) {
			str := fmt.Sprintf("total value of all transaction "+
				"inputs is %v which is higher than max "+
				"allowed value of %v", totalIns[utxo.TokenType],
				btcutil.MaxHao)
			return ruleError(ErrBadTxOutValue, str)
		}
	}

	return nil
}

func (b *BlockChain) UndefinedDefinitions(tx *btcutil.Tx, chainParams *chaincfg.Params) map[chainhash.Hash]uint8 {
	defs := make(map[chainhash.Hash]uint8, 0)

	defined := make(map[chainhash.Hash]struct{}, 0)

	views := b.NewViewPointSet()

	for _, rt := range tx.MsgTx().TxDef {
		if rt.IsSeparator() {
			continue
		}

		switch rt.(type) {
		case *token.RightSetDef:
			for _, r := range rt.(*token.RightSetDef).Rights {
				if _, ok := defined[r]; ok {
					continue
				}
				e2 := views.Rights.GetRight(views.Db, r).(*viewpoint.RightEntry)
				if e2 == nil {
					defs[r] = token.DefTypeRight
				} else {
					defined[r] = struct{}{}
				}
			}

		case *token.RightDef:
			if !rt.(*token.RightDef).Father.IsEqual(&chainhash.Hash{}) {
				if _, ok := defined[rt.(*token.RightDef).Father]; ok {
					continue
				}
				e3 := views.Rights.GetRight(views.Db, rt.(*token.RightDef).Father).(*viewpoint.RightEntry)
				if e3 == nil {
					defs[rt.(*token.RightDef).Father] = token.DefTypeRight
				} else {
					defined[rt.(*token.RightDef).Father] = struct{}{}
				}
			}

		case *token.PolygonDef:
			for _, loops := range rt.(*token.PolygonDef).Loops {
				for _, l := range loops {
					if _, ok := defined[l]; ok {
						continue
					}
					tmp := make(map[chainhash.Hash]struct{})
					tmp[l] = struct{}{}
					views.Border.FetchBorder(views.Db, tmp)
					e2 := views.Border.LookupEntry(l)
					if e2 == nil {
						defs[l] = token.DefTypeBorder
					} else {
						defined[l] = struct{}{}
					}
				}
			}

		case *token.BorderDef:
			f := rt.(*token.BorderDef).Father
			if !f.IsEqual(&chainhash.Hash{}) {
				if _, ok := defined[f]; ok {
					continue
				}
				tmp := make(map[chainhash.Hash]struct{})
				tmp[f] = struct{}{}
				views.Border.FetchBorder(views.Db, tmp)
				e3 := views.Border.LookupEntry(f)
				if e3 == nil {
					defs[f] = token.DefTypeRight
				} else {
					defined[f] = struct{}{}
				}
			}
		}
		defined[rt.Hash()] = struct{}{}
	}

	for _, to := range tx.MsgTx().TxOut {
		if to.TokenType != 3 {
			continue
		}

		p, _ := to.Token.Value.Value()
		if _, ok := defined[*p]; ok {
			continue
		}

		q, _ := views.FetchPolygonEntry(p)
		if q == nil {
			defs[*p] = token.DefTypePolygon
		} else {
			defined[*p] = struct{}{}
		}
	}
	return defs
}

func CheckAdditionalDefinitions(tx *btcutil.Tx, txHeight int32, views *viewpoint.ViewPointSet, chainParams *chaincfg.Params) error {
	// check definitions in TxOuts
	// recheck CheckDefinitions

	for _, rt := range tx.MsgTx().TxDef {
		if rt.IsSeparator() {
			continue
		}

		/*
			hash := rt.Hash()

			e := views.Rights.GetRight(views.Db, hash)
			// don't do this because rights are added during execution
			log.Infof("For def %s we got view %v", hash.String(), e)
			switch e.(type) {
			case *viewpoint.RightEntry:
				if e.(*viewpoint.RightEntry) != (*viewpoint.RightEntry)(nil) {
					str := fmt.Sprintf("Right duplicated in tx %s. Def Item %d, Hash %s.", tx.MsgTx().TxHash().String(), i, hash.String())
					return ruleError(1, str)
				}
			case *viewpoint.RightSetEntry:
				if e.(*viewpoint.RightSetEntry) != (*viewpoint.RightSetEntry)(nil) {
					str := fmt.Sprintf("Rightset duplicated in tx %s. Def Item %d, Hash %s.", tx.MsgTx().TxHash().String(), i, hash.String())
					return ruleError(1, str)
				}
			}
		*/

		switch rt.(type) {
		case *token.RightSetDef:
			dup := make(map[chainhash.Hash]struct{})
			for _, r := range rt.(*token.RightSetDef).Rights {
				if _, ok := dup[r]; ok {
					str := fmt.Sprintf("Duplicated right in rightset in tx %s.", tx.MsgTx().TxHash().String())
					return ruleError(1, str)
				}
				dup[r] = struct{}{}
				e2 := views.Rights.GetRight(views.Db, r).(*viewpoint.RightEntry)
				if e2 == nil {
					str := fmt.Sprintf("Right undefined in tx %s.", tx.MsgTx().TxHash().String())
					return ruleError(1, str)
				}
			}

			views.Rights.AddRightSet(rt.(*token.RightSetDef))

		case *token.RightDef:
			if !rt.(*token.RightDef).Father.IsEqual(&chainhash.Hash{}) {
				e3 := views.Rights.GetRight(views.Db, rt.(*token.RightDef).Father).(*viewpoint.RightEntry)
				if e3 == nil {
					str := fmt.Sprintf("Parent right missing in tx %s.", tx.MsgTx().TxHash().String())
					return ruleError(1, str)
				}
			}
			if !views.AddRight(rt.(*token.RightDef)) {
				str := fmt.Sprintf("Invalid right definition in tx %s.", tx.MsgTx().TxHash().String())
				return ruleError(1, str)
			}
		}
	}

	//	err, newrights, newrightsets := validate.ScanDefinitions(tx.MsgTx())
	//	if err != nil {
	//		return err
	//	}

	//	var righttrees = make(map[chainhash.Hash]chainhash.Hash)

	for i, to := range tx.MsgTx().TxOut {
		if to.IsSeparator() || !to.HasRight() {
			continue
		}

		//		var rights = make(map[chainhash.Hash]*token.RightDef)
		/*
			if _, ok := newrightsets[*to.Rights]; ok {
				for _, r := range newrightsets[*to.Rights].Rights {
					e := views.Rights.GetRight(views.Db, r).(*viewpoint.RightEntry)
					if e == nil {
						str := fmt.Sprintf("Right undefined in tx %s : %s.", tx.MsgTx().TxHash().String(), i)
						return ruleError(1, str)
					} else if rights[r] != nil {
						str := fmt.Sprintf("Right duplicated in tx %s : %s.", tx.MsgTx().TxHash().String(), i)
						return ruleError(1, str)
					} else {
						rights[r] = e.ToToken()
					}
				}
			} else if _, ok = newrights[*to.Rights]; ok {
				if rights[*to.Rights] != nil {
					str := fmt.Sprintf("Right duplicated in tx %s : %s.", tx.MsgTx().TxHash().String(), i)
					return ruleError(1, str)
				}
				rights[*to.Rights] = newrights[*to.Rights]
			} else {
		*/
		e := views.Rights.GetRight(views.Db, *to.Rights)
		switch e.(type) {
		case *viewpoint.RightSetEntry:
			if e == (*viewpoint.RightSetEntry)(nil) {
				str := fmt.Sprintf("Rightset undefined in tx %s : %s.", tx.MsgTx().TxHash().String(), i)
				return ruleError(1, str)
			}
			/*
				for _, r := range e.(*viewpoint.RightSetEntry).Rights {
					e := views.Rights.GetRight(views.Db, r).(*viewpoint.RightEntry)
					rights[r] = e.ToToken()
				}
			*/
		case *viewpoint.RightEntry:
			if e == (*viewpoint.RightEntry)(nil) {
				str := fmt.Sprintf("Right does not exists in tx %s : %s.", tx.MsgTx().TxHash().String(), i)
				return ruleError(1, str)
			}
		}
		//		}
		/*
			zh := chainhash.Hash{}
			for h,p := range rights {
				if _,ok := righttrees[h]; ok {
					continue
				}
				for p != nil {
					righttrees[h] = p.Father
					h = p.Father
					if _,ok := righttrees[h]; ok || h.IsEqual(&zh) {
						break
					}
					q := views.Rights.GetRight(views.Db, h).(*viewpoint.RightEntry)
					if q == nil {
						break
					}
					p = q.ToToken()
				}
			}
			for h,_ := range rights {
				p := righttrees[h]
				var ok bool
				for _, ok = rights[p]; !ok; _, ok = rights[p] {
					var k bool
					if p, k = righttrees[p]; !k {
						break
					}
				}
				if ok {
					str := fmt.Sprintf("Rights having ancestor/decendant relationship in %d : %d", tx.MsgTx().TxHash().String(), i)
					return ruleError(1, str)
				}
			}
		*/
	}

	return nil
}

func CheckTransactionIntegrity(tx *btcutil.Tx, views *viewpoint.ViewPointSet, version uint32) error {
	if tx.MsgTx().IsBtcL2() || tx.MsgTx().IsCrossChain() {
		return nil
	}
	if tx.MsgTx().TxIn[0].PreviousOutPoint.Hash.IsEqual(&zerohash) { // coinbase
		return nil
	}

	// Check numeric token w/ rights. If no new geometry is introduced, we can
	// make quick check geometry too by treating them as numeric token.

	// we check numeric tokens in tx fee check, here we check hash only tokens
	// and load view at the same time
	inputs := make([]token.Token, 0)
	for _, txIn := range tx.MsgTx().TxIn {
		if txIn.PreviousOutPoint.Hash.IsEqual(&zerohash) {
			continue
		}
		out := txIn.PreviousOutPoint
		x := views.Utxo.LookupEntry(out)
		if x == nil {
			r := make(map[wire.OutPoint]struct{})
			r[out] = struct{}{}

			fmt.Printf("Pre-fetch input %v\n", out)
			views.Utxo.FetchUtxosMain(views.Db, r)
			x = views.Utxo.LookupEntry(out)
		}
		if x == nil {
			str := fmt.Sprintf("A Tx input does not exist: %s", txIn.PreviousOutPoint.String())
			return ruleError(ErrSpendTooHigh, str)
		}

		t := x.ToTxOut().Token.TokenType

		/*		if version >= wire.Version5 {
				if t & 1 != 1 {
					continue
				}
			} else*/if t&3 != 1 {
			continue
		}
		inputs = append(inputs, x.ToTxOut().Token)
	}
	rem := len(inputs)
	for _, txOut := range tx.MsgTx().TxOut {
		t := txOut.TokenType
		if txOut.IsSeparator() {
			continue
		}
		/*		if version >= wire.Version5 {
				if t & 1 != 1 {
					continue
				}
			} else*/if t&3 != 1 {
			continue
		}
		match := false
		for j, tk := range inputs {
			if txOut.TokenType == tk.TokenType &&
				txOut.Token.Value.(*token.HashToken).Hash.IsEqual(&tk.Value.(*token.HashToken).Hash) {
				rem--
				match = true
				inputs[j].TokenType = common.FeeCoinTyp // no further matching
				break
			}
		}
		if !match {
			str := fmt.Sprintf("The Tx %s is not integral", tx.Hash().String())
			return ruleError(ErrSpendTooHigh, str)
		}
	}
	if rem != 0 {
		str := fmt.Sprintf("The Tx %s is not integral", tx.Hash().String())
		return ruleError(ErrSpendTooHigh, str)
	}
	//	ntx := tx.Copy() // Deep copy
	//	ntx.Spends = append(inputs, ntx.Spends...)

	res, err := validate.QuickCheckRight(tx, views, version)
	if res {
		return nil
	}
	if err != nil {
		return err
	}

	// check geometry integrity
	if !validate.CheckGeometryIntegrity(tx, views) {
		str := fmt.Sprintf("The Tx is not geometrically integral")
		return ruleError(ErrSpendTooHigh, str)
	}
	return nil
}

func CheckTransactionFees(tx *btcutil.Tx, storage int64, views *viewpoint.ViewPointSet, chainParams *chaincfg.Params) (int64, int64, error) {
	if tx.MsgTx().IsBtcL2() || tx.MsgTx().IsCrossChain() {
		return 0, 0, nil
	}

	// Coinbase transactions have no inputs.
	// allow two kinds tx fees: omega (common.OmegaCoinTyp) and bitcoin (0)
	utxoView := views.Utxo

	txHash := tx.Hash()
	totalIns := make(map[uint64]int64)
	minbtcreq := int64(0)

	if tx.MsgTx().IsCrossChain() {
		return 0, 0, nil
	}
	for _, txIn := range tx.MsgTx().TxIn {
		if txIn.PreviousOutPoint.Hash.IsEqual(&zerohash) {
			continue
		}
		// Ensure the referenced input transaction is available.
		var utxo *wire.TxOut
		utxoe := utxoView.LookupEntry(txIn.PreviousOutPoint)
		if utxoe == nil {
			continue
		}
		utxo = utxoe.ToTxOut()
		// Ensure the transaction amounts are in range.  Each of the
		// output values of the input transactions must not be negative
		// or more than the max allowed per transaction.  All amounts in
		// a transaction are in a unit value known as a hao.  One
		// bitcoin is a quantity of hao as defined by the
		// HaoPerBitcoin constant.
		if utxo.TokenType&3 != 0 {
			continue
		}

		originTxHao := utxo.Token.Value.(*token.NumToken).Val

		rtype := utxo.TokenType
		if uint32(rtype>>40) == chainParams.ChainID {
			rtype = rtype & 0xFFFFFFFFFF
		}

		// The total of all outputs must not be more than the max
		// allowed per transaction.  Also, we could potentially overflow
		// the accumulator so check for overflow.
		//		lastHaoIn := totalIns[utxo.TokenType]
		totalIns[rtype] += originTxHao
		/*		already checked elsewhere
				if totalIns[utxo.TokenType] < lastHaoIn ||
					totalIns[utxo.TokenType] > btcutil.MaxHao {
					str := fmt.Sprintf("total value of all transaction "+
						"inputs is %v which is higher than max "+
						"allowed value of %v", totalIns[utxo.TokenType],
						btcutil.MaxHao)
					return 0, ruleError(ErrBadTxOutValue, str)
				}
		*/
	}

	// Calculate the total output amount for this transaction.  It is safe
	// to ignore overflow and out of range errors here because those error
	// conditions would have already been caught by checkTransactionSanity.
	totalHaoOut := make(map[uint64]int64)

	for _, txOut := range tx.MsgTx().TxOut {
		if txOut.IsSeparator() || txOut.TokenType&3 != 0 {
			continue
		}

		if txOut.Value == nil {
			continue
		}
		if bytes.Compare(txOut.PkScript[22:25], []byte{0x2, 0x0, 0x40}) == 0 { // BTC chainid = 0x400002
			// min 0.0001 BTC required
			minbtcreq += 10000
		}

		rtype := txOut.TokenType
		origin := uint32(txOut.TokenType >> 40)
		dtype := rtype
		if (origin & 0x3FFFFF) == chainParams.ChainID {
			dtype = dtype & 0xFFFFFFFFFF
		}
		if txOut.IsCrossChain() {
			if origin != 0 {
				if (dtype>>40) != 0 && uint32(rtype>>40) != (common.LittleEndian.Uint32(txOut.PkScript[21:])>>8) {
					str := fmt.Sprintf("A cross chain tx of foreign type token %d must go back to its origin %d", rtype>>40,
						common.LittleEndian.Uint32(txOut.PkScript[21:])>>8)
					return 0, 0, ruleError(ErrBadTxOutValue, str)
				}
			} else {
				str := fmt.Sprintf("Tokentype in a cross chain tx must include chainid")
				return 0, 0, ruleError(ErrBadTxOutValue, str)
			}
		}

		if _, ok := totalHaoOut[rtype]; ok {
			totalHaoOut[rtype] += txOut.Value.(*token.NumToken).Val
		} else {
			totalHaoOut[rtype] = txOut.Value.(*token.NumToken).Val
		}
	}

	// Ensure the transaction does not spend more than its inputs.
	for in, out := range totalHaoOut {
		v := int64(0)
		if k, ok := totalIns[in]; ok {
			v = k
		}
		if v < out {
			str := fmt.Sprintf("total type %d value of all transaction inputs for "+
				"transaction %v is %v which is less than the amount "+
				"spent of %v", in, txHash, v, out)
			return 0, 0, ruleError(ErrSpendTooHigh, str)
		} else if in != common.OmegaCoinTyp && in != common.BTCCHAINID<<40 && in != 0 && v != out {
			str := fmt.Sprintf("total %d type token value of all transaction inputs for "+
				"transaction %v is %v which is not equal to the amount "+
				"spent of %v", in, txHash, v, out)
			return 0, 0, ruleError(ErrSpendTooHigh, str)
		}
	}

	for in, out := range totalIns {
		if in == common.OmegaCoinTyp || in == common.BTCCHAINID<<40 || in == 0 {
			continue
		}
		v := int64(0)
		if k, ok := totalHaoOut[in]; ok {
			v = k
		}
		if v != out {
			str := fmt.Sprintf("total %d type token value of all transaction inputs for "+
				"transaction %v is %v which is not equal to the amount "+
				"spent of %v", in, txHash, out, v)
			return 0, 0, ruleError(ErrSpendTooHigh, str)
		}
	}

	// NOTE: bitcoind checks if the transaction fees are < 0 here, but that
	// is an impossible condition because of the check above that ensures
	// the inputs are >= the outputs.
	txFeeInHao := int64(0)
	txbtcFeeInHao := int64(0)
	if _, ok := totalIns[common.OmegaCoinTyp]; ok {
		txFeeInHao = totalIns[common.OmegaCoinTyp] - totalHaoOut[common.OmegaCoinTyp]
	}
	if _, ok := totalIns[0]; ok {
		txbtcFeeInHao = totalIns[0] - totalHaoOut[0]
	}
	if _, ok := totalIns[common.BTCCHAINID<<40]; ok {
		txbtcFeeInHao += totalIns[common.BTCCHAINID<<40] - totalHaoOut[common.BTCCHAINID<<40]
	}

	n := 0
	for _, d := range tx.MsgTx().TxDef {
		if d.DefType() == token.DefTypeBorder && d.(*token.BorderDef).Father.IsEqual(&zeroHash) {
			n++
		}
	}

	if txbtcFeeInHao < minbtcreq {
		return 0, 0, fmt.Errorf("BTC Transaction fee is less than the mandatory minimal fee.")
	}

	// must pay more than border fee + tx storage fee + contract storage fee
	if txFeeInHao < int64(n*chainParams.MinBorderFee)+chainParams.MinRelayTxFee*(storage+int64(tx.MsgTx().SerializeSizeFull()))/1000 {
		return 0, 0, fmt.Errorf("Transaction fee is less than the mandatory storage fee.")
	}

	return txFeeInHao, txbtcFeeInHao, nil
}

func ContractNewStorage(tx *btcutil.Tx, vm *ovm.OVM, paidstoragefees map[[20]byte]int64) int64 {
	storagefees := make(map[[20]byte]int64)

	for _, txOut := range tx.MsgTx().TxOut {
		if txOut.IsSeparator() || !chaincfg.IsContractAddrID(txOut.PkScript[0]) {
			continue
		}

		var addr [20]byte
		copy(addr[:], txOut.PkScript[1:21])
		if _, ok := storagefees[addr]; !ok {
			storagefees[addr] = int64(vm.NewUage(addr))
		}
	}
	storage := int64(0) // storage fees need to be paid by this tx
	for addr, t := range storagefees {
		if t <= 0 {
			continue
		}
		if s, ok := paidstoragefees[addr]; ok {
			if t <= s {
				continue
			}
			storage += t - s
		} else {
			storage += t
		}
		paidstoragefees[addr] = t
	}
	return storage
}

func (b *BlockChain) normalizeTxo(txo *wire.TxOut) {
	copy(txo.PkScript[21:], txo.PkScript[25:])
	txo.PkScript = txo.PkScript[:len(txo.PkScript)-4]
	if (txo.TokenType >> 40) == uint64(b.ChainParams.ChainID) {
		txo.TokenType &= 0xFFFFFFFFFF
	}
}

func (b *BlockChain) checkCrossChain(block *btcutil.Block) error {
	chain := chainmap.ChainMap[b.ChainParams.ChainID&0x3FFFFF]
	for _, tx := range block.MsgBlock().Transactions[1:] {
		for _, txo := range tx.TxOut {
			if txo.IsSeparator() || !txo.IsCrossChain() {
				continue
			}
			dc := txo.DestChain()
			if chainmap.ChainMap[dc&0x3FFFFF] == nil {
				b.SrvReq <- ReqChain(dc)
				return fmt.Errorf("Dest chain unknown %d", dc)
			}
			if dc == b.ChainParams.MainChainID {
				return fmt.Errorf("Can not cross chain to self")
			}
			if (txo.TokenType>>40) != 0 && uint32(txo.TokenType>>40) != dc && !chain.PassThru(uint32(txo.TokenType>>40)&0x3FFFFF, dc) {
				return fmt.Errorf("Cross chain tx not in propgation path")
			}
		}
	}

	return b.db.View(func(dbTx database.Tx) error {
		bucket := dbTx.Metadata().Bucket([]byte(common.INCOMINGPOOL))
		for _, tx := range block.MsgBlock().Transactions[1:] {
			if !tx.IsCrossChain() {
				continue
			}
			d := bucket.Get(tx.TxIn[0].PreviousOutPoint.ToBytes())
			if d == nil || len(d) == 0 {
				return fmt.Errorf("Cross chain source does not exist")
			}
			xtx := &wire.XchainData{}
			err := xtx.DeSerialize(d)
			if err != nil {
				return err
			}
			if xtx.Txs[0].Txo.PkScript[21] != 0x66 {
				fmt.Printf("bad XchainData")
			}
			if xtx.Finalized == 0 {
				return fmt.Errorf("Cross chain source is not finalized")
			}

			mtx := wire.NewMsgTx(wire.TxVersion | wire.TxNoDefine)
			mtx.LockTime = uint32(block.Height()) + 1
			txin := wire.NewTxIn(&wire.OutPoint{Hash: xtx.Hash, Index: wire.CrossChainFalg | xtx.ChainID}, uint32(xtx.Height))
			mtx.AddTxIn(txin)
			for _, txo := range xtx.Txs {
				if txo.Txo.PkScript[21] == ovm.OP_PAYCROSSCHAIN {
					if (common.LittleEndian.Uint32(txo.Txo.PkScript[21:]) >> 8) == b.ChainParams.ChainID {
						b.normalizeTxo(&txo.Txo)
					}
				}

				mtx.AddTxOut(&txo.Txo)
			}
			if !mtx.Match(tx) {
				return fmt.Errorf("tx does not match cross chain source %x v. %x", mtx.TxOut[0].PkScript, tx.TxOut[0].PkScript)
			}
		}

		if b.IsSVP {
			return nil
		}

		xcbucket := dbTx.Metadata().Bucket([]byte(common.XCAssets))
		assets := make(map[[76]byte]int64)
		for _, tx := range block.MsgBlock().Transactions[1:] {
			svp := uint32(0)
			if tx.IsCrossChain() {
				svp = tx.TxIn[0].PreviousOutPoint.Index &^ wire.CrossChainFalg
			}

			for _, txo := range tx.TxOut {
				if txo.IsSeparator() || (svp == 0 && !txo.IsCrossChain()) {
					continue
				}
				dest := txo.DestChain()
				if dest == 0 {
					dest = b.ChainParams.MainChainID
				}

				assetKey, dest, srckey, tokensrc := b.makeAssetKey(txo)

				out := dest != tokensrc

				d := int64(0)
				switch txo.TokenType & 3 {
				case 0, 2:
					d = txo.Value.(*token.NumToken).Val
					if d <= 0 {
						return fmt.Errorf("invalid cross chain asset value")
					}
				case 1, 3:
					d = 1
					if txo.Value.(*token.HashToken).Hash.IsEqual(&zerohash) {
						return fmt.Errorf("invalid cross chain asset value")
					}
				}

				var vk [76]byte
				copy(vk[:], assetKey)

				val := xcbucket.Get(assetKey)
				if val != nil {
					assets[vk] = int64(common.LittleEndian.Uint64(val))
				} else {
					assets[vk] = 0
				}

				if out {
					assets[vk] += d
				} else if assets[vk] >= d {
					assets[vk] -= d
				} else {
					return fmt.Errorf("back value excees out value")
				}

				copy(vk[:], srckey)

				val = xcbucket.Get(srckey)
				if val != nil {
					assets[vk] = int64(common.LittleEndian.Uint64(val))
				} else {
					assets[vk] = 0
				}

				if out {
					assets[vk] += d
				} else if assets[vk] >= d {
					assets[vk] -= d
				} else {
					return fmt.Errorf("back value excees out value")
				}
			}
		}
		return nil
	})
}

// checkConnectBlock performs several checks to confirm connecting the passed
// block to the chain represented by the passed view does not violate any rules.
// In addition, the passed view is updated to spend all of the referenced
// outputs and add all of the new utxos created by block.  Thus, the view will
// represent the state of the chain as if the block were actually connected and
// consequently the best hash for the view is also updated to passed block.
//
// An example of some of the checks performed are ensuring connecting the block
// would not cause any duplicate transaction hashes for old transactions that
// aren't already fully spent, double spends, exceeding the maximum allowed
// signature operations per block, invalid values in relation to the expected
// block subsidy, or fail transaction script validation.
//
// The CheckConnectBlockTemplate function makes use of this function to perform
// the bulk of its work.  The only difference is this function accepts a node
// which may or may not require reorganization to connect it to the main chain
// whereas CheckConnectBlockTemplate creates a new node which specifically
// connects to the end of the current main chain and then calls this function
// with that node.
//
// This function MUST be called with the chain state lock held (for writes).
func (b *BlockChain) checkConnectBlock(node *chainutil.BlockNode, block *btcutil.Block, views *viewpoint.ViewPointSet, stxos *[]viewpoint.SpentTxOut, Vm *ovm.OVM) error {
	// If the side chain blocks end up in the database, a call to
	// CheckBlockSanity should be done here in case a previous version
	// allowed a block that is no longer valid.  However, since the
	// implementation only currently uses memory for the side chain blocks,
	// it isn't currently necessary.

	// Ensure the view is for the node being checked.
	parentHash := &block.MsgBlock().Header.PrevBlock
	if !views.Utxo.BestHash().IsEqual(parentHash) {
		return AssertError(fmt.Sprintf("inconsistent view when "+
			"checking block connection: best hash is %v instead "+
			"of expected %v", views.Utxo.BestHash(), parentHash))
	}

	// Load all of the utxos referenced by the inputs for all transactions
	// in the block don't already exist in the utxo view from the database.
	//
	// These utxo entries are needed for verification of things such as
	// transaction inputs, counting pay-to-script-hashes, and scripts.
	err := views.FetchInputUtxos(block)
	if err != nil {
		return err
	}

	// The number of signature operations must be less than the maximum
	// allowed per block.  Note that the preliminary sanity checks on a
	// block also include a check similar to this one, but this check
	// expands the count to include a precise count of pay-to-script-hash
	// signature operations in each of the input transaction public key
	// scripts.
	transactions := block.Transactions()
	totalSigOpCost := 0
	for i, tx := range transactions {
		// Since the first (and only the first) transaction has
		// already been verified to be a coinbase transaction,
		// use i == 0 as an optimization for the flag to
		// countP2SHSigOps for whether or not the transaction is
		// a coinbase transaction rather than having to do a
		// full coinbase check again.
		sigOpCost, err := GetSigOpCost(tx, i == 0, views.Utxo, true, true)
		if err != nil {
			return err
		}

		// Check for overflow or going over the limits.  We have to do
		// this on every loop iteration to avoid overflow.
		lastSigOpCost := totalSigOpCost
		totalSigOpCost += sigOpCost
		if totalSigOpCost < lastSigOpCost || totalSigOpCost > chaincfg.MaxBlockSigOpsCost {
			str := fmt.Sprintf("block contains too many "+
				"signature operations - got %v, max %v",
				totalSigOpCost, chaincfg.MaxBlockSigOpsCost)
			return ruleError(ErrTooManySigOps, str)
		}
	}

	// Don't run scripts if this node is before the latest known good
	// checkpoint since the validity is verified via the checkpoints (all
	// transactions are included in the merkle root hash and any changes
	// will therefore be detected by the next checkpoint).  This is a huge
	// optimization because running the scripts is the most time consuming
	// portion of block handling.
	checkpoint := b.LatestCheckpoint()
	runScripts := true
	if checkpoint != nil && node.Height <= checkpoint.Height {
		runScripts = false
	}

	// Perform several checks on the inputs for each transaction.  Also
	// accumulate the total fees.  This could technically be combined with
	// the loop above instead of running another loop over the transactions,
	// but by separating it we can avoid running the more expensive (though
	// still relatively cheap as compared to running the scripts) checks
	// against all the inputs when the signature operations are out of
	// bounds.

	coinBase := btcutil.NewTx(transactions[0].MsgTx().Stripped())
	coinBase.SetIndex(transactions[0].Index())

	if Vm != nil {
		Vm.SetViewPoint(views)

		coinBaseHash := *transactions[0].Hash()

		Vm.SetCoinBaseOp(
			func(txo wire.TxOut) wire.OutPoint {
				if !coinBase.HasOuts {
					// this servers as a separater. only TokenType is serialized
					to := wire.TxOut{}
					to.Token = token.Token{TokenType: token.DefTypeSeparator}
					coinBase.MsgTx().AddTxOut(&to)
					coinBase.HasOuts = true
				}
				coinBase.MsgTx().AddTxOut(&txo)
				op := wire.OutPoint{coinBaseHash, uint32(len(coinBase.MsgTx().TxOut) - 1)}
				views.Utxo.AddRawTxOut(op, &txo, false, block.Height())
				return op
			})

		Vm.StepLimit = block.MsgBlock().Header.ContractExec
		Vm.BlockNumber = func() uint64 {
			return uint64(block.Height())
		}
		Vm.BlockTime = func() uint32 {
			return uint32(block.MsgBlock().Header.Timestamp.Unix())
		}
		Vm.BlockVersion = func() uint32 { return block.MsgBlock().Header.Version }
		//	Vm.Block = func() *btcutil.Block { return block }
		Vm.GetCoinBase = func() *btcutil.Tx { return coinBase }
		Vm.BlockTime = func() uint32 {
			return uint32(block.MsgBlock().Header.Timestamp.Unix())
		}
		Vm.BlockVersion = func() uint32 { return block.MsgBlock().Header.Version }
		//	} else {
		//		oldcoinBase = transactions[0]
	}

	paidstoragefees := make(map[[20]byte]int64)
	storages := make([]int64, len(transactions)-1)

	var unmached string

	for i, tx := range transactions[1:] {
		if runScripts && !tx.MsgTx().IsBtcL2() && !tx.MsgTx().IsCrossChain() {
			err = ovm.VerifySigs(tx, b.ChainParams, 0, views)
			if err != nil {
				return err
			}
		}

		if Vm != nil {
			newtx := btcutil.NewTx(tx.MsgTx().Stripped())
			newtx.SetIndex(tx.Index())
			newtx.HasIns, newtx.HasDefs, newtx.HasOuts = false, false, false

			_, err = Vm.ExecContract(newtx, node.Height)
			if err != nil {
				return err
			}

			if !newtx.Match(tx) {
				old, _ := json.Marshal(tx.MsgTx())
				newt, _ := json.Marshal(newtx.MsgTx())
				blk, _ := json.Marshal(block.MsgBlock())

				unmached = unmached + fmt.Sprintf("Mismatch contract execution result. old %s \n vs. new %s \n block %s\n", string(old), string(newt), string(blk))

				if !tx.Match(btcutil.NewTx(tx.MsgTx().Stripped())) {
					// we will update block in DB only if mismatch is between raw tx and executed tx
					// here we find that tx is executed (therefore it does not match its raw version)
					return fmt.Errorf("%s", unmached)
				}
				transactions[i+1] = newtx
			}

			storages[i] = ContractNewStorage(newtx, Vm, paidstoragefees)
		}
	}

	if Vm != nil {
		if !transactions[0].Match(coinBase) {
			transactions[0] = coinBase
			unmached = unmached + "Mismatch contract execution result in coinbase."
		}

		if len(unmached) > 0 {
			var dbblk *btcutil.Block
			b.db.View(func(dbTx database.Tx) error {
				var err error
				blockBytes, err := dbTx.FetchBlock(block.Hash())
				if err != nil {
					return err
				}

				t, err := btcutil.NewBlockFromBytes(blockBytes)
				if err != nil {
					return err
				}

				dbblk = t

				return nil
			})

			if dbblk != nil {
				um := false
				for i, tx := range dbblk.Transactions() {
					um = um || !tx.Match(transactions[i])
				}
				if um {
					b.db.Update(func(dbTx database.Tx) error {
						return dbTx.UpdateBlock(block)
					})
				}
			}
			return fmt.Errorf("%s", unmached)
		}
		if Vm.StepLimit != 0 {
			return fmt.Errorf("Incorrect contract execution cost.")
		}
	}

	totalFees := int64(0)
	totalbtcFees := int64(0)

	block.Btctxfees = 0

	//	views.Rights = viewpoint.NewRightViewpoint()
	//	views.Polygon = viewpoint.NewPolygonViewpoint()
	//	views.Border = viewpoint.NewBorderViewpoint()

	err = b.checkCrossChain(block)
	if err != nil {
		return err
	}

	err = CheckTransactionInputs(transactions[0], node.Height, views, b.ChainParams)
	if err != nil {
		return err
	}

	if !b.IsSVP {
		err = CheckAdditionalDefinitions(transactions[0], node.Height, views, b.ChainParams)
		if err != nil {
			return err
		}
		err = views.ConnectTransaction(transactions[0], node.Height, stxos)
		if err != nil {
			return err
		}
	}

	fromBTC := make(map[chainhash.Hash]*common.BTCL2Data)
	heights := make(map[chainhash.Hash]uint32)
	top := uint32(0)

	ck := b.LatestCheckpoint()
	flag := BFNone
	if ck != nil && node.Height <= ck.Height {
		flag |= BFFastAdd
	}

	for i, tx := range transactions[1:] {
		err := CheckTransactionInputs(tx, node.Height, views, b.ChainParams)
		if err != nil {
			return err
		}

		err = CheckAdditionalTransactionInputs(tx, node.Height, views, b.ChainParams)
		if err != nil {
			return err
		}

		if !b.IsSVP {
			err = CheckAdditionalDefinitions(tx, node.Height, views, b.ChainParams)
			if err != nil {
				return err
			}
		}
		txFee, txbtcfee := int64(0), int64(0)

		if flag&BFFastAdd == 0 {
			err = CheckTransactionIntegrity(tx, views, block.MsgBlock().Header.Version)
			if err != nil {
				return err
			}

			txFee, txbtcfee, err = CheckTransactionFees(tx, storages[i], views, b.ChainParams)
			if err != nil {
				return err
			}

			// check locked collateral
			for _, txin := range tx.MsgTx().TxIn {
				if txin.PreviousOutPoint.Hash.IsEqual(&zerohash) {
					continue
				}
				if txin.PreviousOutPoint.Index&wire.OP_PAYCROSSCHAIN != 0 {
					continue
				}
				if b.LockedCollaterals.Exists(&txin.PreviousOutPoint) {
					return fmt.Errorf("Try to spend locked collateral")
				}
			}
		}

		// Sum the total fees and ensure we don't overflow the
		// accumulator.
		lastTotalFees := totalFees
		totalFees += txFee

		lastbtcTotalFees := totalbtcFees
		totalbtcFees += txbtcfee
		if totalFees < lastTotalFees {
			return ruleError(ErrBadFees, "total fees for block "+
				"overflows accumulator")
		}
		if totalbtcFees < lastbtcTotalFees {
			return ruleError(ErrBadFees, "total fees for block "+
				"overflows accumulator")
		}

		// Add all of the outputs for this transaction which are not
		// provably unspendable as available utxos.  Also, the passed
		// spent txos slice is updated to contain an entry for each
		// spent txout in the order each transaction spends them.
		if !b.IsSVP {
			err = views.ConnectTransaction(tx, node.Height, stxos)
			if err != nil {
				return err
			}
		}
	}

	block.Btctxfees = totalbtcFees

	for hash, _ := range fromBTC {
		if heights[hash] < top {
			return fmt.Errorf("Mismatch in BTC transfer")
		}
	}

	err = b.CheckForfeit(block, node.Parent, views)
	if err != nil {
		return err
	}

	// Build merkle tree and ensure the calculated merkle root matches the
	// entry in the block header. This also has the effect of caching all
	// of the transaction hashes in the block to speed up future hash
	// checks. We do this check here after contract execution has been validated.
	merkles := BuildMerkleTreeStore(block.Transactions(), false, block.MsgBlock().Header.Version&^0xFFFF)
	calculatedMerkleRoot := merkles[len(merkles)-1]
	header := block.MsgBlock().Header
	if !header.MerkleRoot.IsEqual(calculatedMerkleRoot) {
		str := fmt.Sprintf("block merkle root is invalid - block "+
			"header indicates %v, but calculated value is %v",
			header.MerkleRoot, calculatedMerkleRoot)
		return ruleError(ErrBadMerkleRoot, str)
	}

	// The total output values of the coinbase transaction must not exceed
	// the expected subsidy value plus total transaction fees gained from
	// mining the block.  It is safe to ignore overflow and out of range
	// errors here because those error conditions would have already been
	// caught by checkTransactionSanity.
	totalHaoOut := int64(0)

	for _, txOut := range transactions[0].MsgTx().TxOut {
		if txOut.IsSeparator() {
			break
		}
		if txOut.TokenType == common.FeeCoinTyp {
			totalHaoOut += txOut.Value.(*token.NumToken).Val
		}
		/*
			if txOut.TokenType == 0 {
				str := fmt.Sprintf("may not claim btc txfee in coinbase transaction. block %s\n", block.Hash().String())
				return ruleError(ErrBadCoinbaseValue, str)
			}
		*/
	}

	/*
		prevPows := uint(0)
		if node.Data.GetNonce() > 0 {
			for pw := node.Parent; pw != nil && pw.Data.GetNonce() > 0; pw = b.ParentNode(pw) {
				prevPows++
			}
		}
		adj := int64(0)

		if prevPows != 0 {
			best := b.BestSnapshot()
			adj = CalcBlockSubsidy(best.Height, b.ChainParams, 0) -
				CalcBlockSubsidy(best.Height, b.ChainParams, prevPows)
		}
	*/
	/*
		award := CalcBlockSubsidy(node.Height, b.ChainParams, prevPows)
		if award < b.ChainParams.MinimalAward {
			award = b.ChainParams.MinimalAward
		}
	*/

	award := int64(0)

	expectedHaoOut := award + totalFees //  + adj
	if totalHaoOut > expectedHaoOut {
		var w bytes.Buffer
		block.Transactions()[0].MsgTx().Serialize(&w)
		s := hex.EncodeToString(w.Bytes())
		str := fmt.Sprintf("coinbase transaction for block %s pays %v "+
			"which is more than expected value of %v\nblock has %d txs\n%s", block.Hash().String(),
			totalHaoOut, expectedHaoOut, len(block.MsgBlock().Transactions), s)
		return ruleError(ErrBadCoinbaseValue, str)
	}

	// We obtain the MTP of the *previous* block in order to
	// determine if transactions in the current block are final.
	medianTime := node.Parent.CalcPastMedianTime()

	// we also enforce the relative sequence number based
	// lock-times within the inputs of all transactions in this
	// candidate block.
	for _, tx := range block.Transactions() {
		if tx.MsgTx().IsCrossChain() {
			continue
		}
		// A transaction can only be included within a block
		// once the sequence locks of *all* its inputs are
		// active.
		sequenceLock, err := b.calcSequenceLock(node, tx, views.Utxo,
			false)
		if err != nil {
			return err
		}
		if !SequenceLockActive(sequenceLock, node.Height,
			medianTime) {
			str := fmt.Sprintf("block contains " +
				"transaction whose input sequence " +
				"locks are not met")
			return ruleError(ErrUnfinalizedTx, str)
		}
	}

	/*	// we don't forbid violating miner from makeing tx. we only forfeit bond and not
		// allow him mining (generating MR block)
		// blacklist check
		var name [20]byte
		for _, tx := range block.MsgBlock().Transactions {
			for _, txo := range tx.TxOut {
				if txo.IsSeparator() {
					break
				}
				copy(name[:], txo.PkScript[1:21])
				if txo.PkScript[0] == b.ChainParams.PubKeyHashAddrID && b.Blacklist.IsBlack(name) {
					return fmt.Errorf("Blacklised txo")
				}
			}

			if tx.IsCoinBase() || tx.IsForfeit() {
				continue
			}
			for _, txi := range tx.TxIn {
				if txi.IsSeparator() {
					break
				}
				utxo := views.Utxo.LookupEntry(txi.PreviousOutPoint)
				if utxo == nil || utxo.IsSpent() {
					continue
				}

				// check blacklist
				copy(name[:], utxo.PkScript()[1:21])
				if b.Blacklist.IsBlack(name) {
					return fmt.Errorf("Blacklised input")
				}
			}
		}
	*/

	// Update the best hash for view to include this block since all of its
	// transactions have been connected.
	views.Utxo.SetBestHash(&node.Hash)

	return nil
}

func (b *BlockChain) checkConnectSVPBlock(node *chainutil.BlockNode, block *btcutil.Block, views *viewpoint.ViewPointSet) error {
	// If the side chain blocks end up in the database, a call to
	// CheckBlockSanity should be done here in case a previous version
	// allowed a block that is no longer valid.  However, since the
	// implementation only currently uses memory for the side chain blocks,
	// it isn't currently necessary.

	// Ensure the view is for the node being checked.
	parentHash := &block.MsgBlock().Header.PrevBlock
	if !views.Utxo.BestHash().IsEqual(parentHash) {
		return AssertError(fmt.Sprintf("inconsistent view when "+
			"checking block connection: best hash is %v instead "+
			"of expected %v", views.Utxo.BestHash(), parentHash))
	}

	// Build merkle tree and ensure the calculated merkle root matches the
	// entry in the block header. This also has the effect of caching all
	// of the transaction hashes in the block to speed up future hash
	// checks. We do this check here after contract execution has been validated.
	merkles := BuildMerkleTreeStore(block.Transactions(), false, block.MsgBlock().Header.Version&^0xFFFF)
	calculatedMerkleRoot := merkles[len(merkles)-1]
	header := block.MsgBlock().Header
	if !header.MerkleRoot.IsEqual(calculatedMerkleRoot) {
		str := fmt.Sprintf("block merkle root is invalid - block "+
			"header indicates %v, but calculated value is %v",
			header.MerkleRoot, calculatedMerkleRoot)
		return ruleError(ErrBadMerkleRoot, str)
	}

	// Update the best hash for view to include this block since all of its
	// transactions have been connected.
	views.Utxo.SetBestHash(&node.Hash)

	return nil
}

// CheckConnectBlockTemplate fully validates that connecting the passed block to
// the main chain does not violate any consensus rules, aside from the proof of
// work requirement. The block must connect to the current tip of the main chain.
//
// This function is safe for concurrent access.
func (b *BlockChain) CheckConnectBlockTemplate(block *btcutil.Block) error {
	//	log.Infof("CheckConnectBlockTemplate: ChainLock.RLock")
	b.ChainLock.Lock()
	defer b.ChainLock.Unlock()

	// Skip the proof of work check as this is just a block template.
	flags := BFNoPoWCheck

	// This only checks whether the block can be connected to the tip of the
	// current chain.
	tip := b.BestChain.Tip()
	header := block.MsgBlock().Header
	if tip.Hash != header.PrevBlock {
		str := fmt.Sprintf("previous block must be the current chain tip %v, "+
			"instead got %v", tip.Hash, header.PrevBlock)
		return ruleError(ErrPrevBlockNotBest, str)
	}

	err := b.checkBlockSanity(block, b.ChainParams.PowLimit, b.timeSource, flags)
	if err != nil {
		return err
	}

	err = b.checkBlockContext(block, tip, flags)
	if err != nil {
		return err
	}

	// Leave the spent txouts entry nil in the state since the information
	// is not needed and thus extra work can be avoided.
	views, Vm := b.Canvas(block)

	views.SetBestHash(&tip.Hash)

	newNode := NewBlockNode(&header, tip)

	return b.checkConnectBlock(newNode, block, views, nil, Vm)
}
