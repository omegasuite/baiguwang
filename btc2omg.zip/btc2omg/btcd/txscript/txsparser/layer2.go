// Copyright (c) 2015-2016 The omegasuite developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

package txsparser

import (
	"github.com/btcsuite/btcd/btc2omg/btcd/database"
	"github.com/btcsuite/btcd/btcutil"
	"github.com/btcsuite/btcd/chaincfg"
	"github.com/btcsuite/btcd/chaincfg/chainhash"
)

var BTCParams *chaincfg.Params

func FindTokentype(script []byte) int64 {
	return 0
}

func FindValue(v int64, script []byte) int64 {
	if v != 0 {
		return v
	}
	return 0
}

func FindRight(script []byte) *chainhash.Hash {
	return nil
}

func tosigners(addresses []btcutil.Address, dbtx database.Tx) bool {
	bucket := dbtx.Metadata().Bucket([]byte("Signers"))
	for _, addr := range addresses {
		m := bucket.Get(addr.ScriptAddress())
		if m == nil {
			return false
		}
	}

	return true
}

/*
func isMatching(script []byte) int32 {
	// check if it is a transaction that transfers asset to Layer 2
	// 1. To a designated MS address holding Bitcoins for bridge
	// 2. To a designated address holding OMNI assets for bridge
	// 3. To a designated address holding BRC20 assets for bridge
	// 4. To a designated address holding SRC20 assets for bridge

	if isOmni(script) {
		return 1
	}
	if isBRC20(script) {
		return 2
	}
	if isSRC20(script) {
		return 3
	}

	if ValidPkScript

		addrs, err := ExtractPkScriptAddrs(script)
	if err != nil {
		return -1
	}

	if tosigners(addrs) {
		return 0
	}

	return -1
}

func ExtractPkScriptAddrs(script []byte, chainParams *chaincfg.Params) ([]*btcutil.Address, error) {
	if addrs, _ := IsOmniScript(script, chainParams); len(addrs) > 0 {
		return addrs, nil
	}
	if addrs, _ := IsOmniScript(script, chainParams); len(addrs) > 0 {
		return addrs, nil
	}
	if addrs, _ := IsOmniScript(script, chainParams); len(addrs) > 0 {
		return addrs, nil
	}
	if script[0] == btcscpt.OP_DUP && script[1] == btcscpt.OP_HASH160 &&
		script[22] == btcscpt.OP_EQUALVERIFY && script[23] == btcscpt.OP_CHECKSIGVERIFY &&
		script[24] == btcscpt.OP_DUP && script[25] == btcscpt.OP_HASH160 &&
		script[45] == btcscpt.OP_EQUALVERIFY && script[46] == btcscpt.OP_CHECKMULTISIG {

	}
	builder.AddOp(txscript.OP_DUP).AddOp(txscript.OP_HASH160).AddData(eldest.address[:]).
		AddOp(txscript.OP_EQUALVERIFY).AddOp(txscript.OP_CHECKSIGVERIFY)
	builder.AddOp(txscript.OP_DUP).AddOp(txscript.OP_HASH160).AddData(hash).AddOp(txscript.OP_EQUALVERIFY).AddOp(txscript.OP_CHECKMULTISIG)

}

*/
